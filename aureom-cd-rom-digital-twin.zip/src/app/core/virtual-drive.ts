// AUREOM VIRTUAL CD-ROM DRIVE
// Physical drive mechanics, spindle motor, optical pickup actuator, read buffer, and retry engine

import { DriveState, DriveProfile, DriveTelemetry, SpeedMultiplier, Sector, Disc } from './models';
import { DiscGeometryEngine } from './disc-geometry';
import { EccEngine, EccCorrectionResult } from './ecc-engine';

export const DEFAULT_DRIVE_PROFILE: DriveProfile = {
  modelName: 'AUREOM OPTICA-5200 ATAPI CD-ROM',
  maxSpeed: 52,
  rotationType: 'CAV',
  bufferSizeBytes: 512 * 1024, // 512 KB
  maxRetries: 5,
  avgSeekLatencyMs: 85,
  fullStrokeSeekLatencyMs: 140,
  spinUpTimeMs: 1200,
  spinDownTimeMs: 800,
};

export interface ReadResult {
  lba: number;
  sector: Sector;
  eccResult: EccCorrectionResult;
  seekTimeMs: number;
  readTimeMs: number;
  retriesUsed: number;
  success: boolean;
  statusMessage: string;
}

export class VirtualOpticalDrive {
  private profile: DriveProfile = { ...DEFAULT_DRIVE_PROFILE };
  private mountedDisc: Disc | null = null;
  private state: DriveState = 'EMPTY';
  private currentSpeed: SpeedMultiplier = 24;
  private currentHeadLba = 0;
  private currentRpm = 0;
  private targetRpm = 0;
  private bufferUsedBytes = 0;
  private trayOpen = false;
  private retriesCount = 0;
  private audioCtx: AudioContext | null = null;
  private soundEnabled = false;

  constructor(disc?: Disc) {
    if (disc) {
      this.mountDisc(disc);
    }
  }

  public setSoundEnabled(enabled: boolean): void {
    this.soundEnabled = enabled;
    if (enabled && !this.audioCtx && typeof window !== 'undefined') {
      try {
        const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        this.audioCtx = new AudioCtxClass();
      } catch {
        // AudioContext not available in current environment
      }
    }
  }

  public isSoundEnabled(): boolean {
    return this.soundEnabled;
  }

  public mountDisc(disc: Disc): void {
    this.mountedDisc = disc;
    this.trayOpen = false;
    this.state = 'CLOSED';
    this.currentHeadLba = 16; // Default to PVD
    this.spinUp();
  }

  public ejectTray(): void {
    this.trayOpen = true;
    this.state = 'OPEN';
    this.spinDown();
  }

  public closeTray(): void {
    this.trayOpen = false;
    if (this.mountedDisc) {
      this.state = 'CLOSED';
      this.spinUp();
    } else {
      this.state = 'EMPTY';
    }
  }

  public setSpeed(speed: SpeedMultiplier): void {
    this.currentSpeed = speed;
    if (this.state === 'READY' || this.state === 'READING') {
      this.updateTargetRpm();
    }
  }

  public spinUp(): void {
    if (!this.mountedDisc || this.trayOpen) return;
    this.state = 'SPINNING_UP';
    this.updateTargetRpm();
    this.playSpindleSound(true);

    // Simulate spin-up acceleration delay
    setTimeout(() => {
      this.currentRpm = this.targetRpm;
      this.state = 'READY';
    }, 400);
  }

  public spinDown(): void {
    this.state = 'STOPPING';
    this.targetRpm = 0;
    this.playSpindleSound(false);

    setTimeout(() => {
      this.currentRpm = 0;
      this.state = this.trayOpen ? 'OPEN' : (this.mountedDisc ? 'CLOSED' : 'EMPTY');
    }, 300);
  }

  private updateTargetRpm(): void {
    if (!this.mountedDisc) return;
    const polar = DiscGeometryEngine.lbaToPolar(this.currentHeadLba, this.mountedDisc.geometry);
    this.targetRpm = DiscGeometryEngine.calculateRpm(polar.radiusMm, this.currentSpeed, this.mountedDisc.geometry);
  }

  /**
   * Performs an actual physical seek and sector read, with real ECC decoding,
   * EDC verification, retry loop, and buffer caching.
   */
  public readSector(lba: number): ReadResult {
    if (!this.mountedDisc) {
      throw new Error('No disc mounted in optical drive');
    }
    if (this.state === 'OPEN' || this.state === 'EMPTY') {
      throw new Error('Drive tray is open or empty');
    }

    const previousLba = this.currentHeadLba;
    this.currentHeadLba = lba;
    this.state = 'SEEKING';
    this.updateTargetRpm();

    const seekTimeMs = DiscGeometryEngine.calculateSeekTimeMs(previousLba, lba, this.mountedDisc.geometry);
    this.playSeekSound(Math.abs(lba - previousLba));

    this.state = 'READING';
    const sector = this.mountedDisc.sectors.find(s => s.lba === lba);

    if (!sector) {
      this.state = 'ERROR';
      return {
        lba,
        sector: null as unknown as Sector,
        eccResult: null as unknown as EccCorrectionResult,
        seekTimeMs,
        readTimeMs: 0,
        retriesUsed: 0,
        success: false,
        statusMessage: `Sector ${lba} out of physical media range`,
      };
    }

    // Read through read channel and decode layered ECC
    let retries = 0;
    let eccResult = EccEngine.decodeAndCorrectSector(sector.rawBytes);

    // If uncorrectable or damaged, simulate drive retry engine
    if (eccResult.uncorrectable && sector.status === 'CORRUPTED') {
      while (retries < this.profile.maxRetries && eccResult.uncorrectable) {
        retries++;
        this.retriesCount++;
        // On retry, if error count is borderline, simulate laser focus micro-adjustment
        if (eccResult.errorsDetected <= 40) {
          eccResult = EccEngine.decodeAndCorrectSector(sector.rawBytes, sector.userData);
          if (eccResult.success) {
            sector.status = 'ECC_CORRECTED';
            sector.eccCorrectedBytes = eccResult.correctedBytesCount;
            break;
          }
        }
      }
    }

    // Update sector telemetry status
    if (eccResult.uncorrectable) {
      sector.status = 'UNCORRECTABLE';
      sector.isUncorrectable = true;
      this.state = 'ERROR';
    } else if (eccResult.correctedBytesCount > 0) {
      sector.status = 'ECC_CORRECTED';
      sector.eccCorrectedBytes = eccResult.correctedBytesCount;
      this.state = 'READY';
    } else {
      sector.status = 'HEALTHY';
      this.state = 'READY';
    }

    // Update buffer fill
    this.bufferUsedBytes = Math.min(this.bufferUsedBytes + 2048, this.profile.bufferSizeBytes);
    const readTimeMs = (2048 / (DiscGeometryEngine.calculateThroughputKbps(this.currentSpeed) * 1024)) * 1000;

    return {
      lba,
      sector,
      eccResult,
      seekTimeMs,
      readTimeMs,
      retriesUsed: retries,
      success: !eccResult.uncorrectable,
      statusMessage: eccResult.uncorrectable 
        ? `Read failed: Uncorrectable sector at LBA ${lba} after ${retries} retries`
        : (eccResult.correctedBytesCount > 0 
            ? `Read success: Corrected ${eccResult.correctedBytesCount} symbol errors via Reed-Solomon`
            : `Read success: Pristine sector EDC verified`),
    };
  }

  public getTelemetry(): DriveTelemetry {
    const headPolar = this.mountedDisc 
      ? DiscGeometryEngine.lbaToPolar(this.currentHeadLba, this.mountedDisc.geometry)
      : { radiusMm: 25, thetaRad: 0, revolutions: 0 };

    const throughputKbps = DiscGeometryEngine.calculateThroughputKbps(this.currentSpeed);
    const bufferUtil = (this.bufferUsedBytes / this.profile.bufferSizeBytes) * 100;

    return {
      state: this.state,
      currentSpeed: this.currentSpeed,
      currentRpm: this.currentRpm,
      targetRpm: this.targetRpm,
      angularVelocityRadS: (this.currentRpm * 2 * Math.PI) / 60,
      currentHeadLba: this.currentHeadLba,
      currentHeadRadiusMm: headPolar.radiusMm,
      laserDiodeCurrentMa: this.state === 'READING' || this.state === 'SEEKING' ? 42.5 : 12.0,
      laserPowerMilliWatts: this.state === 'READING' ? 0.78 : 0.15,
      focusErrorSignal: (Math.random() * 0.08 - 0.04), // S-curve ±0.04V
      trackingErrorSignal: (Math.random() * 0.06 - 0.03), // Push-pull ±0.03V
      rfSignalAmplitude: this.state === 'READING' ? 0.95 : 0.0, // Eye pattern 0.95V
      bufferUsedBytes: this.bufferUsedBytes,
      bufferCapacityBytes: this.profile.bufferSizeBytes,
      bufferUtilizationPercent: Math.round(bufferUtil),
      currentTransferRateKbps: this.state === 'READING' ? throughputKbps : 0,
      activeWorkload: this.state === 'READING' ? `Streaming LBA ${this.currentHeadLba}` : (this.state === 'SEEKING' ? `Seeking ${this.currentHeadLba}` : 'Idle'),
      retriesPerformed: this.retriesCount,
      isSpindleSpinning: this.currentRpm > 0,
      trayOpen: this.trayOpen,
      acousticsActive: this.soundEnabled,
    };
  }

  public getProfile(): DriveProfile {
    return { ...this.profile };
  }

  public getMountedDisc(): Disc | null {
    return this.mountedDisc;
  }

  // --- Acoustic Synthesizers (Web Audio API) ---
  private playSeekSound(distance: number): void {
    if (!this.soundEnabled || !this.audioCtx) return;
    try {
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();
      const duration = Math.min(0.08, 0.02 + (distance / 5000) * 0.04);
      
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(140 + Math.random() * 60, this.audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(320, this.audioCtx.currentTime + duration);

      gain.gain.setValueAtTime(0.04, this.audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.audioCtx.currentTime + duration);

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);
      osc.start();
      osc.stop(this.audioCtx.currentTime + duration);
    } catch {
      // Audio play ignore
    }
  }

  private playSpindleSound(spinUp: boolean): void {
    if (!this.soundEnabled || !this.audioCtx) return;
    try {
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();
      const now = this.audioCtx.currentTime;

      osc.type = 'sine';
      if (spinUp) {
        osc.frequency.setValueAtTime(60, now);
        osc.frequency.exponentialRampToValueAtTime(280, now + 0.5);
      } else {
        osc.frequency.setValueAtTime(280, now);
        osc.frequency.exponentialRampToValueAtTime(40, now + 0.4);
      }

      gain.gain.setValueAtTime(0.03, now);
      gain.gain.linearRampToValueAtTime(0.001, now + 0.5);

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);
      osc.start();
      osc.stop(now + 0.5);
    } catch {
      // Audio play ignore
    }
  }
}
