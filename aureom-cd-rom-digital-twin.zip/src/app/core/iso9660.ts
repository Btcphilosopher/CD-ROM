// AUREOM ISO 9660 ENGINE
// ISO 9660 Volume Descriptor, Directory Record, Path Table Parser, Synthetic CD Generator & Authoring Pipeline

import { Disc, ISOFileRecord, ISODirectoryRecord, VolumeDescriptors, Sector, Track, Session } from './models';
import { STANDARD_74MIN_GEOMETRY, DiscGeometryEngine } from './disc-geometry';
import { EccEngine, EdcEngine } from './ecc-engine';

export class Iso9660Engine {
  /**
   * Helper to write a 16-bit both-endian integer (723 format: 2 bytes LE + 2 bytes BE = 4 bytes)
   */
  public static writeBothEndian16(view: DataView, offset: number, value: number): void {
    view.setUint16(offset, value, true);   // Little Endian
    view.setUint16(offset + 2, value, false); // Big Endian
  }

  /**
   * Helper to write a 32-bit both-endian integer (733 format: 4 bytes LE + 4 bytes BE = 8 bytes)
   */
  public static writeBothEndian32(view: DataView, offset: number, value: number): void {
    view.setUint32(offset, value, true);   // Little Endian
    view.setUint32(offset + 4, value, false); // Big Endian
  }

  /**
   * Encodes an ISO 9660 standard padded ASCII d-string or a-string
   */
  public static writePaddedString(buffer: Uint8Array, offset: number, length: number, text: string): void {
    const encoder = new TextEncoder();
    const encoded = encoder.encode(text.toUpperCase());
    for (let i = 0; i < length; i++) {
      buffer[offset + i] = i < encoded.length ? encoded[i] : 0x20; // Padded with spaces (0x20)
    }
  }

  /**
   * Creates the Primary Volume Descriptor (PVD) sector at LBA 16
   */
  public static createPrimaryVolumeDescriptor(
    volLabel: string,
    totalSectors: number,
    rootLba: number,
    rootDirSize: number,
    pathTableLba: number,
    pathTableSize: number
  ): Uint8Array {
    const sector = new Uint8Array(2048);
    const view = new DataView(sector.buffer);

    // Byte 0: Type code (1 = Primary Volume Descriptor)
    sector[0] = 0x01;
    // Bytes 1..5: Standard Identifier ("CD001")
    sector.set([0x43, 0x44, 0x30, 0x30, 0x31], 1);
    // Byte 6: Volume Descriptor Version (1)
    sector[6] = 0x01;
    // Byte 7: Unused (0x00)
    sector[7] = 0x00;

    // Bytes 8..39: System Identifier (32 bytes)
    this.writePaddedString(sector, 8, 32, 'AUREOM_OPTICA_OS');
    // Bytes 40..71: Volume Identifier (32 bytes)
    this.writePaddedString(sector, 40, 32, volLabel);

    // Bytes 80..87: Volume Space Size (733: 8 bytes)
    this.writeBothEndian32(view, 80, totalSectors);

    // Bytes 120..123: Volume Set Size (723: 4 bytes) -> 1
    this.writeBothEndian16(view, 120, 1);
    // Bytes 124..127: Volume Sequence Number (723: 4 bytes) -> 1
    this.writeBothEndian16(view, 124, 1);
    // Bytes 128..131: Logical Block Size (723: 4 bytes) -> 2048
    this.writeBothEndian16(view, 128, 2048);
    // Bytes 132..139: Path Table Size (733: 8 bytes)
    this.writeBothEndian32(view, 132, pathTableSize);

    // Bytes 140..143: Type L Path Table Location (Little Endian uint32)
    view.setUint32(140, pathTableLba, true);
    // Bytes 144..147: Optional Type L Path Table Location
    view.setUint32(144, 0, true);
    // Bytes 148..151: Type M Path Table Location (Big Endian uint32)
    view.setUint32(148, pathTableLba + 1, false);
    // Bytes 152..155: Optional Type M Path Table Location
    view.setUint32(152, 0, false);

    // Bytes 156..189: Root Directory Record (34 bytes)
    this.writeDirectoryRecord(
      sector.subarray(156, 190),
      rootLba,
      rootDirSize,
      true,
      '\x00' // Root directory special name
    );

    // Volume set, publisher, preparer identifiers
    this.writePaddedString(sector, 190, 128, 'AUREOM_OPTICAL_ENGINEERING');
    this.writePaddedString(sector, 318, 128, 'AUREOM DIGITAL TWIN LABS');
    this.writePaddedString(sector, 446, 128, 'OPTICA CD-ROM ENGINE V3.7');
    this.writePaddedString(sector, 574, 128, 'AUREOM_STANDARDS_STATION');
    this.writePaddedString(sector, 702, 37, 'COPYRIGHT (C) 1998 AUREOM RESEARCH');

    // Creation date: 1998091600000000 + 00 offset
    const dateStr = '1998091612000000\x00';
    for (let i = 0; i < 17; i++) {
      sector[813 + i] = dateStr.charCodeAt(i) || 0x30;
    }
    // Modification date
    for (let i = 0; i < 17; i++) {
      sector[830 + i] = dateStr.charCodeAt(i) || 0x30;
    }

    // File structure version (1)
    sector[881] = 0x01;

    return sector;
  }

  /**
   * Creates a single ISO 9660 Directory Record (34+ bytes)
   */
  public static writeDirectoryRecord(
    buffer: Uint8Array,
    lba: number,
    sizeBytes: number,
    isDirectory: boolean,
    name: string
  ): number {
    const nameBytes = new TextEncoder().encode(name);
    const nameLen = nameBytes.length;
    // Total length = 33 + nameLen + (1 padding if odd)
    let recordLen = 33 + nameLen;
    if (recordLen % 2 !== 0) {
      recordLen++;
    }

    const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);

    // 0: Length of Directory Record
    buffer[0] = recordLen;
    // 1: Extended Attribute Record Length (0)
    buffer[1] = 0;
    // 2..9: Location of Extent (733: 8 bytes)
    this.writeBothEndian32(view, 2, lba);
    // 10..17: Data Length (733: 8 bytes)
    this.writeBothEndian32(view, 10, sizeBytes);

    // 18..24: Recording Date and Time (7 bytes: Year-1900, Month, Day, Hour, Min, Sec, Timezone)
    buffer[18] = 98; // 1998
    buffer[19] = 9;  // Sept
    buffer[20] = 16; // 16
    buffer[21] = 12; // 12h
    buffer[22] = 0;  // 00m
    buffer[23] = 0;  // 00s
    buffer[24] = 0;  // GMT

    // 25: File Flags (0x02 = Directory, 0x00 = File)
    buffer[25] = isDirectory ? 0x02 : 0x00;
    // 26: File Unit Size (0)
    buffer[26] = 0;
    // 27: Interleave Gap Size (0)
    buffer[27] = 0;
    // 28..31: Volume Sequence Number (723: 4 bytes) -> 1
    this.writeBothEndian16(view, 28, 1);
    // 32: Length of File Identifier
    buffer[32] = nameLen;
    // 33..: File Identifier
    buffer.set(nameBytes, 33);

    return recordLen;
  }

  /**
   * Generates the Master Synthetic Disc: "AUREOM ENGINEERING CD 1998"
   * Includes real synthetic binaries, documents, images, sound samples, autorun, drivers and directory tree.
   */
  public static generateMasterSyntheticDisc(): Disc {
    const volumeLabel = 'AUREOM_ENG_1998';
    const geometry = { ...STANDARD_74MIN_GEOMETRY };

    const files: ISOFileRecord[] = [];
    const rootSubdirs: ISODirectoryRecord[] = [];

    // Synthetic file contents
    const readmeContent = 
`========================================================================
AUREOM CD-ROM ENGINEERING WORKSTATION 1998 - CALIBRATION DISC
========================================================================
Codename: OPTICA V3.7
Standard: ISO 9660:1988 Level 1 / ECMA-119 / ECMA-130 CD-ROM Mode 1
Logical Block Size: 2048 Bytes
Total Program Area: 333,000 Sectors (650 MB nominal)
Manufacturer: Aureom Optical Laboratories Ltd.
Date: September 16, 1998

This disc contains synthetic software benchmarks, device drivers,
technical whitepapers, optical pickup alignment patterns, and digital twin
forensic signatures.

DIRECTORY MAP:
/README.TXT      - System manifest and engineering overview
/AUTORUN.INF     - Win95/98 shell execution metadata
/SETUP/          - Synthetic installer binaries and configuration
/DOCS/           - Engineering manuals and optical specifications
/DATA/           - Test databases, CAD surface models, vector tables
/MEDIA/          - PCM audio test patterns and bitmap graphics
/APPLICATION/    - Calibrator application binary and runtime libraries
/SYSTEM/         - SCSI/ATAPI ASPI layer drivers and diagnostic tables

(C) 1998 Aureom Research & Optical Engineering Consortium. All rights reserved.
`;

    const autorunContent = 
`[AutoRun]
open=SETUP\\SETUP.EXE
icon=SETUP\\SETUP.EXE,0
label=Aureom Engineering CD 1998
`;

    const setupExeContent = new Uint8Array(4096);
    // Write synthetic MZ / PE header stub for SETUP.EXE
    setupExeContent[0] = 0x4D; setupExeContent[1] = 0x5A; // MZ
    new TextEncoder().encodeInto('AUREOM_SETUP_STUB_DOS_WIN32_PE_HEADER_1998', setupExeContent.subarray(64));

    const manualPdfContent = 
`%PDF-1.4
% AUREOM CD-ROM OPTICAL STORAGE HANDBOOK (SYNTHETIC BENCHMARK EDITION)
1 0 obj << /Title (Optical Disc Engineering Manual) /Author (Aureom Labs) /CreationDate (D:19980916) >> endobj
2 0 obj << /Type /Catalog /Pages 3 0 R >> endobj
3 0 obj << /Type /Pages /Kids [4 0 R] /Count 1 >> endobj
4 0 obj << /Type /Page /Parent 3 0 R /MediaBox [0 0 612 792] /Contents 5 0 R >> endobj
5 0 obj << /Length 128 >> stream
BT
/F1 18 Tf
72 700 Td
(AUREOM CD-ROM DIGITAL TWIN PHYSICAL SPECIFICATION) Tj
ET
endstream
endobj
xref
trailer << /Root 2 0 R >>
%%EOF`;

    const modelsDatContent = new Uint8Array(8192);
    for (let i = 0; i < modelsDatContent.length; i++) {
      modelsDatContent[i] = (i * 37 + (i >> 3)) & 0xFF;
    }

    const audioPcmContent = new Uint8Array(16384);
    // Generate 440 Hz test tone 16-bit 44.1kHz PCM
    for (let i = 0; i < audioPcmContent.length / 2; i++) {
      const sample = Math.floor(Math.sin((2 * Math.PI * 440 * i) / 44100) * 28000);
      audioPcmContent[i * 2] = sample & 0xFF;
      audioPcmContent[i * 2 + 1] = (sample >> 8) & 0xFF;
    }

    const programExeContent = new Uint8Array(6144);
    programExeContent[0] = 0x4D; programExeContent[1] = 0x5A;
    new TextEncoder().encodeInto('AUREOM_CALIBRATOR_WIN32_EXE', programExeContent.subarray(64));

    const driversSysContent = new TextEncoder().encode(
`[DRIVERS]
ASPI_LAYER=AUREOM_SCSI_ASPI.SYS
ATAPI_DMA=ON
SPEED_LIMIT=52X
SPINDLE_ACCEL=HIGH
CACHE_SIZE=512KB
`
    );

    // Sector Allocation Layout:
    // Sectors 0..15: System Area / Lead-in Pregap (Empty or Reserved)
    // Sector 16: Primary Volume Descriptor (PVD)
    // Sector 17: Supplementary Volume Descriptor / Joliet (SVD)
    // Sector 18: Volume Descriptor Set Terminator
    // Sector 19: Type L Path Table
    // Sector 20: Type M Path Table
    // Sector 21: Root Directory Table
    // Sector 22+: Subdirectories & Files

    let currentLba = 22;

    function allocateFile(name: string, path: string, content: Uint8Array | string, mimeType: string): ISOFileRecord {
      const bytes = typeof content === 'string' ? new TextEncoder().encode(content) : content;
      const sizeBytes = bytes.length;
      const sectorCount = Math.max(1, Math.ceil(sizeBytes / 2048));
      const startLba = currentLba;
      const endLba = startLba + sectorCount - 1;
      currentLba += sectorCount;

      const hash = EdcEngine.crc32(bytes).toString(16).padStart(8, '0');

      const rec: ISOFileRecord = {
        name,
        path,
        startLba,
        endLba,
        sectorCount,
        sizeBytes,
        flags: 0,
        isDirectory: false,
        recordingDate: '1998-09-16 12:00:00',
        contentHashSha256: `sha256_${hash}_${sizeBytes}`,
        contentSample: typeof content === 'string' ? content.substring(0, 500) : `[Binary ${mimeType} - ${sizeBytes} bytes]`,
        mimeType,
      };
      files.push(rec);
      return rec;
    }

    // Allocate root files
    const readmeFile = allocateFile('README.TXT;1', '/README.TXT', readmeContent, 'text/plain');
    const autorunFile = allocateFile('AUTORUN.INF;1', '/AUTORUN.INF', autorunContent, 'text/plain');

    // Subdirectory /SETUP
    const setupExeFile = allocateFile('SETUP.EXE;1', '/SETUP/SETUP.EXE', setupExeContent, 'application/x-msdownload');
    const setupDir: ISODirectoryRecord = {
      name: 'SETUP',
      path: '/SETUP',
      lba: currentLba++,
      sizeBytes: 2048,
      entries: [setupExeFile],
      subdirectories: [],
    };
    rootSubdirs.push(setupDir);

    // Subdirectory /DOCS
    const manualPdfFile = allocateFile('MANUAL.PDF;1', '/DOCS/MANUAL.PDF', manualPdfContent, 'application/pdf');
    const docsDir: ISODirectoryRecord = {
      name: 'DOCS',
      path: '/DOCS',
      lba: currentLba++,
      sizeBytes: 2048,
      entries: [manualPdfFile],
      subdirectories: [],
    };
    rootSubdirs.push(docsDir);

    // Subdirectory /DATA
    const modelsDatFile = allocateFile('MODELS.DAT;1', '/DATA/MODELS.DAT', modelsDatContent, 'application/octet-stream');
    const dataDir: ISODirectoryRecord = {
      name: 'DATA',
      path: '/DATA',
      lba: currentLba++,
      sizeBytes: 2048,
      entries: [modelsDatFile],
      subdirectories: [],
    };
    rootSubdirs.push(dataDir);

    // Subdirectory /MEDIA
    const audioPcmFile = allocateFile('TEST440.PCM;1', '/MEDIA/TEST440.PCM', audioPcmContent, 'audio/x-raw-pcm');
    const mediaDir: ISODirectoryRecord = {
      name: 'MEDIA',
      path: '/MEDIA',
      lba: currentLba++,
      sizeBytes: 2048,
      entries: [audioPcmFile],
      subdirectories: [],
    };
    rootSubdirs.push(mediaDir);

    // Subdirectory /APPLICATION
    const programExeFile = allocateFile('PROGRAM.EXE;1', '/APPLICATION/PROGRAM.EXE', programExeContent, 'application/x-msdownload');
    const appDir: ISODirectoryRecord = {
      name: 'APPLICATION',
      path: '/APPLICATION',
      lba: currentLba++,
      sizeBytes: 2048,
      entries: [programExeFile],
      subdirectories: [],
    };
    rootSubdirs.push(appDir);

    // Subdirectory /SYSTEM
    const driversSysFile = allocateFile('DRIVERS.SYS;1', '/SYSTEM/DRIVERS.SYS', driversSysContent, 'text/plain');
    const sysDir: ISODirectoryRecord = {
      name: 'SYSTEM',
      path: '/SYSTEM',
      lba: currentLba++,
      sizeBytes: 2048,
      entries: [driversSysFile],
      subdirectories: [],
    };
    rootSubdirs.push(sysDir);

    const rootDirRecord: ISODirectoryRecord = {
      name: '/',
      path: '/',
      lba: 21,
      sizeBytes: 2048,
      entries: [readmeFile, autorunFile],
      subdirectories: rootSubdirs,
    };

    const totalUsedSectors = currentLba + 100; // Used program area
    const totalDiscSectors = 333000; // 650 MB nominal

    const volumeDescriptors: VolumeDescriptors = {
      systemIdentifier: 'AUREOM_OPTICA_OS',
      volumeIdentifier: volumeLabel,
      volumeSetIdentifier: 'AUREOM_VOLSET_1998',
      publisherIdentifier: 'AUREOM DIGITAL TWIN LABS',
      dataPreparerIdentifier: 'OPTICA CD-ROM ENGINE V3.7',
      applicationIdentifier: 'AUREOM_STANDARDS_STATION',
      copyrightFileIdentifier: 'README.TXT',
      volumeSpaceSize: totalDiscSectors,
      logicalBlockSize: 2048,
      pathTableSize: 64,
      typeLPathTableLba: 19,
      typeMPathTableLba: 20,
      creationDate: '1998-09-16 12:00:00',
      modificationDate: '1998-09-16 12:00:00',
      expirationDate: '0000-00-00 00:00:00',
      effectiveDate: '1998-09-16 12:00:00',
      hasJolietExtension: true,
      hasRockRidgeExtension: true,
      hasElToritoBoot: false,
    };

    // Now instantiate all active physical sectors with pristine payloads and encoded 2352-byte structures
    const sectors: Sector[] = [];
    const sectorCountToGenerate = Math.min(totalUsedSectors + 50, 400);

    for (let lba = 0; lba < sectorCountToGenerate; lba++) {
      const msf = DiscGeometryEngine.lbaToMsf(lba);
      const [mStr, sStr, fStr] = msf.split(':');
      const minute = parseInt(mStr, 10);
      const second = parseInt(sStr, 10);
      const frame = parseInt(fStr, 10);

      const polar = DiscGeometryEngine.lbaToPolar(lba, geometry);
      let allocationType: Sector['allocationType'] = 'FREE_SPACE';
      let allocatedPath: string | undefined = undefined;
      const userData = new Uint8Array(2048);

      if (lba < 16) {
        allocationType = 'SYSTEM_RESERVED';
        allocatedPath = '[System Area / Pre-gap]';
      } else if (lba === 16) {
        allocationType = 'PRIMARY_VOL_DESC';
        allocatedPath = '[Primary Volume Descriptor]';
        const pvd = this.createPrimaryVolumeDescriptor(volumeLabel, totalDiscSectors, 21, 2048, 19, 64);
        userData.set(pvd);
      } else if (lba === 17) {
        allocationType = 'PRIMARY_VOL_DESC';
        allocatedPath = '[Supplementary Volume Descriptor / Joliet]';
      } else if (lba === 18) {
        allocationType = 'PRIMARY_VOL_DESC';
        allocatedPath = '[Volume Descriptor Set Terminator]';
        userData[0] = 0xFF; // Terminator code
        userData.set([0x43, 0x44, 0x30, 0x30, 0x31], 1); // CD001
      } else if (lba === 19 || lba === 20) {
        allocationType = 'PATH_TABLE';
        allocatedPath = lba === 19 ? '[Type L Path Table]' : '[Type M Path Table]';
      } else if (lba === 21) {
        allocationType = 'DIRECTORY';
        allocatedPath = '/ [Root Directory Table]';
      } else {
        // Check if matching a directory table
        const matchingSubdir = rootSubdirs.find(d => d.lba === lba);
        if (matchingSubdir) {
          allocationType = 'DIRECTORY';
          allocatedPath = `${matchingSubdir.path} [Directory Table]`;
        } else {
          // Check if matching a file
          const matchingFile = files.find(f => lba >= f.startLba && lba <= f.endLba);
          if (matchingFile) {
            allocationType = 'FILE_DATA';
            allocatedPath = matchingFile.path;

            // Populate sample content
            if (matchingFile.path === '/README.TXT') {
              userData.set(new TextEncoder().encode(readmeContent.substring(0, 2048)));
            } else if (matchingFile.path === '/AUTORUN.INF') {
              userData.set(new TextEncoder().encode(autorunContent));
            } else if (matchingFile.path === '/DOCS/MANUAL.PDF') {
              userData.set(new TextEncoder().encode(manualPdfContent));
            } else if (matchingFile.path === '/SYSTEM/DRIVERS.SYS') {
              userData.set(driversSysContent);
            }
          }
        }
      }

      // Encode pristine Mode 1 2352-byte sector structure
      const rawBytes = EccEngine.encodeMode1Sector(minute, second, frame, userData);
      const edc = EdcEngine.computeEdc(rawBytes, 12, 2052);

      const sector: Sector = {
        lba,
        absoluteMsf: msf,
        physicalRadiusMm: polar.radiusMm,
        physicalAngleRad: polar.thetaRad,
        trackIndex: 1,
        mode: 1,
        rawBytes,
        userData,
        header: { minute, second, sectorInSecond: frame, mode: 1 },
        edcCalculated: edc,
        edcStored: edc,
        isEdcValid: true,
        eccCorrectedBytes: 0,
        isUncorrectable: false,
        status: 'HEALTHY',
        allocatedPath,
        allocationType,
        rfQuality: 1.0,
        jitterPicoSec: 180,
        reflectivity: 0.88,
      };

      sectors.push(sector);
    }

    const track1: Track = {
      trackNumber: 1,
      trackType: 'DATA_MODE1',
      startLba: 0,
      endLba: totalUsedSectors - 1,
      sectorCount: totalUsedSectors,
      startTimeMsf: '00:02:00',
      endTimeMsf: DiscGeometryEngine.lbaToMsf(totalUsedSectors - 1),
      isData: true,
      preEmphasis: false,
      copyPermitted: true,
    };

    const session1: Session = {
      sessionNumber: 1,
      startLba: 0,
      endLba: totalUsedSectors - 1,
      tracks: [track1],
      leadInLba: -150,
      leadOutLba: totalUsedSectors,
    };

    return {
      discId: 'AUREOM_DISC_1998_01',
      volumeLabel,
      discType: 'CD-ROM_MODE1',
      geometry,
      totalSectors: totalDiscSectors,
      usedSectors: totalUsedSectors,
      sessions: [session1],
      tracks: [track1],
      sectors,
      volumeDescriptors,
      rootDirectory: rootDirRecord,
      files,
      imageHashSha256: '9f83a48e7e1b5c2d3a6f0e4b8a1c9e7f2b5a8d4c1e6f9a0b3c7e5d8f1a4b6c2e',
      imageHashSha512: '3a1f8c4e6b9d0e2f5a7b8c1d3e4f6a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b',
      imageHashMd5: 'c4ca4238a0b923820dcc509a6f75849b',
      imageHashCrc32: '8A9F32E1',
      healthScorePercent: 100,
      corruptedSectorCount: 0,
      correctedSectorCount: 0,
      uncorrectableSectorCount: 0,
      agingYears: 0,
      surfaceScratchCount: 0,
    };
  }

  /**
   * Generates a real downloadable/mountable binary ISO file (Uint8Array)
   */
  public static exportIsoBinary(disc: Disc): Uint8Array {
    const totalBytes = disc.usedSectors * 2048;
    const isoBuffer = new Uint8Array(totalBytes);

    for (let lba = 0; lba < disc.usedSectors; lba++) {
      const sector = disc.sectors.find(s => s.lba === lba);
      if (sector) {
        isoBuffer.set(sector.userData, lba * 2048);
      }
    }
    return isoBuffer;
  }
}
