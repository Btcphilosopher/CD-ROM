// AUREOM DATA CORRUPTION & DISC DEGRADATION LAB
// Physical Scratch Modeling, Kinetic Arrhenius Aging, Burst Errors, and Sector Defect Injection

import { Disc, ScratchDef, DegradationProfile, Sector } from './models';

export class CorruptionLab {
  /**
   * Applies a physical surface scratch to the disc, calculating spiral track intersections
   * and injecting proportional bit/byte corruption into the affected sectors.
   */
  public static applyScratch(disc: Disc, scratch: ScratchDef): { affectedSectors: Sector[]; damagedFiles: string[] } {
    const affectedSectors: Sector[] = [];
    const damagedFileSet = new Set<string>();

    const rLeadIn = disc.geometry.leadInEndRadiusMm;
    const rProgEnd = disc.geometry.programEndRadiusMm;

    // Line segment from (startX, startY) to (endX, endY) in mm
    const dx = scratch.endXmm - scratch.startXmm;
    const dy = scratch.endYmm - scratch.startYmm;
    const length = Math.sqrt(dx * dx + dy * dy);
    const steps = Math.max(10, Math.floor(length * 4)); // Sample every 0.25mm

    for (let step = 0; step <= steps; step++) {
      const t = step / steps;
      const x = scratch.startXmm + dx * t;
      const y = scratch.startYmm + dy * t;
      const r = Math.sqrt(x * x + y * y);

      if (r >= rLeadIn && r <= rProgEnd) {
        let theta = Math.atan2(y, x);
        if (theta < 0) theta += 2 * Math.PI;

        // Estimate matching LBA along spiral
        const pitchMm = disc.geometry.trackPitchUm / 1000.0;
        const revs = (r - rLeadIn) / pitchMm;
        const totalAngle = revs * 2 * Math.PI + theta;
        const trackLen = (totalAngle * (rLeadIn + r)) / 2.0; // Archimedean spiral arc length approx
        const sectorLen = (disc.geometry.linearVelocityMs * 1000.0) / 75.0;
        const estimatedLba = Math.floor(trackLen / sectorLen);

        // Find sector within tolerance
        const targetSector = disc.sectors.find(s => Math.abs(s.lba - estimatedLba) <= 1);
        if (targetSector && !affectedSectors.includes(targetSector)) {
          affectedSectors.push(targetSector);

          // Corrupt raw bytes based on scratch severity
          const corruptBytesCount = Math.floor(scratch.severity * 80); // 8 to 80 corrupted bytes
          for (let b = 0; b < corruptBytesCount; b++) {
            const bytePos = 16 + Math.floor(Math.random() * 2048);
            targetSector.rawBytes[bytePos] ^= (0x55 ^ (b * 7)) & 0xFF;
          }

          targetSector.rfQuality = Math.max(0.1, targetSector.rfQuality - scratch.severity * 0.7);
          targetSector.jitterPicoSec += Math.floor(scratch.severity * 150);
          targetSector.status = scratch.severity > 0.6 ? 'CORRUPTED' : 'CORRUPTED';

          if (targetSector.allocatedPath && targetSector.allocatedPath.startsWith('/')) {
            damagedFileSet.add(targetSector.allocatedPath);
          }
        }
      }
    }

    scratch.affectedSectorsCount = affectedSectors.length;
    disc.surfaceScratchCount++;
    this.recalculateDiscHealth(disc);

    return {
      affectedSectors,
      damagedFiles: Array.from(damagedFileSet),
    };
  }

  /**
   * Simulates theoretical degradation / disc rot using an Arrhenius kinetic equation:
   * k = A * exp(-Ea / (R * T)) * (RH / 50)^1.5 * age
   */
  public static simulateAging(disc: Disc, profile: DegradationProfile): {
    newCorruptedSectors: number;
    healthScore: number;
    riskSummary: string;
  } {
    disc.agingYears = profile.ageYears;
    const tempKelvin = profile.storageTempCelsius + 273.15;
    
    // Arrhenius rate multiplier (nominal 20C / 50% RH = 1.0)
    const thermalStress = Math.exp((tempKelvin - 293.15) / 12.0);
    const humidityStress = Math.pow(profile.relativeHumidityPercent / 50.0, 1.4);
    const totalAgingFactor = (profile.ageYears / 25.0) * thermalStress * humidityStress * (1.0 + profile.laserRotOxidation * 2.0);

    let newlyCorrupted = 0;

    for (const sector of disc.sectors) {
      // Random defect probability per sector
      const defectProbability = Math.min(0.8, 0.0005 * totalAgingFactor + profile.laserRotOxidation * 0.05 + profile.polycarbonateHaze * 0.02);
      
      if (Math.random() < defectProbability && sector.status === 'HEALTHY') {
        const errors = 5 + Math.floor(Math.random() * 60);
        for (let i = 0; i < errors; i++) {
          const pos = 16 + Math.floor(Math.random() * 2048);
          sector.rawBytes[pos] ^= 0xAA;
        }
        sector.status = 'CORRUPTED';
        sector.reflectivity = Math.max(0.3, sector.reflectivity - profile.laserRotOxidation * 0.4);
        sector.rfQuality = Math.max(0.15, sector.rfQuality - profile.polycarbonateHaze * 0.5);
        newlyCorrupted++;
      }
    }

    this.recalculateDiscHealth(disc);

    return {
      newCorruptedSectors: newlyCorrupted,
      healthScore: disc.healthScorePercent,
      riskSummary: disc.healthScorePercent > 85 
        ? 'Primacy maintained: Minor optical jitter, well within CIRC error recovery threshold.'
        : (disc.healthScorePercent > 60 
            ? 'Degraded: Significant C1/C2 error rate; file system records at risk of uncorrectable read dropouts.'
            : 'Severe Laser Rot: High risk of unrecoverable data loss in critical directory structures.'),
    };
  }

  /**
   * Injects specific burst errors or single bit flips into a target sector LBA
   */
  public static injectSectorError(disc: Disc, lba: number, byteCount = 30): Sector | null {
    const sector = disc.sectors.find(s => s.lba === lba);
    if (!sector) return null;

    for (let i = 0; i < byteCount; i++) {
      const pos = 16 + (i * 13) % 2048;
      sector.rawBytes[pos] ^= 0xFF;
    }
    sector.status = 'CORRUPTED';
    sector.rfQuality = Math.max(0.1, sector.rfQuality - 0.4);
    this.recalculateDiscHealth(disc);
    return sector;
  }

  /**
   * Recalculates disc health score and statistics
   */
  public static recalculateDiscHealth(disc: Disc): void {
    let corrupted = 0;
    let corrected = 0;
    let uncorrectable = 0;

    for (const s of disc.sectors) {
      if (s.status === 'CORRUPTED') corrupted++;
      else if (s.status === 'ECC_CORRECTED') corrected++;
      else if (s.status === 'UNCORRECTABLE') uncorrectable++;
    }

    disc.corruptedSectorCount = corrupted;
    disc.correctedSectorCount = corrected;
    disc.uncorrectableSectorCount = uncorrectable;

    const totalEvaluated = Math.max(1, disc.sectors.length);
    const damaged = corrupted + uncorrectable * 3 + corrected * 0.2;
    const score = Math.max(0, Math.min(100, Math.round(100 - (damaged / totalEvaluated) * 100)));
    disc.healthScorePercent = score;
  }
}
