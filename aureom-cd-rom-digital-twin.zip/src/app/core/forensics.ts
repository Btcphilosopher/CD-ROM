// AUREOM CD-ROM FORENSICS & DIGITAL PRESERVATION ENGINE
// Cryptographic Hashing, Anomaly Detection, Differential Sector Analysis, and Preservation Reports

import { Disc, ForensicReport } from './models';
import { EdcEngine } from './ecc-engine';

export interface ImageDiffResult {
  identical: boolean;
  totalSectorsCompared: number;
  differingSectorsCount: number;
  differingSectors: {
    lba: number;
    path?: string;
    originalStatus: string;
    targetStatus: string;
    byteDiffCount: number;
  }[];
  metadataChanges: string[];
}

export class ForensicsEngine {
  /**
   * Generates a complete cryptographic forensic inspection and preservation audit report
   */
  public static generateForensicReport(disc: Disc): ForensicReport {
    const reportId = `OPTICA-AUDIT-${Date.now().toString(36).toUpperCase()}`;
    const timestamp = new Date().toISOString();

    let healthyCount = 0;
    let correctedCount = 0;
    let uncorrectableCount = 0;
    let corruptedCount = 0;
    let orphanCount = 0;
    let slackBytes = 0;
    const anomalies: string[] = [];

    // Scan all sectors
    for (const sector of disc.sectors) {
      if (sector.status === 'HEALTHY') healthyCount++;
      else if (sector.status === 'ECC_CORRECTED') correctedCount++;
      else if (sector.status === 'UNCORRECTABLE') {
        uncorrectableCount++;
        anomalies.push(`LBA ${sector.lba} (${sector.absoluteMsf}): Uncorrectable Reed-Solomon failure in ${sector.allocatedPath || 'Free space'}`);
      } else if (sector.status === 'CORRUPTED') {
        corruptedCount++;
        anomalies.push(`LBA ${sector.lba}: EDC checksum mismatch (${sector.edcCalculated.toString(16)} != ${sector.edcStored.toString(16)})`);
      }

      if (sector.allocationType === 'FREE_SPACE' && sector.userData.some(b => b !== 0)) {
        slackBytes += 2048;
        orphanCount++;
        anomalies.push(`LBA ${sector.lba}: Hidden slack space / non-zero unallocated sector data detected.`);
      }
    }

    // Verify Volume Descriptors
    if (disc.volumeDescriptors.logicalBlockSize !== 2048) {
      anomalies.push(`Volume descriptor specifies non-standard block size: ${disc.volumeDescriptors.logicalBlockSize} bytes.`);
    }

    const fileInventory = disc.files.map(f => {
      const isDamaged = disc.sectors.some(s => s.lba >= f.startLba && s.lba <= f.endLba && (s.status === 'CORRUPTED' || s.status === 'UNCORRECTABLE'));
      return {
        path: f.path,
        size: f.sizeBytes,
        startLba: f.startLba,
        endLba: f.endLba,
        sha256: f.contentHashSha256,
        status: isDamaged ? ('DAMAGED' as const) : ('INTACT' as const),
      };
    });

    const report: ForensicReport = {
      reportId,
      timestamp,
      discIdentifier: disc.discId,
      volumeLabel: disc.volumeLabel,
      totalCapacityBytes: disc.totalSectors * 2048,
      totalSectors: disc.totalSectors,
      usedSectors: disc.usedSectors,
      freeSectors: disc.totalSectors - disc.usedSectors,
      hashes: {
        sha256: disc.imageHashSha256,
        sha512: disc.imageHashSha512,
        md5: disc.imageHashMd5,
        crc32: disc.imageHashCrc32,
      },
      volumeDescriptors: disc.volumeDescriptors,
      directoryCount: 7, // Standard synthetic tree
      fileCount: disc.files.length,
      sectorIntegrity: {
        healthySectors: healthyCount,
        correctedSectors: correctedCount,
        uncorrectableSectors: uncorrectableCount,
        corruptedSectors: corruptedCount,
        orphanSectors: orphanCount,
        slackSpaceBytes: slackBytes,
      },
      filesInventory: fileInventory,
      anomaliesFound: anomalies,
      signature: `AUREOM-EDC-ECC-DIGITAL-SIGNATURE-${EdcEngine.crc32(new TextEncoder().encode(reportId + timestamp)).toString(16).toUpperCase()}`,
    };

    return report;
  }

  /**
   * Compares two discs (or baseline vs modified) sector-by-sector
   */
  public static compareDiscs(original: Disc, modified: Disc): ImageDiffResult {
    const differingSectors: ImageDiffResult['differingSectors'] = [];
    const metadataChanges: string[] = [];

    if (original.volumeLabel !== modified.volumeLabel) {
      metadataChanges.push(`Volume Label changed: "${original.volumeLabel}" -> "${modified.volumeLabel}"`);
    }
    if (original.healthScorePercent !== modified.healthScorePercent) {
      metadataChanges.push(`Disc Health Score changed: ${original.healthScorePercent}% -> ${modified.healthScorePercent}%`);
    }

    const maxSectors = Math.max(original.sectors.length, modified.sectors.length);

    for (let lba = 0; lba < maxSectors; lba++) {
      const sOrig = original.sectors.find(s => s.lba === lba);
      const sMod = modified.sectors.find(s => s.lba === lba);

      if (!sOrig || !sMod) {
        differingSectors.push({
          lba,
          path: sOrig?.allocatedPath || sMod?.allocatedPath,
          originalStatus: sOrig ? sOrig.status : 'NON_EXISTENT',
          targetStatus: sMod ? sMod.status : 'NON_EXISTENT',
          byteDiffCount: 2352,
        });
        continue;
      }

      // Check byte diff
      let byteDiff = 0;
      for (let b = 0; b < 2352; b++) {
        if (sOrig.rawBytes[b] !== sMod.rawBytes[b]) {
          byteDiff++;
        }
      }

      if (byteDiff > 0 || sOrig.status !== sMod.status) {
        differingSectors.push({
          lba,
          path: sOrig.allocatedPath,
          originalStatus: sOrig.status,
          targetStatus: sMod.status,
          byteDiffCount: byteDiff,
        });
      }
    }

    return {
      identical: differingSectors.length === 0 && metadataChanges.length === 0,
      totalSectorsCompared: maxSectors,
      differingSectorsCount: differingSectors.length,
      differingSectors,
      metadataChanges,
    };
  }

  /**
   * Formats the forensic report into a comprehensive Markdown document
   */
  public static formatMarkdownReport(report: ForensicReport): string {
    return `# AUREOM CD-ROM FORENSIC & DIGITAL PRESERVATION REPORT
**Report ID**: \`${report.reportId}\`  
**Generated**: ${report.timestamp}  
**Software**: Aureom OPTICA CD-ROM Digital Twin Laboratory v3.7

---

## 1. MEDIA IDENTIFICATION & CRYPTOGRAPHIC HASHES
| Metric | Value |
| :--- | :--- |
| **Volume Identifier** | \`${report.volumeLabel}\` |
| **System Identifier** | \`${report.volumeDescriptors.systemIdentifier}\` |
| **Publisher** | \`${report.volumeDescriptors.publisherIdentifier}\` |
| **Total Sectors** | ${report.totalSectors.toLocaleString()} (650 MB / 74-min standard) |
| **Used Sectors** | ${report.usedSectors.toLocaleString()} sectors (${((report.usedSectors * 2048) / 1024 / 1024).toFixed(2)} MB) |
| **SHA-256 Hash** | \`${report.hashes.sha256}\` |
| **SHA-512 Hash** | \`${report.hashes.sha512.substring(0, 32)}...\` |
| **CRC-32 Checksum** | \`0x${report.hashes.crc32}\` |

---

## 2. PHYSICAL SECTOR & ECC INTEGRITY
- **Healthy Sectors**: ${report.sectorIntegrity.healthySectors}
- **Reed-Solomon Corrected Sectors**: ${report.sectorIntegrity.correctedSectors}
- **Uncorrectable Sectors (Dead Blocks)**: ${report.sectorIntegrity.uncorrectableSectors}
- **Corrupted Sectors (Pending Decode)**: ${report.sectorIntegrity.corruptedSectors}
- **Hidden Slack Space**: ${report.sectorIntegrity.slackSpaceBytes} bytes in ${report.sectorIntegrity.orphanSectors} sectors

---

## 3. FILE SYSTEM INVENTORY & CRYPTOGRAPHIC PROOF
| File Path | Extent LBA Range | Size (Bytes) | Integrity | SHA-256 Digest |
| :--- | :--- | :--- | :--- | :--- |
${report.filesInventory.map(f => `| \`${f.path}\` | LBA ${f.startLba} - ${f.endLba} | ${f.size.toLocaleString()} | **${f.status}** | \`${f.sha256.substring(0, 24)}...\` |`).join('\n')}

---

## 4. ANOMALIES & AUDIT LOG
${report.anomaliesFound.length === 0 ? '_No anomalies or sector discrepancies detected. Image is cryptographically pristine._' : report.anomaliesFound.map(a => `- ⚠️ ${a}`).join('\n')}

---
**Verification Signature**: \`${report.signature}\`
`;
  }
}
