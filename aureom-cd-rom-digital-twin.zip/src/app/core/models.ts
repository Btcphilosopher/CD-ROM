// AUREOM CD-ROM DIGITAL TWIN - CANONICAL DATA MODELS
// Codename: OPTICA

export type DiscType = 'CD-ROM_MODE1' | 'CD-ROM_MODE2_FORM1' | 'CD-ROM_MODE2_FORM2' | 'CD-DA_AUDIO' | 'CD-R_74MIN' | 'CD-R_80MIN';

export type TrackType = 'DATA_MODE1' | 'DATA_MODE2' | 'AUDIO' | 'MIXED_MODE';

export type DriveState = 
  | 'EMPTY' 
  | 'OPEN' 
  | 'CLOSED' 
  | 'SPINNING_UP' 
  | 'READY' 
  | 'SEEKING' 
  | 'READING' 
  | 'BUFFERING' 
  | 'RETRYING' 
  | 'ERROR' 
  | 'STOPPING';

export type SpeedMultiplier = 1 | 2 | 4 | 8 | 12 | 16 | 24 | 32 | 40 | 52;

export interface DiscGeometry {
  outerRadiusMm: number;        // e.g. 60.0 mm (120 mm diameter)
  innerRadiusMm: number;        // e.g. 7.5 mm (15 mm center hole)
  clampingRadiusMm: number;   // e.g. 13.0 mm (26 mm clamping area)
  leadInStartRadiusMm: number; // e.g. 23.0 mm
  leadInEndRadiusMm: number;   // e.g. 25.0 mm (LBA 0 begins here)
  programEndRadiusMm: number;  // e.g. 58.0 mm
  leadOutEndRadiusMm: number;  // e.g. 59.5 mm
  thicknessMm: number;         // e.g. 1.2 mm
  trackPitchUm: number;        // e.g. 1.6 µm (standard CD)
  linearVelocityMs: number;    // e.g. 1.2 to 1.4 m/s (standard 1x)
  totalCapacityMb: number;     // e.g. 650 MB / 700 MB
  maxSectors: number;          // e.g. 333,000 sectors for 74 min (650MB)
}

export interface SectorHeader {
  minute: number;
  second: number;
  sectorInSecond: number; // 0..74
  mode: number;           // 1 for Mode 1, 2 for Mode 2
}

export interface SectorSubheader {
  fileNumber: number;
  channelNumber: number;
  submode: number;
  codingInfo: number;
}

export type SectorStatus = 'HEALTHY' | 'CORRUPTED' | 'ECC_CORRECTED' | 'UNCORRECTABLE' | 'EMPTY' | 'ORPHAN';

export interface Sector {
  lba: number;                    // Logical Block Address (0, 1, 2, ...)
  absoluteMsf: string;           // "MM:SS:FF" (e.g. "00:02:00" for LBA 0)
  physicalRadiusMm: number;      // Radial distance from center in mm
  physicalAngleRad: number;      // Angle along Archimedean spiral in radians
  trackIndex: number;
  mode: number;                  // 1 = CD-ROM Mode 1
  rawBytes: Uint8Array;          // Full 2352 bytes for Mode 1 (Sync+Header+Data+EDC+Reserved+ECC)
  userData: Uint8Array;          // 2048 bytes payload
  header: SectorHeader;
  edcCalculated: number;         // 32-bit EDC CRC
  edcStored: number;
  isEdcValid: boolean;
  eccCorrectedBytes: number;     // Number of symbol errors corrected
  isUncorrectable: boolean;
  status: SectorStatus;
  
  // High-level filesystem allocation link
  allocatedPath?: string;
  allocationType: 'LEAD_IN' | 'SYSTEM_RESERVED' | 'PRIMARY_VOL_DESC' | 'PATH_TABLE' | 'DIRECTORY' | 'FILE_DATA' | 'FREE_SPACE' | 'LEAD_OUT';
  
  // Physical simulation metrics
  rfQuality: number;             // 0.0 to 1.0 (1.0 = pristine RF eye pattern)
  jitterPicoSec: number;        // Track jitter in picoseconds
  reflectivity: number;          // 0.0 to 1.0 (0.85 nominal for aluminum)
}

export interface Track {
  trackNumber: number;
  trackType: TrackType;
  startLba: number;
  endLba: number;
  sectorCount: number;
  startTimeMsf: string;
  endTimeMsf: string;
  isData: boolean;
  preEmphasis: boolean;
  copyPermitted: boolean;
}

export interface Session {
  sessionNumber: number;
  startLba: number;
  endLba: number;
  tracks: Track[];
  leadInLba: number;
  leadOutLba: number;
}

export interface ISOFileRecord {
  name: string;
  path: string;
  startLba: number;
  endLba: number;
  sectorCount: number;
  sizeBytes: number;
  flags: number;                 // 0 = file, 2 = directory, etc.
  isDirectory: boolean;
  recordingDate: string;
  contentHashSha256: string;
  contentSample?: string;
  mimeType: string;
  isCorrupted?: boolean;
}

export interface ISODirectoryRecord {
  name: string;
  path: string;
  lba: number;
  sizeBytes: number;
  entries: ISOFileRecord[];
  subdirectories: ISODirectoryRecord[];
}

export interface VolumeDescriptors {
  systemIdentifier: string;
  volumeIdentifier: string;
  volumeSetIdentifier: string;
  publisherIdentifier: string;
  dataPreparerIdentifier: string;
  applicationIdentifier: string;
  copyrightFileIdentifier: string;
  volumeSpaceSize: number;       // In sectors
  logicalBlockSize: number;      // 2048 bytes
  pathTableSize: number;
  typeLPathTableLba: number;
  typeMPathTableLba: number;
  creationDate: string;
  modificationDate: string;
  expirationDate: string;
  effectiveDate: string;
  hasJolietExtension: boolean;
  hasRockRidgeExtension: boolean;
  hasElToritoBoot: boolean;
}

export interface Disc {
  discId: string;
  volumeLabel: string;
  discType: DiscType;
  geometry: DiscGeometry;
  totalSectors: number;
  usedSectors: number;
  sessions: Session[];
  tracks: Track[];
  sectors: Sector[];             // Real sector table/cache
  volumeDescriptors: VolumeDescriptors;
  rootDirectory: ISODirectoryRecord;
  files: ISOFileRecord[];
  
  // Cryptographic & forensic hashes
  imageHashSha256: string;
  imageHashSha512: string;
  imageHashMd5: string;
  imageHashCrc32: string;
  
  // Health & Simulation state
  healthScorePercent: number;
  corruptedSectorCount: number;
  correctedSectorCount: number;
  uncorrectableSectorCount: number;
  agingYears: number;
  surfaceScratchCount: number;
}

export interface DriveProfile {
  modelName: string;
  maxSpeed: SpeedMultiplier;
  rotationType: 'CLV' | 'CAV' | 'PCAV';
  bufferSizeBytes: number;       // e.g. 512 KB
  maxRetries: number;
  avgSeekLatencyMs: number;
  fullStrokeSeekLatencyMs: number;
  spinUpTimeMs: number;
  spinDownTimeMs: number;
}

export interface DriveTelemetry {
  state: DriveState;
  currentSpeed: SpeedMultiplier;
  currentRpm: number;
  targetRpm: number;
  angularVelocityRadS: number;
  currentHeadLba: number;
  currentHeadRadiusMm: number;
  laserDiodeCurrentMa: number;
  laserPowerMilliWatts: number;
  focusErrorSignal: number;      // S-curve voltage
  trackingErrorSignal: number;   // Push-pull tracking error
  rfSignalAmplitude: number;     // Eye pattern voltage (0 to 1.2V)
  bufferUsedBytes: number;
  bufferCapacityBytes: number;
  bufferUtilizationPercent: number;
  currentTransferRateKbps: number;
  activeWorkload: string;
  retriesPerformed: number;
  isSpindleSpinning: boolean;
  trayOpen: boolean;
  acousticsActive: boolean;
}

export interface ScratchDef {
  id: string;
  startXmm: number;
  startYmm: number;
  endXmm: number;
  endYmm: number;
  widthUm: number;             // Width in microns (e.g. 200 µm)
  depthUm: number;             // Depth in microns
  severity: number;            // 0.1 to 1.0
  description: string;
  affectedSectorsCount: number;
}

export interface DegradationProfile {
  ageYears: number;
  storageTempCelsius: number;
  relativeHumidityPercent: number;
  laserRotOxidation: number;     // 0.0 to 1.0
  polycarbonateHaze: number;     // 0.0 to 1.0
  reflectivePinholeDensity: number; // per cm²
  jitterIncreasePercent: number;
}

export interface ForensicReport {
  reportId: string;
  timestamp: string;
  discIdentifier: string;
  volumeLabel: string;
  totalCapacityBytes: number;
  totalSectors: number;
  usedSectors: number;
  freeSectors: number;
  hashes: {
    sha256: string;
    sha512: string;
    md5: string;
    crc32: string;
  };
  volumeDescriptors: VolumeDescriptors;
  directoryCount: number;
  fileCount: number;
  sectorIntegrity: {
    healthySectors: number;
    correctedSectors: number;
    uncorrectableSectors: number;
    corruptedSectors: number;
    orphanSectors: number;
    slackSpaceBytes: number;
  };
  filesInventory: {
    path: string;
    size: number;
    startLba: number;
    endLba: number;
    sha256: string;
    status: 'INTACT' | 'DAMAGED';
  }[];
  anomaliesFound: string[];
  signature: string;
}

export interface SimulationEvent {
  id: string;
  timestamp: number;
  type: 
    | 'DISC_CREATED' 
    | 'ISO_BUILT' 
    | 'DISC_MOUNTED' 
    | 'DISC_EJECTED' 
    | 'SPINDLE_SPIN_UP' 
    | 'SEEK_START' 
    | 'SEEK_COMPLETE' 
    | 'SECTOR_READ' 
    | 'SECTOR_ERROR' 
    | 'ECC_CORRECTION' 
    | 'SECTOR_UNCORRECTABLE' 
    | 'READ_RETRY' 
    | 'CORRUPTION_INJECTED' 
    | 'SCRATCH_APPLIED' 
    | 'AGING_SIMULATED' 
    | 'FORENSIC_AUDIT'
    | 'FILE_READ';
  message: string;
  details?: Record<string, unknown>;
}
