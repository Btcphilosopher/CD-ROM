// AUREOM CD-ROM DISC GEOMETRY ENGINE
// Archimedean Spiral, Physical Dimensions, CLV/CAV Kinematics, and Sector Mapping

import { DiscGeometry } from './models';

export const STANDARD_74MIN_GEOMETRY: DiscGeometry = {
  outerRadiusMm: 60.0,
  innerRadiusMm: 7.5,
  clampingRadiusMm: 13.0,
  leadInStartRadiusMm: 23.0,
  leadInEndRadiusMm: 25.0, // LBA 0 starts at r = 25.0 mm
  programEndRadiusMm: 58.0,
  leadOutEndRadiusMm: 59.5,
  thicknessMm: 1.2,
  trackPitchUm: 1.6, // 1.6 micrometers
  linearVelocityMs: 1.3, // 1.3 m/s nominal at 1x
  totalCapacityMb: 650,
  maxSectors: 333000, // 74 minutes * 60 sec * 75 frames = 333,000 sectors
};

export const STANDARD_80MIN_GEOMETRY: DiscGeometry = {
  outerRadiusMm: 60.0,
  innerRadiusMm: 7.5,
  clampingRadiusMm: 13.0,
  leadInStartRadiusMm: 23.0,
  leadInEndRadiusMm: 25.0,
  programEndRadiusMm: 58.5,
  leadOutEndRadiusMm: 59.5,
  thicknessMm: 1.2,
  trackPitchUm: 1.5, // tighter track pitch for 700MB
  linearVelocityMs: 1.2,
  totalCapacityMb: 700,
  maxSectors: 360000, // 80 minutes
};

export interface PolarCoord {
  radiusMm: number;
  thetaRad: number;
  revolutions: number;
}

export interface CartesianCoord {
  xMm: number;
  yMm: number;
  zMm: number;
}

export class DiscGeometryEngine {
  /**
   * Converts LBA (Logical Block Address) to MSF string "MM:SS:FF"
   * Note: CD-ROM LBA 0 corresponds to 00:02:00 (150 frame 2-sec lead-in pregap)
   */
  public static lbaToMsf(lba: number): string {
    const totalFrames = lba + 150;
    if (totalFrames < 0) {
      return '00:00:00';
    }
    const minute = Math.floor(totalFrames / (60 * 75));
    const rem = totalFrames % (60 * 75);
    const second = Math.floor(rem / 75);
    const frame = rem % 75;

    const mStr = minute.toString().padStart(2, '0');
    const sStr = second.toString().padStart(2, '0');
    const fStr = frame.toString().padStart(2, '0');
    return `${mStr}:${sStr}:${fStr}`;
  }

  /**
   * Converts MSF string or values to LBA
   */
  public static msfToLba(minute: number, second: number, frame: number): number {
    return (minute * 60 + second) * 75 + frame - 150;
  }

  /**
   * Calculates exact physical polar coordinates (radius, angle) of a sector on the Archimedean spiral
   * Archimedean spiral equation: r(theta) = r0 + (pitch / (2*PI)) * theta
   * Total track length L(theta) approx = PI * (r(theta)^2 - r0^2) / pitch
   * Sector linear length dL = velocity / 75 Hz approx 17.33 mm
   */
  public static lbaToPolar(lba: number, geometry: DiscGeometry = STANDARD_74MIN_GEOMETRY): PolarCoord {
    const r0 = geometry.leadInEndRadiusMm; // 25.0 mm
    const pitchMm = geometry.trackPitchUm / 1000.0; // 0.0016 mm
    const sectorLinearLenMm = (geometry.linearVelocityMs * 1000.0) / 75.0; // ~17.33 mm per sector

    // Total distance along the spiral track to this sector
    const currentTrackLengthMm = lba * sectorLinearLenMm;

    // From L(r) = PI * (r^2 - r0^2) / pitch  =>  r = sqrt(r0^2 + (L * pitch / PI))
    const rSquared = r0 * r0 + (currentTrackLengthMm * pitchMm) / Math.PI;
    const radiusMm = Math.min(Math.sqrt(rSquared), geometry.programEndRadiusMm);

    // Theta from Archimedean spiral: theta = 2 * PI * (r - r0) / pitch
    const thetaRad = (2.0 * Math.PI * (radiusMm - r0)) / pitchMm;
    const revolutions = (radiusMm - r0) / pitchMm;

    return {
      radiusMm,
      thetaRad,
      revolutions,
    };
  }

  /**
   * Converts Polar Coordinate to 2D/3D Cartesian (x, y) in mm
   */
  public static polarToCartesian(polar: PolarCoord): CartesianCoord {
    return {
      xMm: polar.radiusMm * Math.cos(polar.thetaRad),
      yMm: polar.radiusMm * Math.sin(polar.thetaRad),
      zMm: 0,
    };
  }

  /**
   * Calculates spindle motor RPM for Constant Linear Velocity (CLV) at a given LBA or radius
   * v = omega * r = (2 * PI * RPM / 60) * r
   * => RPM = (60 * v) / (2 * PI * r)
   */
  public static calculateRpm(
    radiusMm: number,
    speedMultiplier = 1,
    geometry: DiscGeometry = STANDARD_74MIN_GEOMETRY
  ): number {
    const rMeters = Math.max(radiusMm, geometry.leadInStartRadiusMm) / 1000.0;
    const vLinear = geometry.linearVelocityMs * speedMultiplier;
    const rpm = (60.0 * vLinear) / (2.0 * Math.PI * rMeters);
    return Math.round(rpm);
  }

  /**
   * Calculates optical pickup radial seek time in milliseconds
   * SLED stepper motor acceleration + travel: t = t_startup + k * sqrt(delta_r)
   */
  public static calculateSeekTimeMs(fromLba: number, toLba: number, geometry: DiscGeometry = STANDARD_74MIN_GEOMETRY): number {
    const fromPolar = this.lbaToPolar(fromLba, geometry);
    const toPolar = this.lbaToPolar(toLba, geometry);
    const deltaRadiusMm = Math.abs(toPolar.radiusMm - fromPolar.radiusMm);

    if (deltaRadiusMm < 0.01) {
      return 0.5; // Track-to-track micro-jump
    }

    const tStartup = 8.0; // Stepper motor inertia & lock
    const kSled = 14.5; // Sled mechanical velocity constant
    return tStartup + kSled * Math.sqrt(deltaRadiusMm);
  }

  /**
   * Calculates theoretical throughput in KB/s for a given speed multiplier and drive mode
   */
  public static calculateThroughputKbps(speedMultiplier: number, dataMode: 1 | 2 = 1): number {
    // 1x CD-ROM Mode 1 = 75 sectors/sec * 2048 bytes = 153,600 bytes/sec = 150 KB/s
    // Mode 2 Form 2 = 75 sectors/sec * 2324 bytes = 170.2 KB/s
    const baseBytesPerSec = dataMode === 1 ? 153600 : 174300;
    return (baseBytesPerSec * speedMultiplier) / 1024;
  }
}
