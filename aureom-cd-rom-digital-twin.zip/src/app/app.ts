// AUREOM CD-ROM DIGITAL TWIN & SIMULATOR
// Main Application Component

import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { OpticalLaboratoryService, WorkspaceTab } from './services/optical-laboratory.service';

import { ThreeDiscView } from './components/three-disc-view';
import { SectorMicroscope } from './components/sector-microscope';
import { SectorHexEditor } from './components/sector-hex-editor';
import { FilesystemTree } from './components/filesystem-tree';
import { VirtualDrivePanel } from './components/virtual-drive-panel';
import { CorruptionLabPanel } from './components/corruption-lab-panel';
import { EccLabPanel } from './components/ecc-lab-panel';
import { ForensicSuitePanel } from './components/forensic-suite-panel';
import { AuthoringStudioPanel } from './components/authoring-studio-panel';
import { ExperimentWorkbenchPanel } from './components/experiment-workbench-panel';
import { MasterDemoRunner } from './components/master-demo-runner';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    MatIconModule,
    ThreeDiscView,
    SectorMicroscope,
    SectorHexEditor,
    FilesystemTree,
    VirtualDrivePanel,
    CorruptionLabPanel,
    EccLabPanel,
    ForensicSuitePanel,
    AuthoringStudioPanel,
    ExperimentWorkbenchPanel,
    MasterDemoRunner,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  public labService = inject(OpticalLaboratoryService);
  public currentDisc = this.labService.currentDisc;
  public telemetry = this.labService.driveTelemetry;
  public activeTab = this.labService.activeTab;

  public navItems: { id: WorkspaceTab; label: string; icon: string; badge?: string }[] = [
    { id: 'command', label: 'Command Center', icon: 'dashboard' },
    { id: '3d-twin', label: '3D Optical Twin', icon: '3d_rotation' },
    { id: 'sector-map', label: 'Microscope', icon: 'biotech' },
    { id: 'hex-editor', label: 'Raw Sector Hex', icon: 'code' },
    { id: 'filesystem', label: 'ISO 9660 Explorer', icon: 'folder_open' },
    { id: 'drive', label: 'Virtual Drive', icon: 'album' },
    { id: 'corruption', label: 'Degradation Lab', icon: 'gesture' },
    { id: 'ecc-lab', label: 'ECC & CIRC', icon: 'matrix' },
    { id: 'forensics', label: 'Preservation & Diff', icon: 'verified_user' },
    { id: 'authoring', label: 'ISO Authoring', icon: 'precision_manufacturing' },
    { id: 'experiments', label: 'Monte Carlo', icon: 'assessment' },
    { id: 'master-demos', label: 'Master Scenarios', icon: 'auto_awesome', badge: '4 LABS' },
  ];

  public setTab(tab: WorkspaceTab): void {
    this.labService.activeTab.set(tab);
  }
}
