// AUREOM OPTICAL LABORATORY SERVICE
// Central Signal-Based State Service & Engine Orchestrator

import { Injectable, signal, computed } from '@angular/core';
import { 
  Disc, 
  Sector, 
  ISOFileRecord, 
  DriveTelemetry, 
  SimulationEvent, 
  SpeedMultiplier, 
  ScratchDef, 
  DegradationProfile, 
  ForensicReport
} from '../core/models';
import { Iso9660Engine } from '../core/iso9660';
import { VirtualOpticalDrive, ReadResult } from '../core/virtual-drive';
import { CorruptionLab } from '../core/corruption-lab';
import { ForensicsEngine, ImageDiffResult } from '../core/forensics';

export type WorkspaceTab = 
  | 'command' 
  | '3d-twin' 
  | 'sector-map' 
  | 'hex-editor' 
  | 'filesystem' 
  | 'drive' 
  | 'corruption' 
  | 'ecc-lab' 
  | 'forensics' 
  | 'authoring' 
  | 'experiments' 
  | 'master-demos';

export interface ExperimentRunResult {
  runId: string;
  speed: SpeedMultiplier;
  totalReads: number;
  successfulReads: number;
  correctedReads: number;
  uncorrectableReads: number;
  avgSeekLatencyMs: number;
  avgReadTimeMs: number;
  effectiveThroughputKbps: number;
  recoveryRatePercent: number;
}

@Injectable({
  providedIn: 'root',
})
export class OpticalLaboratoryService {
  // Primary Canonical Disc State
  public currentDisc = signal<Disc>(Iso9660Engine.generateMasterSyntheticDisc());
  public baselineDisc = signal<Disc>(Iso9660Engine.generateMasterSyntheticDisc());

  // Virtual Optical Drive
  private virtualDriveInstance = new VirtualOpticalDrive(this.currentDisc());
  public driveTelemetry = signal<DriveTelemetry>(this.virtualDriveInstance.getTelemetry());

  // Active Inspectors
  public activeSector = signal<Sector>(this.currentDisc().sectors[16]); // Start at PVD LBA 16
  public selectedFile = signal<ISOFileRecord | null>(this.currentDisc().files[0]);
  
  // Navigation & 3D Viewport State
  public activeTab = signal<WorkspaceTab>('command');
  public cameraPreset = signal<'orbit' | 'top' | 'side' | 'cross-section' | 'microscopic' | 'exploded'>('orbit');
  public explodedOffset = signal<number>(0); // 0 (flat) to 1.0 (fully exploded layers)
  public microZoomLevel = signal<number>(1); // 1 = Macro Disc (120mm) to 5 = EFM Pit/Land microscopic

  // Telemetry, Events & Forensics
  public events = signal<SimulationEvent[]>([]);
  public lastReadResult = signal<ReadResult | null>(null);
  public lastForensicReport = signal<ForensicReport | null>(null);
  public lastImageDiff = signal<ImageDiffResult | null>(null);
  public experimentHistory = signal<ExperimentRunResult[]>([]);

  // Simulation Running State
  public isRunningScenario = signal<boolean>(false);
  public scenarioStepText = signal<string>('');
  public scenarioProgress = signal<number>(0);

  // Computed Properties
  public totalCapacityMb = computed(() => this.currentDisc().geometry.totalCapacityMb);
  public usedCapacityMb = computed(() => (this.currentDisc().usedSectors * 2048) / (1024 * 1024));
  public usedPercentage = computed(() => Math.min(100, (this.currentDisc().usedSectors / this.currentDisc().totalSectors) * 100));

  constructor() {
    this.addEvent('DISC_CREATED', `Mounted Master Synthetic CD: ${this.currentDisc().volumeLabel} (650MB / 74-min Mode 1)`, {
      sectors: this.currentDisc().usedSectors,
      files: this.currentDisc().files.length,
    });

    // Start background telemetry polling loop for drive state & motor simulation
    setInterval(() => {
      this.updateDriveTelemetry();
    }, 100);
  }

  private updateDriveTelemetry(): void {
    this.driveTelemetry.set(this.virtualDriveInstance.getTelemetry());
  }

  public addEvent(type: SimulationEvent['type'], message: string, details?: Record<string, unknown>): void {
    const newEvent: SimulationEvent = {
      id: `evt_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      type,
      message,
      details,
    };
    this.events.update(list => [newEvent, ...list.slice(0, 99)]);
  }

  // --- Disc Actions ---
  public resetToPristineMasterDisc(): void {
    const master = Iso9660Engine.generateMasterSyntheticDisc();
    this.currentDisc.set(master);
    this.baselineDisc.set(Iso9660Engine.generateMasterSyntheticDisc());
    this.virtualDriveInstance.mountDisc(master);
    this.activeSector.set(master.sectors[16]);
    this.selectedFile.set(master.files[0]);
    this.lastReadResult.set(null);
    this.lastForensicReport.set(null);
    this.lastImageDiff.set(null);
    this.addEvent('DISC_CREATED', 'Reset virtual disc to pristine factory state.');
  }

  public selectSectorByLba(lba: number): void {
    const disc = this.currentDisc();
    const sector = disc.sectors.find(s => s.lba === lba);
    if (sector) {
      this.activeSector.set(sector);
    }
  }

  public selectFile(file: ISOFileRecord): void {
    this.selectedFile.set(file);
    this.selectSectorByLba(file.startLba);
  }

  // --- Drive Controls ---
  public readSector(lba: number): ReadResult {
    const result = this.virtualDriveInstance.readSector(lba);
    this.lastReadResult.set(result);
    this.activeSector.set(result.sector);
    this.updateDriveTelemetry();

    if (result.eccResult?.correctedBytesCount > 0) {
      this.addEvent('ECC_CORRECTION', `LBA ${lba}: Corrected ${result.eccResult.correctedBytesCount} symbol errors via Reed-Solomon P/Q parity.`);
    } else if (result.eccResult?.uncorrectable) {
      this.addEvent('SECTOR_UNCORRECTABLE', `LBA ${lba}: Reed-Solomon decoder reported uncorrectable error (EDC failed).`);
    } else {
      this.addEvent('SECTOR_READ', `LBA ${lba} read success (${result.sector.allocatedPath || 'Free space'}) in ${result.seekTimeMs.toFixed(1)}ms seek + ${result.readTimeMs.toFixed(1)}ms read.`);
    }

    return result;
  }

  public setDriveSpeed(speed: SpeedMultiplier): void {
    this.virtualDriveInstance.setSpeed(speed);
    this.updateDriveTelemetry();
    this.addEvent('SPINDLE_SPIN_UP', `Drive speed profile switched to ${speed}x (${speed * 150} KB/s theoretical).`);
  }

  public toggleDriveTray(): void {
    if (this.driveTelemetry().trayOpen) {
      this.virtualDriveInstance.closeTray();
      this.addEvent('DISC_MOUNTED', 'Drive tray closed and clamped onto spindle.');
    } else {
      this.virtualDriveInstance.ejectTray();
      this.addEvent('DISC_EJECTED', 'Drive tray ejected.');
    }
    this.updateDriveTelemetry();
  }

  public toggleAcoustics(): void {
    const current = this.virtualDriveInstance.isSoundEnabled();
    this.virtualDriveInstance.setSoundEnabled(!current);
    this.updateDriveTelemetry();
  }

  // --- Corruption Lab ---
  public applyPhysicalScratch(scratch: ScratchDef): void {
    const res = CorruptionLab.applyScratch(this.currentDisc(), scratch);
    this.currentDisc.set({ ...this.currentDisc() });
    this.addEvent('SCRATCH_APPLIED', `Physical scratch applied (${scratch.description}): damaged ${res.affectedSectors.length} sectors. Affected files: ${res.damagedFiles.join(', ') || 'None'}`);
  }

  public simulateDiscAging(profile: DegradationProfile): void {
    const res = CorruptionLab.simulateAging(this.currentDisc(), profile);
    this.currentDisc.set({ ...this.currentDisc() });
    this.addEvent('AGING_SIMULATED', `Simulated ${profile.ageYears} years aging at ${profile.storageTempCelsius}°C / ${profile.relativeHumidityPercent}% RH: ${res.newCorruptedSectors} newly degraded sectors. Health: ${res.healthScore}%`);
  }

  public injectSectorCorruption(lba: number, byteCount = 30): void {
    const sector = CorruptionLab.injectSectorError(this.currentDisc(), lba, byteCount);
    if (sector) {
      this.currentDisc.set({ ...this.currentDisc() });
      this.activeSector.set(sector);
      this.addEvent('CORRUPTION_INJECTED', `Injected ${byteCount} corrupted bytes into Sector LBA ${lba} (${sector.allocatedPath || 'Free space'}).`);
    }
  }

  // --- Forensics & Differentials ---
  public runForensicAudit(): ForensicReport {
    const report = ForensicsEngine.generateForensicReport(this.currentDisc());
    this.lastForensicReport.set(report);
    this.addEvent('FORENSIC_AUDIT', `Forensic audit complete: ${report.sectorIntegrity.healthySectors} healthy, ${report.sectorIntegrity.corruptedSectors} corrupted, ${report.sectorIntegrity.uncorrectableSectors} uncorrectable.`);
    return report;
  }

  public compareWithBaseline(): ImageDiffResult {
    const diff = ForensicsEngine.compareDiscs(this.baselineDisc(), this.currentDisc());
    this.lastImageDiff.set(diff);
    return diff;
  }

  // --- Monte Carlo Experiment Engine ---
  public runMonteCarloBatch(readsCount = 100): ExperimentRunResult {
    const speed = this.driveTelemetry().currentSpeed;
    const sectors = this.currentDisc().sectors;
    let successful = 0;
    let corrected = 0;
    let uncorrectable = 0;
    let totalSeekMs = 0;
    let totalReadMs = 0;

    for (let i = 0; i < readsCount; i++) {
      const randomLba = Math.floor(Math.random() * sectors.length);
      const res = this.readSector(randomLba);
      if (res.success) {
        successful++;
        if (res.eccResult?.correctedBytesCount > 0) corrected++;
      } else {
        uncorrectable++;
      }
      totalSeekMs += res.seekTimeMs;
      totalReadMs += res.readTimeMs;
    }

    const runResult: ExperimentRunResult = {
      runId: `EXP-${Date.now().toString(36).toUpperCase()}`,
      speed,
      totalReads: readsCount,
      successfulReads: successful,
      correctedReads: corrected,
      uncorrectableReads: uncorrectable,
      avgSeekLatencyMs: totalSeekMs / readsCount,
      avgReadTimeMs: totalReadMs / readsCount,
      effectiveThroughputKbps: ((successful * 2048) / ((totalSeekMs + totalReadMs) / 1000)) / 1024,
      recoveryRatePercent: Math.round((successful / readsCount) * 100),
    };

    this.experimentHistory.update(list => [runResult, ...list]);
    return runResult;
  }

  // --- Master Demonstration Scenarios ---
  public async runScenario1FullLifecycle(): Promise<void> {
    this.isRunningScenario.set(true);
    this.scenarioProgress.set(0);

    const step = async (text: string, progress: number, delayMs = 1200) => {
      this.scenarioStepText.set(text);
      this.scenarioProgress.set(progress);
      await new Promise(r => setTimeout(r, delayMs));
    };

    try {
      await step('Step 1/10: Initializing Disc Engine & Geometry...', 10);
      this.resetToPristineMasterDisc();
      this.activeTab.set('command');

      await step('Step 2/10: Building ISO 9660 Primary Volume Descriptor & Path Tables...', 20);
      this.activeTab.set('filesystem');

      await step('Step 3/10: Mounting Virtual Disc onto Spindle & Spinning Up to 24x...', 30);
      this.activeTab.set('drive');
      this.virtualDriveInstance.spinUp();

      await step('Step 4/10: Traversing ISO 9660 Directory Tree & Selecting /README.TXT...', 40);
      const readme = this.currentDisc().files.find(f => f.path === '/README.TXT');
      if (readme) this.selectFile(readme);

      await step('Step 5/10: Tracing File Extents to Sector LBA 22 and Inspecting Raw Mode 1 Hex...', 50);
      this.activeTab.set('hex-editor');
      this.selectSectorByLba(22);

      await step('Step 6/10: Optical Head Seeking to LBA 22 and Reading Sector...', 60);
      this.readSector(22);

      await step('Step 7/10: Injecting Physical Scratch & 24 Corrupted Bytes into LBA 22...', 70);
      this.activeTab.set('corruption');
      this.injectSectorCorruption(22, 24);

      await step('Step 8/10: Triggering Read Retry & Reed-Solomon P/Q Parity Correction...', 80);
      this.activeTab.set('ecc-lab');
      this.readSector(22);

      await step('Step 9/10: Executing Cryptographic Forensic Audit & Verification...', 90);
      this.activeTab.set('forensics');
      this.runForensicAudit();
      this.compareWithBaseline();

      await step('Step 10/10: Scenario Complete! Disc verified, ECC corrected, audit signed.', 100, 1500);
    } finally {
      this.isRunningScenario.set(false);
    }
  }

  public async runScenario2RecoveryExperiment(): Promise<void> {
    this.isRunningScenario.set(true);
    this.scenarioProgress.set(0);

    const step = async (text: string, progress: number, delayMs = 1000) => {
      this.scenarioStepText.set(text);
      this.scenarioProgress.set(progress);
      await new Promise(r => setTimeout(r, delayMs));
    };

    try {
      await step('Initializing fresh disc image...', 15);
      this.resetToPristineMasterDisc();
      this.activeTab.set('corruption');

      await step('Applying 15-year thermal degradation + 2 surface scratches...', 35);
      this.simulateDiscAging({
        ageYears: 15,
        storageTempCelsius: 30,
        relativeHumidityPercent: 65,
        laserRotOxidation: 0.25,
        polycarbonateHaze: 0.2,
        reflectivePinholeDensity: 4,
        jitterIncreasePercent: 20,
      });

      this.applyPhysicalScratch({
        id: 'sc1',
        startXmm: 26,
        startYmm: 10,
        endXmm: 52,
        endYmm: 20,
        widthUm: 220,
        depthUm: 45,
        severity: 0.75,
        description: 'Deep tangential handling scratch',
        affectedSectorsCount: 0,
      });

      await step('Running 200 simulated sector reads with automated retry & ECC...', 65);
      this.activeTab.set('experiments');
      const res = this.runMonteCarloBatch(200);

      await step(`Experiment complete! Recovery Rate: ${res.recoveryRatePercent}%. Uncorrectable: ${res.uncorrectableReads}`, 100, 2000);
    } finally {
      this.isRunningScenario.set(false);
    }
  }

  public async runScenario3SpeedBenchmark(): Promise<void> {
    this.isRunningScenario.set(true);
    this.scenarioProgress.set(0);

    const step = async (text: string, progress: number, delayMs = 900) => {
      this.scenarioStepText.set(text);
      this.scenarioProgress.set(progress);
      await new Promise(r => setTimeout(r, delayMs));
    };

    try {
      this.activeTab.set('experiments');
      const speeds: SpeedMultiplier[] = [1, 4, 16, 32, 52];
      for (let i = 0; i < speeds.length; i++) {
        const sp = speeds[i];
        this.setDriveSpeed(sp);
        await step(`Testing ${sp}x profile (${sp * 150} KB/s nominal)...`, Math.round(((i + 1) / speeds.length) * 100));
        this.runMonteCarloBatch(50);
      }
      await step('All speed profiles benchmarked successfully!', 100, 1500);
    } finally {
      this.isRunningScenario.set(false);
    }
  }

  public async runScenario4PreservationWorkflow(): Promise<void> {
    this.isRunningScenario.set(true);
    this.scenarioProgress.set(0);

    const step = async (text: string, progress: number, delayMs = 1000) => {
      this.scenarioStepText.set(text);
      this.scenarioProgress.set(progress);
      await new Promise(r => setTimeout(r, delayMs));
    };

    try {
      this.activeTab.set('forensics');
      await step('Ingesting Disc Image and calculating SHA-256 / SHA-512 / CRC-32 digests...', 25);
      await step('Scanning for sector anomalies, slack space, and directory record timestamps...', 50);
      const report = this.runForensicAudit();
      await step(`Preservation report generated: ID ${report.reportId} with cryptographic seal.`, 100, 2000);
    } finally {
      this.isRunningScenario.set(false);
    }
  }
}
