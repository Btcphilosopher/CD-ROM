// AUREOM DATA CORRUPTION & DISC DEGRADATION LAB PANEL
// Interactive Physical Scratch Drawing, Arrhenius Aging Kinetics, Burst Defect Injection

import { Component, ElementRef, ViewChild, AfterViewInit, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { OpticalLaboratoryService } from '../services/optical-laboratory.service';
import { DegradationProfile, ScratchDef } from '../core/models';

@Component({
  selector: 'app-corruption-lab-panel',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
      <!-- Left Column: Interactive Scratch Canvas & Presets -->
      <div class="lg:col-span-6 bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-4">
        <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div class="flex items-center gap-2">
            <div class="p-2 bg-rose-500/10 text-rose-400 rounded-xl">
              <mat-icon>gesture</mat-icon>
            </div>
            <div>
              <h3 class="font-display font-semibold text-sm text-neutral-100">Physical Scratch Laboratory</h3>
              <p class="text-[11px] text-neutral-400 font-mono">Click & drag on disc surface to carve real physical scratches</p>
            </div>
          </div>
          <span class="text-xs font-mono px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20">
            {{ disc().surfaceScratchCount }} Scratches Applied
          </span>
        </div>

        <!-- 2D Interactive Disc Drawing Canvas -->
        <div class="relative w-full h-64 bg-neutral-950 rounded-xl border border-neutral-800 flex items-center justify-center overflow-hidden">
          <canvas #scratchCanvas 
                  (mousedown)="startScratch($event)"
                  (mousemove)="drawScratch($event)"
                  (mouseup)="endScratch($event)"
                  class="w-full h-full cursor-crosshair"></canvas>
          <div class="absolute bottom-2 left-2 text-[10px] font-mono text-neutral-500 bg-neutral-950/80 px-2 py-1 rounded">
            Drag across program area (r=25mm to 58mm)
          </div>
        </div>

        <!-- Scratch Presets -->
        <div class="flex flex-col gap-2 font-mono text-xs">
          <span class="text-neutral-400">Standard Forensic Scratch Presets:</span>
          <div class="grid grid-cols-2 gap-2">
            <button (click)="applyPresetScratch('tangential')"
                    class="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 hover:border-rose-500/40 text-left transition-all group">
              <span class="text-neutral-200 font-semibold group-hover:text-rose-400 block">Tangential Scratch</span>
              <span class="text-[10px] text-neutral-500">Affects multiple consecutive LBAs along spiral</span>
            </button>
            <button (click)="applyPresetScratch('radial')"
                    class="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 hover:border-rose-500/40 text-left transition-all group">
              <span class="text-neutral-200 font-semibold group-hover:text-rose-400 block">Radial Deep Gouge</span>
              <span class="text-[10px] text-neutral-500">Crosses all tracks from lead-in to outer rim</span>
            </button>
            <button (click)="applyPresetScratch('clamping')"
                    class="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 hover:border-rose-500/40 text-left transition-all group">
              <span class="text-neutral-200 font-semibold group-hover:text-rose-400 block">Inner Hub Microfracture</span>
              <span class="text-[10px] text-neutral-500">Damages PVD and Path Tables (LBA 16-20)</span>
            </button>
            <button (click)="applyPresetScratch('edge')"
                    class="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 hover:border-rose-500/40 text-left transition-all group">
              <span class="text-neutral-200 font-semibold group-hover:text-rose-400 block">Edge Delamination</span>
              <span class="text-[10px] text-neutral-500">Outer rim oxidation and lacquer peeling</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Right Column: Environmental Arrhenius Aging & Disc Rot Simulator -->
      <div class="lg:col-span-6 flex flex-col gap-4">
        <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-4">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
            <div class="flex items-center gap-2">
              <div class="p-2 bg-amber-500/10 text-amber-400 rounded-xl">
                <mat-icon>hourglass_bottom</mat-icon>
              </div>
              <div>
                <h3 class="font-display font-semibold text-sm text-neutral-100">Arrhenius Degradation & Disc Rot</h3>
                <p class="text-[11px] text-neutral-400 font-mono">Thermodynamic hydrolysis, laser rot pinholes & polycarbonate aging</p>
              </div>
            </div>
            <div class="text-right">
              <span class="text-xs font-mono font-bold block"
                    [class.text-emerald-400]="disc().healthScorePercent >= 80"
                    [class.text-amber-400]="disc().healthScorePercent >= 50 && disc().healthScorePercent < 80"
                    [class.text-rose-400]="disc().healthScorePercent < 50">
                HEALTH: {{ disc().healthScorePercent }}%
              </span>
            </div>
          </div>

          <!-- Aging Sliders -->
          <div class="flex flex-col gap-3 font-mono text-xs">
            <!-- Age in Years -->
            <div class="flex flex-col gap-1">
              <div class="flex items-center justify-between text-neutral-300">
                <span>Age of Media:</span>
                <span class="text-cyan-400 font-bold">{{ agingProfile.ageYears }} Years</span>
              </div>
              <input type="range" min="0" max="50" step="1" [(ngModel)]="agingProfile.ageYears" class="w-full cursor-pointer" />
            </div>

            <!-- Temperature -->
            <div class="flex flex-col gap-1">
              <div class="flex items-center justify-between text-neutral-300">
                <span>Storage Temperature:</span>
                <span class="text-amber-400 font-bold">{{ agingProfile.storageTempCelsius }} °C</span>
              </div>
              <input type="range" min="15" max="50" step="1" [(ngModel)]="agingProfile.storageTempCelsius" class="w-full cursor-pointer" />
            </div>

            <!-- Humidity -->
            <div class="flex flex-col gap-1">
              <div class="flex items-center justify-between text-neutral-300">
                <span>Relative Humidity (RH):</span>
                <span class="text-cyan-400 font-bold">{{ agingProfile.relativeHumidityPercent }} %</span>
              </div>
              <input type="range" min="20" max="95" step="1" [(ngModel)]="agingProfile.relativeHumidityPercent" class="w-full cursor-pointer" />
            </div>

            <!-- Laser Rot Oxidation Pinholes -->
            <div class="flex flex-col gap-1">
              <div class="flex items-center justify-between text-neutral-300">
                <span>Aluminum Layer Laser Rot (Oxidation):</span>
                <span class="text-rose-400 font-bold">{{ (agingProfile.laserRotOxidation * 100).toFixed(0) }} %</span>
              </div>
              <input type="range" min="0" max="1" step="0.05" [(ngModel)]="agingProfile.laserRotOxidation" class="w-full cursor-pointer" />
            </div>

            <!-- Polycarbonate Haze -->
            <div class="flex flex-col gap-1">
              <div class="flex items-center justify-between text-neutral-300">
                <span>Polycarbonate Yellowing / Haze:</span>
                <span class="text-amber-400 font-bold">{{ (agingProfile.polycarbonateHaze * 100).toFixed(0) }} %</span>
              </div>
              <input type="range" min="0" max="1" step="0.05" [(ngModel)]="agingProfile.polycarbonateHaze" class="w-full cursor-pointer" />
            </div>

            <button (click)="applyAgingSimulation()"
                    class="mt-2 py-2.5 px-4 rounded-xl bg-amber-500 text-neutral-950 font-bold font-mono hover:bg-amber-400 transition-all flex items-center justify-center gap-2 shadow-lg">
              <mat-icon class="scale-90">science</mat-icon>
              <span>Simulate Kinetic Aging</span>
            </button>
          </div>

          <!-- Impact Summary -->
          <div class="p-3 bg-neutral-950 rounded-xl border border-neutral-800 font-mono text-xs flex flex-col gap-1.5">
            <span class="text-neutral-500">CORRUPTION METRICS:</span>
            <div class="grid grid-cols-3 gap-2 text-center">
              <div class="p-2 bg-neutral-900 rounded-lg">
                <span class="text-[10px] text-neutral-500 block">Corrupted</span>
                <span class="text-rose-400 font-bold">{{ disc().corruptedSectorCount }} Sectors</span>
              </div>
              <div class="p-2 bg-neutral-900 rounded-lg">
                <span class="text-[10px] text-neutral-500 block">ECC Corrected</span>
                <span class="text-amber-400 font-bold">{{ disc().correctedSectorCount }} Sectors</span>
              </div>
              <div class="p-2 bg-neutral-900 rounded-lg">
                <span class="text-[10px] text-neutral-500 block">Uncorrectable</span>
                <span class="text-red-500 font-bold">{{ disc().uncorrectableSectorCount }} Sectors</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class CorruptionLabPanel implements AfterViewInit {
  public labService = inject(OpticalLaboratoryService);
  public disc = this.labService.currentDisc;

  @ViewChild('scratchCanvas') private canvasRef!: ElementRef<HTMLCanvasElement>;

  public agingProfile: DegradationProfile = {
    ageYears: 20,
    storageTempCelsius: 28,
    relativeHumidityPercent: 60,
    laserRotOxidation: 0.15,
    polycarbonateHaze: 0.1,
    reflectivePinholeDensity: 3,
    jitterIncreasePercent: 15,
  };

  private isDrawing = false;
  private startPoint = { x: 0, y: 0 };

  public ngAfterViewInit(): void {
    if (typeof window !== 'undefined') {
      this.renderDiscCanvas();
    }
  }

  private renderDiscCanvas(): void {
    const canvas = this.canvasRef?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = (canvas.width = canvas.clientWidth);
    const h = (canvas.height = canvas.clientHeight);
    const cx = w / 2;
    const cy = h / 2;
    const scale = Math.min(w, h) / 130; // 120mm fits within scale

    ctx.fillStyle = '#0a0c14';
    ctx.fillRect(0, 0, w, h);

    // Outer edge (120mm)
    ctx.beginPath();
    ctx.arc(cx, cy, 60 * scale, 0, Math.PI * 2);
    ctx.fillStyle = '#1e293b';
    ctx.fill();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Program Data Area (25mm to 58mm)
    ctx.beginPath();
    ctx.arc(cx, cy, 58 * scale, 0, Math.PI * 2);
    ctx.arc(cx, cy, 25 * scale, 0, Math.PI * 2, true);
    ctx.fillStyle = '#0f172a';
    ctx.fill();

    // Inner Hole (15mm)
    ctx.beginPath();
    ctx.arc(cx, cy, 7.5 * scale, 0, Math.PI * 2);
    ctx.fillStyle = '#0a0c14';
    ctx.fill();
    ctx.strokeStyle = '#64748b';
    ctx.stroke();
  }

  public startScratch(e: MouseEvent): void {
    this.isDrawing = true;
    const rect = this.canvasRef.nativeElement.getBoundingClientRect();
    this.startPoint = { x: e.clientX - rect.left, y: e.clientY - rect.top };
  }

  public drawScratch(e: MouseEvent): void {
    if (!this.isDrawing) return;
    const canvas = this.canvasRef.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const curX = e.clientX - rect.left;
    const curY = e.clientY - rect.top;

    ctx.strokeStyle = 'rgba(244, 63, 94, 0.8)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(this.startPoint.x, this.startPoint.y);
    ctx.lineTo(curX, curY);
    ctx.stroke();
  }

  public endScratch(e: MouseEvent): void {
    if (!this.isDrawing) return;
    this.isDrawing = false;
    const rect = this.canvasRef.nativeElement.getBoundingClientRect();
    const endX = e.clientX - rect.left;
    const endY = e.clientY - rect.top;

    // Convert pixel coordinates to mm relative to disc center
    const w = this.canvasRef.nativeElement.width;
    const h = this.canvasRef.nativeElement.height;
    const cx = w / 2;
    const cy = h / 2;
    const scale = Math.min(w, h) / 130;

    const startXmm = (this.startPoint.x - cx) / scale;
    const startYmm = (this.startPoint.y - cy) / scale;
    const endXmm = (endX - cx) / scale;
    const endYmm = (endY - cy) / scale;

    const scratch: ScratchDef = {
      id: `scr_${Date.now()}`,
      startXmm,
      startYmm,
      endXmm,
      endYmm,
      widthUm: 180,
      depthUm: 35,
      severity: 0.65,
      description: 'Interactive User Surface Scratch',
      affectedSectorsCount: 0,
    };

    this.labService.applyPhysicalScratch(scratch);
  }

  public applyPresetScratch(type: 'tangential' | 'radial' | 'clamping' | 'edge'): void {
    let scratch: ScratchDef;
    if (type === 'tangential') {
      scratch = {
        id: `sc_tan_${Date.now()}`,
        startXmm: 30,
        startYmm: 15,
        endXmm: 50,
        endYmm: 22,
        widthUm: 200,
        depthUm: 40,
        severity: 0.7,
        description: 'Tangential Spiral Scratch',
        affectedSectorsCount: 0,
      };
    } else if (type === 'radial') {
      scratch = {
        id: `sc_rad_${Date.now()}`,
        startXmm: 24,
        startYmm: 5,
        endXmm: 58,
        endYmm: 25,
        widthUm: 280,
        depthUm: 50,
        severity: 0.85,
        description: 'Radial Full-Radius Gouge',
        affectedSectorsCount: 0,
      };
    } else if (type === 'clamping') {
      scratch = {
        id: `sc_hub_${Date.now()}`,
        startXmm: 25,
        startYmm: 0,
        endXmm: 28,
        endYmm: 4,
        widthUm: 150,
        depthUm: 60,
        severity: 0.9,
        description: 'Inner Hub Clamping Fracture (ISO PVD Risk)',
        affectedSectorsCount: 0,
      };
    } else {
      scratch = {
        id: `sc_edge_${Date.now()}`,
        startXmm: 54,
        startYmm: -10,
        endXmm: 58,
        endYmm: 10,
        widthUm: 350,
        depthUm: 40,
        severity: 0.6,
        description: 'Outer Rim Delamination',
        affectedSectorsCount: 0,
      };
    }

    this.labService.applyPhysicalScratch(scratch);
    this.renderDiscCanvas();
  }

  public applyAgingSimulation(): void {
    this.labService.simulateDiscAging(this.agingProfile);
  }
}
