// AUREOM SECTOR MICROSCOPE & MULTI-SCALE DEEP INSPECTOR
// Zoom hierarchy: Disc (120mm) -> Spiral (1.6µm) -> EFM Pits/Lands (3T-11T) -> Raw Channel Bits -> User Data

import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { OpticalLaboratoryService } from '../services/optical-laboratory.service';

@Component({
  selector: 'app-sector-microscope',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-4 shadow-xl flex flex-col gap-4">
      <!-- Microscope Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 border-b border-neutral-800 pb-3">
        <div class="flex items-center gap-2">
          <div class="p-2 bg-cyan-500/10 text-cyan-400 rounded-xl border border-cyan-500/20">
            <mat-icon class="scale-90">biotech</mat-icon>
          </div>
          <div>
            <h3 class="font-display font-semibold text-sm text-neutral-100">Optical Sector Microscope</h3>
            <p class="text-xs text-neutral-400">Multi-tier deep inspection from 120mm macro disc to 110nm physical pits</p>
          </div>
        </div>

        <!-- Zoom Level Step Buttons -->
        <div class="flex items-center gap-1 bg-neutral-950 p-1 rounded-xl border border-neutral-800 text-xs font-mono">
          <button (click)="setZoom(1)" 
                  class="px-2.5 py-1 rounded-lg transition-all"
                  [class.bg-cyan-500]="zoomLevel() === 1"
                  [class.text-neutral-950]="zoomLevel() === 1"
                  [class.text-neutral-400]="zoomLevel() !== 1">
            L1: 120mm Disc
          </button>
          <button (click)="setZoom(2)" 
                  class="px-2.5 py-1 rounded-lg transition-all"
                  [class.bg-cyan-500]="zoomLevel() === 2"
                  [class.text-neutral-950]="zoomLevel() === 2"
                  [class.text-neutral-400]="zoomLevel() !== 2">
            L2: 1.6µm Spiral
          </button>
          <button (click)="setZoom(3)" 
                  class="px-2.5 py-1 rounded-lg transition-all"
                  [class.bg-cyan-500]="zoomLevel() === 3"
                  [class.text-neutral-950]="zoomLevel() === 3"
                  [class.text-neutral-400]="zoomLevel() !== 3">
            L3: EFM Pits/Lands
          </button>
          <button (click)="setZoom(4)" 
                  class="px-2.5 py-1 rounded-lg transition-all"
                  [class.bg-cyan-500]="zoomLevel() === 4"
                  [class.text-neutral-950]="zoomLevel() === 4"
                  [class.text-neutral-400]="zoomLevel() !== 4">
            L4: Channel Bits
          </button>
          <button (click)="setZoom(5)" 
                  class="px-2.5 py-1 rounded-lg transition-all"
                  [class.bg-cyan-500]="zoomLevel() === 5"
                  [class.text-neutral-950]="zoomLevel() === 5"
                  [class.text-neutral-400]="zoomLevel() !== 5">
            L5: Decoded Sector
          </button>
        </div>
      </div>

      <!-- Microscope Viewport Canvas / Visualization -->
      <div class="relative w-full h-64 bg-neutral-950 rounded-xl overflow-hidden border border-neutral-800 flex items-center justify-center p-4">
        
        <!-- LEVEL 1: 120mm Macro View -->
        @if (zoomLevel() === 1) {
          <div class="relative flex flex-col items-center justify-center text-center">
            <div class="w-44 h-44 rounded-full border-4 border-cyan-500/40 relative flex items-center justify-center bg-gradient-to-tr from-cyan-950/40 via-neutral-900 to-indigo-950/40 shadow-inner">
              <div class="w-16 h-16 rounded-full border-2 border-neutral-700 bg-neutral-950 flex items-center justify-center">
                <span class="text-[10px] font-mono text-neutral-500">15mm Hole</span>
              </div>
              <div class="absolute top-8 right-12 w-3 h-3 rounded-full bg-rose-500 animate-ping"></div>
              <div class="absolute top-8 right-12 w-3 h-3 rounded-full bg-rose-500 flex items-center justify-center"></div>
            </div>
            <div class="mt-3 font-mono text-xs text-neutral-400">
              Target: <span class="text-cyan-400">LBA {{ sector().lba }} ({{ sector().absoluteMsf }})</span> | Radius: <span class="text-emerald-400">{{ sector().physicalRadiusMm.toFixed(2) }} mm</span>
            </div>
          </div>
        }

        <!-- LEVEL 2: 1.6µm Spiral Tracks -->
        @if (zoomLevel() === 2) {
          <div class="w-full flex flex-col gap-3 font-mono">
            <div class="flex items-center justify-between text-xs text-neutral-400">
              <span>Track Pitch: 1.60 µm</span>
              <span>Substrate Refraction: n = 1.55</span>
              <span>Scanning Velocity: 1.30 m/s</span>
            </div>
            <div class="flex flex-col gap-2.5 py-2">
              <div class="h-4 bg-neutral-800/80 rounded-full flex items-center px-3 border border-neutral-700/50">
                <span class="text-[10px] text-neutral-500">Track n-1 (LBA {{ sector().lba - 75 }})</span>
              </div>
              <div class="h-7 bg-cyan-950/60 border border-cyan-500/60 rounded-full flex items-center justify-between px-4 shadow-[0_0_15px_rgba(6,182,212,0.15)]">
                <span class="text-xs text-cyan-300 font-bold">Active Track n (LBA {{ sector().lba }})</span>
                <span class="text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">Laser Spot: 780nm (1.7µm FWHM)</span>
              </div>
              <div class="h-4 bg-neutral-800/80 rounded-full flex items-center px-3 border border-neutral-700/50">
                <span class="text-[10px] text-neutral-500">Track n+1 (LBA {{ sector().lba + 75 }})</span>
              </div>
            </div>
          </div>
        }

        <!-- LEVEL 3: EFM Pits and Lands (3T to 11T) -->
        @if (zoomLevel() === 3) {
          <div class="w-full flex flex-col gap-3 font-mono">
            <div class="flex items-center justify-between text-xs text-neutral-400">
              <span>Pit Depth: 110 nm (λ / 4n Phase Cancellation)</span>
              <span>Pit Width: 500 nm</span>
              <span>Run Length: T=3 to T=11</span>
            </div>
            <!-- Physical Pits / Lands Cross Section Visualizer -->
            <div class="h-20 bg-neutral-900 border border-neutral-800 rounded-lg p-3 flex items-end gap-1 overflow-x-auto">
              @for (pit of samplePits; track $index) {
                <div class="flex flex-col items-center gap-1" [style.width.px]="pit.length * 14">
                  <span class="text-[9px] text-neutral-500">{{ pit.type }}{{ pit.length }}T</span>
                  <div class="w-full rounded-sm transition-all"
                       [class.h-8]="pit.type === 'LAND'"
                       [class.bg-emerald-500/60]="pit.type === 'LAND'"
                       [class.h-2]="pit.type === 'PIT'"
                       [class.bg-neutral-950]="pit.type === 'PIT'"
                       [class.border]="pit.type === 'PIT'"
                       [class.border-cyan-500/50]="pit.type === 'PIT'">
                  </div>
                </div>
              }
            </div>
            <div class="text-[11px] text-neutral-500 text-center">
              Constructive interference (Land: High RF) vs Destructive interference (Pit: Zero RF)
            </div>
          </div>
        }

        <!-- LEVEL 4: Raw 2352-byte Channel Bits -->
        @if (zoomLevel() === 4) {
          <div class="w-full flex flex-col gap-2 font-mono text-xs">
            <div class="flex items-center justify-between text-neutral-400">
              <span class="text-cyan-400 font-semibold">Raw Channel Frame Bitstream</span>
              <span>Modulation: EFM 8-to-14 + 3 Merging Bits (17 Channel Bits/Byte)</span>
            </div>
            <div class="p-3 bg-neutral-950 border border-neutral-800 rounded-lg text-emerald-400 break-all leading-relaxed text-[11px] max-h-40 overflow-y-auto">
              00100000000001000 100000000001000 001000100001000 010001000001000 100100000100000 001000010000010
              100001000001000 001001000001000 000100001000010 100010000001000 010000100000100 001000001000010
              100000000001000 001000100001000 010001000001000 100100000100000 001000010000010 100001000001000
            </div>
          </div>
        }

        <!-- LEVEL 5: Decoded Mode 1 Sector -->
        @if (zoomLevel() === 5) {
          <div class="w-full flex flex-col gap-2 font-mono text-xs">
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div class="p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl">
                <span class="text-[10px] text-neutral-500 block">SYNC (12 Bytes)</span>
                <span class="text-amber-400 font-bold">00 FF..FF 00</span>
              </div>
              <div class="p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl">
                <span class="text-[10px] text-neutral-500 block">HEADER (4 Bytes)</span>
                <span class="text-cyan-400 font-bold">{{ sector().absoluteMsf }} [M{{ sector().mode }}]</span>
              </div>
              <div class="p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl">
                <span class="text-[10px] text-neutral-500 block">EDC (32-Bit CRC)</span>
                <span class="text-emerald-400 font-bold">0x{{ sector().edcCalculated.toString(16).toUpperCase() }}</span>
              </div>
              <div class="p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl">
                <span class="text-[10px] text-neutral-500 block">ECC PARITY</span>
                <span class="text-purple-400 font-bold">172 P + 104 Q</span>
              </div>
            </div>
            <div class="p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl flex items-center justify-between">
              <div>
                <span class="text-neutral-500">Allocation:</span>
                <span class="text-neutral-200 ml-1 font-semibold">{{ sector().allocatedPath || 'Free Space' }}</span>
              </div>
              <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                    [class.bg-emerald-500/20]="sector().status === 'HEALTHY'"
                    [class.text-emerald-400]="sector().status === 'HEALTHY'"
                    [class.bg-rose-500/20]="sector().status === 'CORRUPTED' || sector().status === 'UNCORRECTABLE'"
                    [class.text-rose-400]="sector().status === 'CORRUPTED' || sector().status === 'UNCORRECTABLE'">
                {{ sector().status }}
              </span>
            </div>
          </div>
        }

      </div>
    </div>
  `,
})
export class SectorMicroscope {
  public labService = inject(OpticalLaboratoryService);
  public sector = this.labService.activeSector;
  public zoomLevel = signal<number>(3); // Default to EFM Pits/Lands view

  public samplePits = [
    { type: 'LAND', length: 3 },
    { type: 'PIT', length: 4 },
    { type: 'LAND', length: 6 },
    { type: 'PIT', length: 3 },
    { type: 'LAND', length: 8 },
    { type: 'PIT', length: 11 },
    { type: 'LAND', length: 5 },
    { type: 'PIT', length: 7 },
    { type: 'LAND', length: 4 },
  ];

  public setZoom(level: number): void {
    this.zoomLevel.set(level);
  }
}
