// AUREOM MONTE CARLO EXPERIMENT WORKBENCH & BENCHMARKING
// Batch Read Performance, Throughput Analytics, Seek Latency vs Radius, Error Recovery Curves

import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { OpticalLaboratoryService } from '../services/optical-laboratory.service';

@Component({
  selector: 'app-experiment-workbench-panel',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
      <!-- Left Column: Experiment Controls & Active Benchmark -->
      <div class="lg:col-span-5 flex flex-col gap-4">
        <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-4">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
            <div class="flex items-center gap-2">
              <div class="p-2 bg-cyan-500/10 text-cyan-400 rounded-xl">
                <mat-icon>assessment</mat-icon>
              </div>
              <div>
                <h3 class="font-display font-semibold text-sm text-neutral-100">Monte Carlo Experiment Suite</h3>
                <p class="text-[11px] text-neutral-400 font-mono">Statistical throughput & recovery evaluation</p>
              </div>
            </div>
          </div>

          <!-- Batch Run Controls -->
          <div class="flex flex-col gap-3 font-mono text-xs">
            <div class="flex items-center justify-between text-neutral-300">
              <span>Sample Batch Size:</span>
              <div class="flex items-center gap-1">
                <button (click)="batchSize.set(50)" 
                        class="px-2 py-1 rounded border transition-all"
                        [class.bg-cyan-500]="batchSize() === 50"
                        [class.text-neutral-950]="batchSize() === 50"
                        [class.border-cyan-400]="batchSize() === 50"
                        [class.bg-neutral-950]="batchSize() !== 50"
                        [class.border-neutral-800]="batchSize() !== 50"
                        [class.text-neutral-400]="batchSize() !== 50">
                  50
                </button>
                <button (click)="batchSize.set(100)" 
                        class="px-2 py-1 rounded border transition-all"
                        [class.bg-cyan-500]="batchSize() === 100"
                        [class.text-neutral-950]="batchSize() === 100"
                        [class.border-cyan-400]="batchSize() === 100"
                        [class.bg-neutral-950]="batchSize() !== 100"
                        [class.border-neutral-800]="batchSize() !== 100"
                        [class.text-neutral-400]="batchSize() !== 100">
                  100
                </button>
                <button (click)="batchSize.set(250)" 
                        class="px-2 py-1 rounded border transition-all"
                        [class.bg-cyan-500]="batchSize() === 250"
                        [class.text-neutral-950]="batchSize() === 250"
                        [class.border-cyan-400]="batchSize() === 250"
                        [class.bg-neutral-950]="batchSize() !== 250"
                        [class.border-neutral-800]="batchSize() !== 250"
                        [class.text-neutral-400]="batchSize() !== 250">
                  250
                </button>
              </div>
            </div>

            <!-- Run Single Batch Button -->
            <button (click)="runBatch()"
                    [disabled]="isRunning()"
                    class="py-2.5 px-4 rounded-xl bg-cyan-500 text-neutral-950 font-bold font-mono hover:bg-cyan-400 transition-all flex items-center justify-center gap-2 shadow-lg disabled:opacity-50">
              <mat-icon class="scale-90">play_circle</mat-icon>
              <span>{{ isRunning() ? 'Executing Monte Carlo Reads...' : 'Launch Monte Carlo Batch' }}</span>
            </button>

            <!-- Multi-Speed Benchmark Button -->
            <button (click)="runFullSpeedBenchmark()"
                    [disabled]="isRunning()"
                    class="py-2.5 px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-bold font-mono border border-neutral-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50">
              <mat-icon class="scale-90">speed</mat-icon>
              <span>Benchmark All Speeds (1x .. 52x)</span>
            </button>
          </div>

          <!-- CLV vs CAV Physics Callout -->
          <div class="p-3 bg-neutral-950 rounded-xl border border-neutral-800 font-mono text-xs flex flex-col gap-1.5 text-neutral-400 leading-relaxed">
            <span class="text-cyan-400 font-semibold">Kinematics: CLV vs CAV</span>
            <p class="text-[11px]">
              - <strong class="text-neutral-200">CLV (Constant Linear Velocity):</strong> Spindle RPM varies from ~500 RPM (inner radius 25mm) down to ~200 RPM (outer radius 58mm) to keep laser scan velocity locked at 1.30 m/s.
            </p>
            <p class="text-[11px]">
              - <strong class="text-neutral-200">CAV (Constant Angular Velocity):</strong> Spindle RPM stays fixed (e.g. 10,400 RPM at 52x) while data transfer rate scales upwards from 22x (inner) to 52x (outer).
            </p>
          </div>
        </div>
      </div>

      <!-- Right Column: Historical Experiment Results & Recovery Graphs -->
      <div class="lg:col-span-7 flex flex-col gap-4">
        <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-4">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
            <div class="flex items-center gap-2">
              <div class="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl">
                <mat-icon>history</mat-icon>
              </div>
              <div>
                <h3 class="font-display font-semibold text-sm text-neutral-100">Experiment Run Telemetry</h3>
                <p class="text-[11px] text-neutral-400 font-mono">Real-time throughput, latency and parity recovery metrics</p>
              </div>
            </div>
            <span class="text-xs font-mono text-neutral-400">
              {{ labService.experimentHistory().length }} Runs Recorded
            </span>
          </div>

          <!-- Results List -->
          <div class="flex flex-col gap-2 max-h-[460px] overflow-y-auto pr-1 font-mono text-xs">
            @for (exp of labService.experimentHistory(); track exp.runId) {
              <div class="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 flex flex-col gap-2">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2">
                    <span class="text-cyan-400 font-bold">{{ exp.runId }}</span>
                    <span class="px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 font-semibold">{{ exp.speed }}x Profile</span>
                  </div>
                  <span class="px-2 py-0.5 rounded text-[11px] font-bold"
                        [class.bg-emerald-500/20]="exp.recoveryRatePercent >= 90"
                        [class.text-emerald-400]="exp.recoveryRatePercent >= 90"
                        [class.bg-amber-500/20]="exp.recoveryRatePercent >= 60 && exp.recoveryRatePercent < 90"
                        [class.text-amber-400]="exp.recoveryRatePercent >= 60 && exp.recoveryRatePercent < 90"
                        [class.bg-rose-500/20]="exp.recoveryRatePercent < 60"
                        [class.text-rose-400]="exp.recoveryRatePercent < 60">
                    {{ exp.recoveryRatePercent }}% RECOVERY RATE
                  </span>
                </div>

                <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-neutral-900 text-[11px]">
                  <div>
                    <span class="text-neutral-500 block">Total Reads:</span>
                    <span class="text-neutral-200 font-bold">{{ exp.totalReads }}</span>
                  </div>
                  <div>
                    <span class="text-neutral-500 block">ECC Corrected:</span>
                    <span class="text-amber-400 font-bold">{{ exp.correctedReads }}</span>
                  </div>
                  <div>
                    <span class="text-neutral-500 block">Avg Seek:</span>
                    <span class="text-cyan-400 font-bold">{{ exp.avgSeekLatencyMs.toFixed(1) }} ms</span>
                  </div>
                  <div>
                    <span class="text-neutral-500 block">Effective Rate:</span>
                    <span class="text-emerald-400 font-bold">{{ exp.effectiveThroughputKbps.toFixed(0) }} KB/s</span>
                  </div>
                </div>
              </div>
            } @empty {
              <div class="p-8 text-center text-neutral-500 font-mono text-xs bg-neutral-950 rounded-xl border border-neutral-800">
                No experiments executed yet. Launch a Monte Carlo batch to record statistical read performance.
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ExperimentWorkbenchPanel {
  public labService = inject(OpticalLaboratoryService);
  public batchSize = signal<number>(100);
  public isRunning = signal<boolean>(false);

  public async runBatch(): Promise<void> {
    this.isRunning.set(true);
    await new Promise(r => setTimeout(r, 100));
    this.labService.runMonteCarloBatch(this.batchSize());
    this.isRunning.set(false);
  }

  public async runFullSpeedBenchmark(): Promise<void> {
    this.isRunning.set(true);
    await this.labService.runScenario3SpeedBenchmark();
    this.isRunning.set(false);
  }
}
