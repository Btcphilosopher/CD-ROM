// AUREOM MASTER DEMONSTRATION & ENGINEERING SCENARIO RUNNER
// Interactive 1-Click Execution for Canonical Lifecycle, Recovery, Speed Kinematics & Digital Preservation

import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { OpticalLaboratoryService } from '../services/optical-laboratory.service';

@Component({
  selector: 'app-master-demo-runner',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
      <!-- Scenario 1: Complete Canonical Lifecycle -->
      <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col justify-between gap-4 hover:border-cyan-500/40 transition-all group">
        <div class="flex flex-col gap-2">
          <div class="flex items-center justify-between">
            <span class="px-2.5 py-1 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-mono font-bold">
              SCENARIO 1
            </span>
            <span class="text-xs font-mono text-neutral-500">10-Step Automated Loop</span>
          </div>
          <h3 class="font-display font-semibold text-base text-neutral-100 group-hover:text-cyan-400 transition-colors">
            Canonical End-to-End Lifecycle
          </h3>
          <p class="text-xs text-neutral-400 leading-relaxed">
            Execute the complete optical storage stack: Physical Geometry -> ISO 9660 PVD -> Spindle Spin-Up -> File Extent Tracing -> Hex Inspection -> Scratch Injection -> Layered P/Q Parity Recovery -> Forensic Verification.
          </p>
        </div>

        <button (click)="labService.runScenario1FullLifecycle()"
                [disabled]="labService.isRunningScenario()"
                class="w-full py-2.5 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold font-mono text-xs flex items-center justify-center gap-2 shadow-lg transition-all disabled:opacity-50">
          <mat-icon class="scale-75">play_arrow</mat-icon>
          <span>Run Canonical Lifecycle</span>
        </button>
      </div>

      <!-- Scenario 2: Disc Degradation & Recovery Experiment -->
      <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col justify-between gap-4 hover:border-rose-500/40 transition-all group">
        <div class="flex flex-col gap-2">
          <div class="flex items-center justify-between">
            <span class="px-2.5 py-1 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/20 text-xs font-mono font-bold">
              SCENARIO 2
            </span>
            <span class="text-xs font-mono text-neutral-500">Stress & Recovery</span>
          </div>
          <h3 class="font-display font-semibold text-base text-neutral-100 group-hover:text-rose-400 transition-colors">
            Laser Rot & Physical Scratch Recovery
          </h3>
          <p class="text-xs text-neutral-400 leading-relaxed">
            Simulate 15-year Arrhenius thermodynamic aging, apply tangential scratches across the program area, and execute 200 automated sector reads to measure Reed-Solomon recovery vs uncorrectable block dropouts.
          </p>
        </div>

        <button (click)="labService.runScenario2RecoveryExperiment()"
                [disabled]="labService.isRunningScenario()"
                class="w-full py-2.5 px-4 rounded-xl bg-rose-500 hover:bg-rose-400 text-neutral-950 font-bold font-mono text-xs flex items-center justify-center gap-2 shadow-lg transition-all disabled:opacity-50">
          <mat-icon class="scale-75">healing</mat-icon>
          <span>Run Recovery Stress Test</span>
        </button>
      </div>

      <!-- Scenario 3: Drive Kinematics & Multi-Speed Benchmark -->
      <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col justify-between gap-4 hover:border-amber-500/40 transition-all group">
        <div class="flex flex-col gap-2">
          <div class="flex items-center justify-between">
            <span class="px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20 text-xs font-mono font-bold">
              SCENARIO 3
            </span>
            <span class="text-xs font-mono text-neutral-500">Kinematics & Speed</span>
          </div>
          <h3 class="font-display font-semibold text-base text-neutral-100 group-hover:text-amber-400 transition-colors">
            Spindle Kinematics & 1x..52x Benchmark
          </h3>
          <p class="text-xs text-neutral-400 leading-relaxed">
            Benchmark optical drive rotational dynamics from Red Book 1x (200-500 RPM / 150 KB/s) up to 52x CAV (10,400 RPM / 7,800 KB/s), evaluating SLED seek latencies and eye pattern jitter.
          </p>
        </div>

        <button (click)="labService.runScenario3SpeedBenchmark()"
                [disabled]="labService.isRunningScenario()"
                class="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold font-mono text-xs flex items-center justify-center gap-2 shadow-lg transition-all disabled:opacity-50">
          <mat-icon class="scale-75">speed</mat-icon>
          <span>Benchmark 1x to 52x Speeds</span>
        </button>
      </div>

      <!-- Scenario 4: Forensic Ingestion & Preservation -->
      <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col justify-between gap-4 hover:border-emerald-500/40 transition-all group">
        <div class="flex flex-col gap-2">
          <div class="flex items-center justify-between">
            <span class="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-mono font-bold">
              SCENARIO 4
            </span>
            <span class="text-xs font-mono text-neutral-500">Digital Preservation</span>
          </div>
          <h3 class="font-display font-semibold text-base text-neutral-100 group-hover:text-emerald-400 transition-colors">
            Forensic Ingestion & Audit Workflow
          </h3>
          <p class="text-xs text-neutral-400 leading-relaxed">
            Ingest disc image into the digital preservation lab, compute SHA-256 / SHA-512 cryptographic digests, scan for hidden slack space and orphan sectors, and generate a signed audit certificate.
          </p>
        </div>

        <button (click)="labService.runScenario4PreservationWorkflow()"
                [disabled]="labService.isRunningScenario()"
                class="w-full py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold font-mono text-xs flex items-center justify-center gap-2 shadow-lg transition-all disabled:opacity-50">
          <mat-icon class="scale-75">verified_user</mat-icon>
          <span>Run Preservation Ingestion</span>
        </button>
      </div>
    </div>
  `,
})
export class MasterDemoRunner {
  public labService = inject(OpticalLaboratoryService);
}
