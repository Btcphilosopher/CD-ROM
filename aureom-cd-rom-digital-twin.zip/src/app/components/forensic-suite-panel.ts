// AUREOM FORENSIC AUDIT & DIGITAL PRESERVATION SUITE
// Cryptographic Multi-Hash, Anomaly & Slack Space Detection, Differential Image Comparator

import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { OpticalLaboratoryService } from '../services/optical-laboratory.service';
import { ForensicReport } from '../core/models';
import { ForensicsEngine } from '../core/forensics';

@Component({
  selector: 'app-forensic-suite-panel',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
      <!-- Left Column: Cryptographic Hashes, Audit Runner & Anomaly Scan -->
      <div class="lg:col-span-6 flex flex-col gap-4">
        <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-4">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
            <div class="flex items-center gap-2">
              <div class="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl">
                <mat-icon>verified_user</mat-icon>
              </div>
              <div>
                <h3 class="font-display font-semibold text-sm text-neutral-100">Forensic Cryptographic Ingestion</h3>
                <p class="text-[11px] text-neutral-400 font-mono">Multi-hash verification, slack space & anomaly scanning</p>
              </div>
            </div>

            <button (click)="runAudit()" 
                    class="px-3 py-1.5 rounded-xl bg-emerald-500 text-neutral-950 font-bold font-mono text-xs hover:bg-emerald-400 transition-all flex items-center gap-1.5 shadow-md">
              <mat-icon class="scale-75">security</mat-icon>
              <span>Run Audit</span>
            </button>
          </div>

          <!-- Cryptographic Hashes -->
          <div class="bg-neutral-950 p-3.5 rounded-xl border border-neutral-800 flex flex-col gap-2 font-mono text-xs">
            <span class="text-neutral-500 text-[10px] uppercase font-bold">Cryptographic Image Digests:</span>
            <div class="flex flex-col gap-1.5">
              <div>
                <span class="text-neutral-500 block text-[10px]">SHA-256:</span>
                <span class="text-emerald-400 text-[11px] break-all select-all">{{ disc().imageHashSha256 }}</span>
              </div>
              <div>
                <span class="text-neutral-500 block text-[10px]">SHA-512 (Prefix):</span>
                <span class="text-cyan-400 text-[11px] break-all select-all">{{ disc().imageHashSha512.substring(0, 48) }}...</span>
              </div>
              <div class="flex items-center justify-between pt-1 border-t border-neutral-900">
                <span class="text-neutral-400">MD5: <code class="text-amber-400">{{ disc().imageHashMd5 }}</code></span>
                <span class="text-neutral-400">CRC-32: <code class="text-purple-400">0x{{ disc().imageHashCrc32 }}</code></span>
              </div>
            </div>
          </div>

          <!-- Anomalies & Sector Discrepancies Log -->
          <div class="bg-neutral-950 p-3.5 rounded-xl border border-neutral-800 flex flex-col gap-2 font-mono text-xs">
            <div class="flex items-center justify-between">
              <span class="text-neutral-400 font-bold">Preservation Anomalies Log</span>
              <span class="text-[10px] text-neutral-500">{{ getAnomalyCount() }} detected</span>
            </div>
            
            <div class="flex flex-col gap-1 max-h-40 overflow-y-auto pr-1">
              @if (report() && report()!.anomaliesFound.length > 0) {
                @for (a of report()!.anomaliesFound; track $index) {
                  <div class="p-2 rounded bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[11px]">
                    {{ a }}
                  </div>
                }
              } @else {
                <div class="text-neutral-500 text-[11px] py-2 text-center">
                  No structural anomalies found. Run audit to generate fresh inspection.
                </div>
              }
            </div>
          </div>

          <!-- Export Report Buttons -->
          @if (report(); as rep) {
            <div class="flex items-center gap-2 pt-2 border-t border-neutral-800">
              <button (click)="downloadMarkdownReport(rep)"
                      class="flex-1 py-2 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-mono text-xs font-semibold flex items-center justify-center gap-1.5 transition-all">
                <mat-icon class="scale-75">download</mat-icon>
                <span>Export Markdown Audit</span>
              </button>
              <button (click)="downloadJsonReport(rep)"
                      class="flex-1 py-2 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-mono text-xs font-semibold flex items-center justify-center gap-1.5 transition-all">
                <mat-icon class="scale-75">data_object</mat-icon>
                <span>Export JSON Report</span>
              </button>
            </div>
          }
        </div>
      </div>

      <!-- Right Column: Side-by-Side Image Diff Comparator (Original vs Corrupted) -->
      <div class="lg:col-span-6 flex flex-col gap-4">
        <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-4">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
            <div class="flex items-center gap-2">
              <div class="p-2 bg-cyan-500/10 text-cyan-400 rounded-xl">
                <mat-icon>difference</mat-icon>
              </div>
              <div>
                <h3 class="font-display font-semibold text-sm text-neutral-100">Differential Image Comparator</h3>
                <p class="text-[11px] text-neutral-400 font-mono">Pristine Baseline Master vs Current Modified Image</p>
              </div>
            </div>

            <button (click)="runDiff()" 
                    class="px-3 py-1.5 rounded-xl bg-cyan-500 text-neutral-950 font-bold font-mono text-xs hover:bg-cyan-400 transition-all flex items-center gap-1.5 shadow-md">
              <mat-icon class="scale-75">compare</mat-icon>
              <span>Compare Discs</span>
            </button>
          </div>

          <!-- Diff Results Table -->
          @if (diffResult(); as diff) {
            <div class="flex flex-col gap-3 font-mono text-xs">
              <div class="p-3 bg-neutral-950 rounded-xl border border-neutral-800 flex items-center justify-between">
                <div>
                  <span class="text-neutral-500">Total Sectors Evaluated:</span>
                  <span class="text-neutral-200 font-bold ml-1">{{ diff.totalSectorsCompared }}</span>
                </div>
                <div>
                  <span class="text-neutral-500">Discrepancies:</span>
                  <span class="font-bold ml-1" [class.text-emerald-400]="diff.differingSectorsCount === 0" [class.text-rose-400]="diff.differingSectorsCount > 0">
                    {{ diff.differingSectorsCount }} Sectors
                  </span>
                </div>
              </div>

              <!-- List of differing sectors -->
              <div class="flex flex-col gap-1.5 max-h-64 overflow-y-auto pr-1">
                @for (d of diff.differingSectors; track d.lba) {
                  <div class="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                    <div>
                      <span class="text-cyan-400 font-bold">LBA {{ d.lba }}</span>
                      <span class="text-[11px] text-neutral-400 ml-2">({{ d.path || 'Free space' }})</span>
                    </div>
                    <div class="text-right">
                      <span class="text-rose-400 font-semibold">{{ d.byteDiffCount }} bytes altered</span>
                      <span class="text-[10px] text-neutral-500 block">{{ d.originalStatus }} -> {{ d.targetStatus }}</span>
                    </div>
                  </div>
                }
              </div>
            </div>
          } @else {
            <div class="bg-neutral-950 rounded-xl p-8 text-center text-neutral-500 font-mono text-xs border border-neutral-800">
              Click "Compare Discs" to perform an automated sector-by-sector differential audit between the pristine factory baseline and the current virtual image.
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class ForensicSuitePanel {
  public labService = inject(OpticalLaboratoryService);
  public disc = this.labService.currentDisc;
  public report = this.labService.lastForensicReport;
  public diffResult = this.labService.lastImageDiff;

  public runAudit(): void {
    this.labService.runForensicAudit();
  }

  public runDiff(): void {
    this.labService.compareWithBaseline();
  }

  public getAnomalyCount(): number {
    return this.report()?.anomaliesFound.length || 0;
  }

  public downloadMarkdownReport(report: ForensicReport): void {
    const md = ForensicsEngine.formatMarkdownReport(report);
    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report.reportId}.md`;
    a.click();
    URL.revokeObjectURL(url);
  }

  public downloadJsonReport(report: ForensicReport): void {
    const json = JSON.stringify(report, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report.reportId}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
