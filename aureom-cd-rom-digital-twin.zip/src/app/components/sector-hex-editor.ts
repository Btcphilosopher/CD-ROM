// AUREOM RAW SECTOR HEX & STRUCTURE EDITOR
// Professional 2352-byte Mode 1 Hex/ASCII/Binary Inspector with Structural Segment Coloration

import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { OpticalLaboratoryService } from '../services/optical-laboratory.service';

export interface HexLine {
  offset: number;
  offsetHex: string;
  bytes: {
    val: number;
    hex: string;
    ascii: string;
    segment: 'SYNC' | 'HEADER' | 'DATA' | 'EDC' | 'RESERVED' | 'PPARITY' | 'QPARITY';
    isDifferentFromPristine?: boolean;
  }[];
}

@Component({
  selector: 'app-sector-hex-editor',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-4">
      <!-- Header Toolbar -->
      <div class="flex flex-wrap items-center justify-between gap-3 border-b border-neutral-800 pb-4">
        <div class="flex items-center gap-2.5">
          <div class="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20">
            <mat-icon class="scale-90">code</mat-icon>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h3 class="font-display font-semibold text-base text-neutral-100">Raw Sector Hex Inspector</h3>
              <span class="px-2 py-0.5 rounded text-xs font-mono font-bold"
                    [class.bg-emerald-500/20]="sector().status === 'HEALTHY'"
                    [class.text-emerald-400]="sector().status === 'HEALTHY'"
                    [class.bg-amber-500/20]="sector().status === 'ECC_CORRECTED'"
                    [class.text-amber-400]="sector().status === 'ECC_CORRECTED'"
                    [class.bg-rose-500/20]="sector().status === 'CORRUPTED' || sector().status === 'UNCORRECTABLE'"
                    [class.text-rose-400]="sector().status === 'CORRUPTED' || sector().status === 'UNCORRECTABLE'">
                {{ sector().status }}
              </span>
            </div>
            <p class="text-xs text-neutral-400 font-mono">
              LBA <span class="text-cyan-400 font-bold">{{ sector().lba }}</span> | MSF: <span class="text-neutral-200">{{ sector().absoluteMsf }}</span> | {{ sector().allocatedPath || 'Unallocated' }}
            </p>
          </div>
        </div>

        <!-- Navigation & Actions -->
        <div class="flex flex-wrap items-center gap-2">
          <!-- Jump to LBA -->
          <div class="flex items-center bg-neutral-950 px-2 py-1 rounded-xl border border-neutral-800 text-xs font-mono">
            <span class="text-neutral-500 mr-1">LBA:</span>
            <input type="number" 
                   [value]="sector().lba" 
                   (change)="onLbaChange($event)"
                   min="0" 
                   [max]="labService.currentDisc().usedSectors - 1"
                   class="w-16 bg-transparent text-cyan-400 font-bold focus:outline-none" />
          </div>

          <button (click)="previousSector()" 
                  [disabled]="sector().lba <= 0"
                  class="p-1.5 rounded-lg bg-neutral-800 text-neutral-300 hover:bg-neutral-700 disabled:opacity-40 transition-all">
            <mat-icon class="scale-75">chevron_left</mat-icon>
          </button>
          <button (click)="nextSector()" 
                  [disabled]="sector().lba >= labService.currentDisc().usedSectors - 1"
                  class="p-1.5 rounded-lg bg-neutral-800 text-neutral-300 hover:bg-neutral-700 disabled:opacity-40 transition-all">
            <mat-icon class="scale-75">chevron_right</mat-icon>
          </button>

          <!-- Corrupt Single Byte Test Action -->
          <button (click)="corruptActiveSector()" 
                  class="px-3 py-1.5 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/30 hover:bg-rose-500/20 text-xs font-medium flex items-center gap-1.5 transition-all">
            <mat-icon class="scale-75">pest_control</mat-icon>
            <span>Inject Corruption</span>
          </button>

          <!-- Export Raw Binary -->
          <button (click)="exportSectorBin()" 
                  class="px-3 py-1.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 hover:bg-cyan-500/20 text-xs font-medium flex items-center gap-1.5 transition-all">
            <mat-icon class="scale-75">download</mat-icon>
            <span>Export 2352B</span>
          </button>
        </div>
      </div>

      <!-- Segment Legend -->
      <div class="flex flex-wrap items-center gap-3 text-[11px] font-mono text-neutral-400 bg-neutral-950/60 p-2.5 rounded-xl border border-neutral-800/80">
        <span class="text-neutral-500">CD-ROM Mode 1 Structure:</span>
        <span class="flex items-center gap-1 text-amber-400"><span class="w-2.5 h-2.5 rounded-sm bg-amber-500/40"></span>Sync (0..11)</span>
        <span class="flex items-center gap-1 text-cyan-400"><span class="w-2.5 h-2.5 rounded-sm bg-cyan-500/40"></span>Header (12..15)</span>
        <span class="flex items-center gap-1 text-neutral-200"><span class="w-2.5 h-2.5 rounded-sm bg-neutral-600/40"></span>Data (16..2063)</span>
        <span class="flex items-center gap-1 text-emerald-400"><span class="w-2.5 h-2.5 rounded-sm bg-emerald-500/40"></span>EDC (2064..2067)</span>
        <span class="flex items-center gap-1 text-neutral-500"><span class="w-2.5 h-2.5 rounded-sm bg-neutral-800"></span>Reserved (2068..2075)</span>
        <span class="flex items-center gap-1 text-purple-400"><span class="w-2.5 h-2.5 rounded-sm bg-purple-500/40"></span>P-Parity (2076..2247)</span>
        <span class="flex items-center gap-1 text-pink-400"><span class="w-2.5 h-2.5 rounded-sm bg-pink-500/40"></span>Q-Parity (2248..2351)</span>
      </div>

      <!-- Hex / ASCII Grid Table -->
      <div class="h-96 overflow-y-auto bg-neutral-950 rounded-xl p-3 border border-neutral-800 font-mono text-xs select-text">
        <div class="grid grid-cols-[70px_1fr_180px] gap-4 font-bold text-neutral-500 border-b border-neutral-800 pb-1 mb-2">
          <span>OFFSET</span>
          <span>HEX (00 01 02 03 04 05 06 07  08 09 0A 0B 0C 0D 0E 0F)</span>
          <span>ASCII</span>
        </div>

        @for (line of hexLines(); track line.offset) {
          <div class="grid grid-cols-[70px_1fr_180px] gap-4 py-0.5 hover:bg-neutral-800/40 rounded transition-colors group">
            <!-- Offset -->
            <span class="text-neutral-500 group-hover:text-cyan-400">{{ line.offsetHex }}</span>

            <!-- Hex Bytes -->
            <div class="flex items-center gap-1 flex-wrap">
              @for (b of line.bytes; track $index) {
                <button type="button"
                        class="px-0.5 rounded cursor-pointer transition-colors text-xs font-mono"
                        (click)="selectedByte.set(b)"
                        [class.bg-cyan-500]="selectedByte() === b"
                        [class.text-neutral-950]="selectedByte() === b"
                        [class.text-amber-400]="b.segment === 'SYNC' && selectedByte() !== b"
                        [class.text-cyan-400]="b.segment === 'HEADER' && selectedByte() !== b"
                        [class.text-neutral-300]="b.segment === 'DATA' && selectedByte() !== b"
                        [class.text-emerald-400]="b.segment === 'EDC' && selectedByte() !== b"
                        [class.text-neutral-600]="b.segment === 'RESERVED' && selectedByte() !== b"
                        [class.text-purple-400]="b.segment === 'PPARITY' && selectedByte() !== b"
                        [class.text-pink-400]="b.segment === 'QPARITY' && selectedByte() !== b"
                        [class.font-bold]="b.segment !== 'DATA'">
                  {{ b.hex }}
                </button>
                @if ($index === 7) {
                  <span class="text-neutral-700 mx-0.5">|</span>
                }
              }
            </div>

            <!-- ASCII -->
            <span class="text-neutral-400 tracking-wider overflow-hidden text-ellipsis whitespace-nowrap">
              @for (b of line.bytes; track $index) {
                <span>{{ b.ascii }}</span>
              }
            </span>
          </div>
        }
      </div>

      <!-- Selected Byte Inspector Footer -->
      @if (selectedByte(); as b) {
        <div class="bg-neutral-950 p-3 rounded-xl border border-neutral-800 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          <div class="flex items-center gap-3">
            <span class="text-neutral-500">Selected Byte:</span>
            <span class="text-cyan-400 font-bold">0x{{ b.hex }}</span>
            <span class="text-neutral-400">Decimal: {{ b.val }}</span>
            <span class="text-emerald-400">ASCII: '{{ b.ascii }}'</span>
            <span class="text-purple-400">Binary: {{ b.val.toString(2).padStart(8, '0') }}</span>
          </div>
          <span class="text-amber-400 font-semibold uppercase">Segment: {{ b.segment }}</span>
        </div>
      }
    </div>
  `,
})
export class SectorHexEditor {
  public labService = inject(OpticalLaboratoryService);
  public sector = this.labService.activeSector;
  public selectedByte = signal<HexLine['bytes'][0] | null>(null);

  public hexLines = computed<HexLine[]>(() => {
    const s = this.sector();
    const raw = s.rawBytes;
    const lines: HexLine[] = [];

    for (let offset = 0; offset < raw.length; offset += 16) {
      const bytes: HexLine['bytes'] = [];
      for (let i = 0; i < 16 && (offset + i) < raw.length; i++) {
        const idx = offset + i;
        const val = raw[idx];
        const hex = val.toString(16).padStart(2, '0').toUpperCase();
        const ascii = (val >= 32 && val <= 126) ? String.fromCharCode(val) : '.';

        let segment: HexLine['bytes'][0]['segment'] = 'DATA';
        if (idx < 12) segment = 'SYNC';
        else if (idx < 16) segment = 'HEADER';
        else if (idx < 2064) segment = 'DATA';
        else if (idx < 2068) segment = 'EDC';
        else if (idx < 2076) segment = 'RESERVED';
        else if (idx < 2248) segment = 'PPARITY';
        else segment = 'QPARITY';

        bytes.push({ val, hex, ascii, segment });
      }

      lines.push({
        offset,
        offsetHex: offset.toString(16).padStart(4, '0').toUpperCase(),
        bytes,
      });
    }

    return lines;
  });

  public onLbaChange(e: Event): void {
    const val = parseInt((e.target as HTMLInputElement).value, 10);
    if (!isNaN(val)) {
      this.labService.selectSectorByLba(val);
    }
  }

  public previousSector(): void {
    const cur = this.sector().lba;
    if (cur > 0) {
      this.labService.selectSectorByLba(cur - 1);
    }
  }

  public nextSector(): void {
    const cur = this.sector().lba;
    if (cur < this.labService.currentDisc().usedSectors - 1) {
      this.labService.selectSectorByLba(cur + 1);
    }
  }

  public corruptActiveSector(): void {
    this.labService.injectSectorCorruption(this.sector().lba, 20);
  }

  public exportSectorBin(): void {
    const s = this.sector();
    const blob = new Blob([s.rawBytes as unknown as BlobPart], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sector_lba_${s.lba}_mode1.bin`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
