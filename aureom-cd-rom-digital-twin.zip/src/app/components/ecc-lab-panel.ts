// AUREOM REED-SOLOMON ECC & LAYERED DECODER LABORATORY
// CIRC C1/C2, Layered P/Q Parity Matrix, Syndrome Polynomials & 32-bit EDC Verification

import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { OpticalLaboratoryService } from '../services/optical-laboratory.service';

@Component({
  selector: 'app-ecc-lab-panel',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
      <!-- Left Column: Layered Pipeline Visualizer -->
      <div class="lg:col-span-7 bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-4">
        <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div class="flex items-center gap-2">
            <div class="p-2 bg-purple-500/10 text-purple-400 rounded-xl">
              <mat-icon>matrix</mat-icon>
            </div>
            <div>
              <h3 class="font-display font-semibold text-sm text-neutral-100">Layered CIRC & CD-ROM ECC Matrix</h3>
              <p class="text-[11px] text-neutral-400 font-mono">Cross-Interleaved Reed-Solomon Code + Mode 1 Layered P/Q Parity</p>
            </div>
          </div>

          <button (click)="runStepByStepDecode()"
                  [disabled]="isDecoding()"
                  class="px-3 py-1.5 rounded-xl bg-purple-500 text-neutral-950 font-bold font-mono text-xs hover:bg-purple-400 transition-all flex items-center gap-1.5 shadow-md disabled:opacity-50">
            <mat-icon class="scale-75">play_arrow</mat-icon>
            <span>{{ isDecoding() ? 'Decoding...' : 'Execute Full Decode' }}</span>
          </button>
        </div>

        <!-- 6-Stage Decoding Pipeline Architecture -->
        <div class="flex flex-col gap-2.5 font-mono text-xs">
          <!-- Stage 1: Photodiode RF & EFM Demodulator -->
          <div class="p-3 rounded-xl border transition-all flex items-center justify-between"
               [class.bg-purple-950/40]="currentStep() >= 1"
               [class.border-purple-500/50]="currentStep() >= 1"
               [class.bg-neutral-950]="currentStep() < 1"
               [class.border-neutral-800]="currentStep() < 1">
            <div class="flex items-center gap-2.5">
              <span class="w-6 h-6 rounded-full bg-purple-500/20 text-purple-300 font-bold flex items-center justify-center text-[10px]">1</span>
              <div>
                <span class="text-neutral-200 font-semibold block">EFM Demodulation & Sync Detection</span>
                <span class="text-[10px] text-neutral-400">14-bit channel words -> 8-bit symbols (2352 bytes/sector)</span>
              </div>
            </div>
            <span class="text-[10px] text-emerald-400">SYNC OK</span>
          </div>

          <!-- Stage 2: CIRC C1 Decoder -->
          <div class="p-3 rounded-xl border transition-all flex items-center justify-between"
               [class.bg-purple-950/40]="currentStep() >= 2"
               [class.border-purple-500/50]="currentStep() >= 2"
               [class.bg-neutral-950]="currentStep() < 2"
               [class.border-neutral-800]="currentStep() < 2">
            <div class="flex items-center gap-2.5">
              <span class="w-6 h-6 rounded-full bg-purple-500/20 text-purple-300 font-bold flex items-center justify-center text-[10px]">2</span>
              <div>
                <span class="text-neutral-200 font-semibold block">CIRC C1 Decoder: RS(28, 24)</span>
                <span class="text-[10px] text-neutral-400">Corrects up to 2 symbol errors per 28-byte frame; flags uncorrectable bytes as erasures</span>
              </div>
            </div>
            <span class="text-[10px] text-cyan-400">t=2 SYMBOLS</span>
          </div>

          <!-- Stage 3: 28-Frame De-Interleaver Delay Lines -->
          <div class="p-3 rounded-xl border transition-all flex items-center justify-between"
               [class.bg-purple-950/40]="currentStep() >= 3"
               [class.border-purple-500/50]="currentStep() >= 3"
               [class.bg-neutral-950]="currentStep() < 3"
               [class.border-neutral-800]="currentStep() < 3">
            <div class="flex items-center gap-2.5">
              <span class="w-6 h-6 rounded-full bg-purple-500/20 text-purple-300 font-bold flex items-center justify-center text-[10px]">3</span>
              <div>
                <span class="text-neutral-200 font-semibold block">De-Interleaver (Delay Lines D = 4 frames)</span>
                <span class="text-[10px] text-neutral-400">Disperses physical burst scratches across 108 frames (~2.5mm length)</span>
              </div>
            </div>
            <span class="text-[10px] text-amber-400">BURST DISPERSED</span>
          </div>

          <!-- Stage 4: CIRC C2 Decoder -->
          <div class="p-3 rounded-xl border transition-all flex items-center justify-between"
               [class.bg-purple-950/40]="currentStep() >= 4"
               [class.border-purple-500/50]="currentStep() >= 4"
               [class.bg-neutral-950]="currentStep() < 4"
               [class.border-neutral-800]="currentStep() < 4">
            <div class="flex items-center gap-2.5">
              <span class="w-6 h-6 rounded-full bg-purple-500/20 text-purple-300 font-bold flex items-center justify-center text-[10px]">4</span>
              <div>
                <span class="text-neutral-200 font-semibold block">CIRC C2 Decoder: RS(28, 24) with Erasures</span>
                <span class="text-[10px] text-neutral-400">Corrects up to 4 erasure symbols with C1 pointer flags</span>
              </div>
            </div>
            <span class="text-[10px] text-emerald-400">t=4 ERASURES</span>
          </div>

          <!-- Stage 5: CD-ROM Layered P/Q Parity (Mode 1 3rd Layer ECC) -->
          <div class="p-3 rounded-xl border transition-all flex items-center justify-between"
               [class.bg-purple-950/40]="currentStep() >= 5"
               [class.border-purple-500/50]="currentStep() >= 5"
               [class.bg-neutral-950]="currentStep() < 5"
               [class.border-neutral-800]="currentStep() < 5">
            <div class="flex items-center gap-2.5">
              <span class="w-6 h-6 rounded-full bg-purple-500/20 text-purple-300 font-bold flex items-center justify-center text-[10px]">5</span>
              <div>
                <span class="text-neutral-200 font-semibold block">Layered Mode 1 P/Q Parity Decoders</span>
                <span class="text-[10px] text-neutral-400">P-Parity: 86 columns of RS(26,24) | Q-Parity: 52 diagonals of RS(45,43)</span>
              </div>
            </div>
            <span class="text-[10px] text-purple-400 font-bold">276 PARITY BYTES</span>
          </div>

          <!-- Stage 6: 32-Bit EDC Checksum Verification -->
          <div class="p-3 rounded-xl border transition-all flex items-center justify-between"
               [class.bg-purple-950/40]="currentStep() >= 6"
               [class.border-purple-500/50]="currentStep() >= 6"
               [class.bg-neutral-950]="currentStep() < 6"
               [class.border-neutral-800]="currentStep() < 6">
            <div class="flex items-center gap-2.5">
              <span class="w-6 h-6 rounded-full bg-purple-500/20 text-purple-300 font-bold flex items-center justify-center text-[10px]">6</span>
              <div>
                <span class="text-neutral-200 font-semibold block">32-Bit EDC Polynomial (P(X) = (X^16 + X^15 + X^2 + 1)(X^16 + X^2 + X + 1))</span>
                <span class="text-[10px] text-neutral-400">Final integrity guard: Residual Error Rate drops to 10^-12 (1 error per 2,000 discs)</span>
              </div>
            </div>
            <span class="text-[10px] text-emerald-400 font-bold">EDC VERIFIED</span>
          </div>
        </div>
      </div>

      <!-- Right Column: Galois Field Arithmetic & Active Sector Parity Matrix -->
      <div class="lg:col-span-5 flex flex-col gap-4">
        <!-- Galois Field GF(2^8) Specs -->
        <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-3 font-mono text-xs">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
            <h3 class="font-display font-semibold text-sm text-neutral-100">Galois Field Arithmetic GF(2^8)</h3>
            <span class="text-[10px] text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
              p(x) = x^8 + x^4 + x^3 + x^2 + 1 (0x11D)
            </span>
          </div>

          <div class="flex flex-col gap-2 text-neutral-300">
            <div class="flex justify-between">
              <span class="text-neutral-500">Primitive Root (α):</span>
              <span class="text-cyan-400 font-bold">0x02 (2)</span>
            </div>
            <div class="flex justify-between">
              <span class="text-neutral-500">Field Size:</span>
              <span class="text-neutral-200">256 elements (8-bit bytes)</span>
            </div>
            <div class="flex justify-between">
              <span class="text-neutral-500">Generator Poly (P-Parity):</span>
              <span class="text-purple-400">g(x) = (x - α^0)(x - α^1)</span>
            </div>
            <div class="flex justify-between">
              <span class="text-neutral-500">Generator Poly (Q-Parity):</span>
              <span class="text-pink-400">g(x) = (x - α^0)(x - α^1)</span>
            </div>
          </div>
        </div>

        <!-- Active Sector Parity Block Viewer -->
        <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-3 font-mono text-xs">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
            <span class="text-neutral-200 font-semibold">Active Sector Parity Status</span>
            <span class="text-cyan-400">LBA {{ sector().lba }}</span>
          </div>

          <div class="grid grid-cols-2 gap-2 text-center">
            <div class="p-2.5 bg-neutral-950 rounded-xl border border-neutral-800">
              <span class="text-[10px] text-neutral-500 block">Calculated EDC</span>
              <span class="text-emerald-400 font-bold">0x{{ sector().edcCalculated.toString(16).toUpperCase() }}</span>
            </div>
            <div class="p-2.5 bg-neutral-950 rounded-xl border border-neutral-800">
              <span class="text-[10px] text-neutral-500 block">Stored EDC</span>
              <span class="font-bold" [class.text-emerald-400]="sector().edcCalculated === sector().edcStored" [class.text-rose-400]="sector().edcCalculated !== sector().edcStored">
                0x{{ sector().edcStored.toString(16).toUpperCase() }}
              </span>
            </div>
          </div>

          <div class="p-3 bg-neutral-950 rounded-xl border border-neutral-800 text-[11px] leading-relaxed">
            @if (sector().edcCalculated === sector().edcStored) {
              <div class="text-emerald-400 flex items-center gap-1.5">
                <mat-icon class="scale-75">verified</mat-icon>
                <span>EDC and P/Q syndromes evaluate to zero. Sector payload is intact.</span>
              </div>
            } @else {
              <div class="text-rose-400 flex items-center gap-1.5">
                <mat-icon class="scale-75">error</mat-icon>
                <span>EDC mismatch detected! Reed-Solomon layered correction required.</span>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class EccLabPanel {
  public labService = inject(OpticalLaboratoryService);
  public sector = this.labService.activeSector;

  public currentStep = signal<number>(6); // Show all complete by default
  public isDecoding = signal<boolean>(false);

  public async runStepByStepDecode(): Promise<void> {
    this.isDecoding.set(true);
    for (let step = 1; step <= 6; step++) {
      this.currentStep.set(step);
      await new Promise(r => setTimeout(r, 450));
    }
    // Attempt actual sector ECC correction on active sector
    this.labService.readSector(this.sector().lba);
    this.isDecoding.set(false);
  }
}
