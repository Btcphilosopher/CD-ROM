// AUREOM ISO 9660 FILESYSTEM BROWSER & FILE-TO-SECTOR GRAPH
// Real ISO Directory Tree, File Extent Tracing, Multi-Format File Viewer & Extraction

import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { OpticalLaboratoryService } from '../services/optical-laboratory.service';
import { ISOFileRecord, ISODirectoryRecord } from '../core/models';

@Component({
  selector: 'app-filesystem-tree',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
      <!-- Left Column: Directory Tree Explorer -->
      <div class="lg:col-span-4 bg-neutral-900 border border-neutral-800 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
        <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div class="flex items-center gap-2">
            <div class="p-1.5 bg-cyan-500/10 text-cyan-400 rounded-lg">
              <mat-icon class="scale-90">folder_open</mat-icon>
            </div>
            <div>
              <h3 class="font-display font-semibold text-sm text-neutral-100">ISO 9660 Explorer</h3>
              <p class="text-[11px] text-neutral-400 font-mono">{{ labService.currentDisc().volumeLabel }}</p>
            </div>
          </div>
          <span class="text-xs font-mono text-neutral-400 bg-neutral-950 px-2 py-0.5 rounded border border-neutral-800">
            {{ labService.currentDisc().files.length }} files
          </span>
        </div>

        <!-- Directory & File Tree List -->
        <div class="flex flex-col gap-1 overflow-y-auto max-h-[480px] font-mono text-xs pr-1">
          <!-- Root item -->
          <div class="flex items-center gap-1.5 py-1 px-2 rounded-lg text-neutral-300 font-semibold bg-neutral-950/60 border border-neutral-800/60">
            <mat-icon class="text-amber-400 scale-75">folder</mat-icon>
            <span>/ [ISO Root LBA 21]</span>
          </div>

          <!-- Root Files -->
          @for (file of getRootFiles(); track file.path) {
            <button (click)="selectFile(file)"
                    class="ml-4 flex items-center justify-between py-1.5 px-2.5 rounded-lg cursor-pointer transition-all text-left"
                    [class.bg-cyan-500/20]="selectedFile()?.path === file.path"
                    [class.border]="selectedFile()?.path === file.path"
                    [class.border-cyan-500/40]="selectedFile()?.path === file.path"
                    [class.text-cyan-300]="selectedFile()?.path === file.path"
                    [class.hover:bg-neutral-800/60]="selectedFile()?.path !== file.path"
                    [class.text-neutral-300]="selectedFile()?.path !== file.path">
              <div class="flex items-center gap-1.5 overflow-hidden">
                <mat-icon class="text-neutral-400 scale-75">{{ getFileIcon(file.name) }}</mat-icon>
                <span class="truncate">{{ file.name }}</span>
              </div>
              <span class="text-[10px] text-neutral-500">{{ formatSize(file.sizeBytes) }}</span>
            </button>
          }

          <!-- Subdirectories -->
          @for (dir of getSubdirectories(); track dir.path) {
            <div class="ml-2 mt-2">
              <div class="flex items-center gap-1.5 py-1 px-2 text-amber-300 font-semibold">
                <mat-icon class="scale-75">folder_open</mat-icon>
                <span>{{ dir.path }} [LBA {{ dir.lba }}]</span>
              </div>
              @for (f of dir.entries; track f.path) {
                <button (click)="selectFile(f)"
                        class="ml-5 flex items-center justify-between py-1.5 px-2.5 rounded-lg cursor-pointer transition-all text-left"
                        [class.bg-cyan-500/20]="selectedFile()?.path === f.path"
                        [class.border]="selectedFile()?.path === f.path"
                        [class.border-cyan-500/40]="selectedFile()?.path === f.path"
                        [class.text-cyan-300]="selectedFile()?.path === f.path"
                        [class.hover:bg-neutral-800/60]="selectedFile()?.path !== f.path"
                        [class.text-neutral-300]="selectedFile()?.path !== f.path">
                  <div class="flex items-center gap-1.5 overflow-hidden">
                    <mat-icon class="text-neutral-400 scale-75">{{ getFileIcon(f.name) }}</mat-icon>
                    <span class="truncate">{{ f.name }}</span>
                  </div>
                  <span class="text-[10px] text-neutral-500">{{ formatSize(f.sizeBytes) }}</span>
                </button>
              }
            </div>
          }
        </div>
      </div>

      <!-- Right Column: File Inspector, Forensic Sector Trace Graph & Live Content -->
      <div class="lg:col-span-8 flex flex-col gap-4">
        @if (selectedFile(); as file) {
          <!-- File Overview Card -->
          <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div class="flex flex-wrap items-center justify-between gap-3 border-b border-neutral-800 pb-3">
              <div class="flex items-center gap-2.5">
                <div class="p-2 bg-cyan-500/10 text-cyan-400 rounded-xl">
                  <mat-icon>{{ getFileIcon(file.name) }}</mat-icon>
                </div>
                <div>
                  <h3 class="font-display font-semibold text-base text-neutral-100">{{ file.path }}</h3>
                  <p class="text-xs font-mono text-neutral-400">
                    Size: {{ file.sizeBytes.toLocaleString() }} Bytes ({{ file.sectorCount }} Sectors) | Date: {{ file.recordingDate }}
                  </p>
                </div>
              </div>

              <!-- Action Buttons -->
              <div class="flex items-center gap-2">
                <button (click)="jumpToSector(file.startLba)" 
                        class="px-3 py-1.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 hover:bg-cyan-500/20 text-xs font-mono font-medium flex items-center gap-1.5 transition-all">
                  <mat-icon class="scale-75">visibility</mat-icon>
                  <span>Inspect LBA {{ file.startLba }}</span>
                </button>
                <button (click)="extractFile(file)" 
                        class="px-3 py-1.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20 text-xs font-mono font-medium flex items-center gap-1.5 transition-all">
                  <mat-icon class="scale-75">file_download</mat-icon>
                  <span>Extract File</span>
                </button>
              </div>
            </div>

            <!-- FILE -> SECTOR -> PHYSICAL POSITION Extent Trace Graph -->
            <div class="bg-neutral-950 p-3.5 rounded-xl border border-neutral-800/80 flex flex-col gap-2 font-mono text-xs">
              <div class="flex items-center justify-between text-neutral-400 text-[11px]">
                <span class="text-cyan-400 font-semibold uppercase">Forensic Extent Trace: File -> Sector -> Track</span>
                <span>Extent Range: LBA {{ file.startLba }} .. {{ file.endLba }}</span>
              </div>

              <!-- Visual Sector Allocation Blocks -->
              <div class="flex items-center gap-1.5 flex-wrap py-1">
                @for (lba of getSectorsArray(file.startLba, file.sectorCount); track lba) {
                  <button (click)="jumpToSector(lba)"
                          class="px-2 py-1 rounded bg-neutral-800 hover:bg-cyan-600 text-neutral-300 hover:text-neutral-950 border border-neutral-700/80 transition-colors flex items-center gap-1 text-[10px]">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <span>LBA {{ lba }}</span>
                  </button>
                }
              </div>

              <div class="text-[11px] text-neutral-500 flex items-center gap-4 pt-1 border-t border-neutral-900">
                <span>SHA-256: <code class="text-neutral-300">{{ file.contentHashSha256 }}</code></span>
                <span>MIME: <code class="text-neutral-300">{{ file.mimeType }}</code></span>
              </div>
            </div>

            <!-- Live Content Viewer -->
            <div class="bg-neutral-950 p-4 rounded-xl border border-neutral-800 flex flex-col gap-2">
              <div class="flex items-center justify-between text-xs font-mono text-neutral-400 border-b border-neutral-800 pb-2">
                <span class="font-semibold text-neutral-200">Content Preview</span>
                <span class="text-[10px] text-neutral-500">Virtual CD Decoder Buffer</span>
              </div>

              <pre class="font-mono text-xs text-emerald-400 bg-neutral-900/60 p-3 rounded-lg border border-neutral-800/80 max-h-60 overflow-y-auto whitespace-pre-wrap select-text leading-relaxed">{{ file.contentSample }}</pre>
            </div>
          </div>
        } @else {
          <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-12 text-center text-neutral-400 flex flex-col items-center justify-center gap-3">
            <mat-icon class="scale-150 text-neutral-600">folder_open</mat-icon>
            <p class="text-sm">Select a file from the ISO 9660 Directory tree to inspect extents, raw sectors, and decoded payload.</p>
          </div>
        }
      </div>
    </div>
  `,
})
export class FilesystemTree {
  public labService = inject(OpticalLaboratoryService);
  public selectedFile = this.labService.selectedFile;

  public getRootFiles(): ISOFileRecord[] {
    return this.labService.currentDisc().rootDirectory.entries;
  }

  public getSubdirectories(): ISODirectoryRecord[] {
    return this.labService.currentDisc().rootDirectory.subdirectories;
  }

  public selectFile(file: ISOFileRecord): void {
    this.labService.selectFile(file);
  }

  public jumpToSector(lba: number): void {
    this.labService.selectSectorByLba(lba);
    this.labService.activeTab.set('hex-editor');
  }

  public getSectorsArray(startLba: number, count: number): number[] {
    const list: number[] = [];
    for (let i = 0; i < count; i++) {
      list.push(startLba + i);
    }
    return list;
  }

  public formatSize(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }

  public getFileIcon(name: string): string {
    const upper = name.toUpperCase();
    if (upper.endsWith('.TXT') || upper.endsWith('.INF') || upper.endsWith('.SYS')) return 'description';
    if (upper.endsWith('.EXE') || upper.endsWith('.BAT')) return 'terminal';
    if (upper.endsWith('.PDF') || upper.endsWith('.DOC')) return 'menu_book';
    if (upper.endsWith('.DAT') || upper.endsWith('.BIN')) return 'dataset';
    if (upper.endsWith('.PCM') || upper.endsWith('.WAV') || upper.endsWith('.MP3')) return 'audiotrack';
    return 'insert_drive_file';
  }

  public extractFile(file: ISOFileRecord): void {
    const text = file.contentSample || `[Binary payload for ${file.name}]`;
    const blob = new Blob([text], { type: file.mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name.replace(/;1$/, '');
    a.click();
    URL.revokeObjectURL(url);
    this.labService.addEvent('FILE_READ', `Extracted file ${file.path} (${file.sizeBytes} bytes) from virtual disc.`);
  }
}
