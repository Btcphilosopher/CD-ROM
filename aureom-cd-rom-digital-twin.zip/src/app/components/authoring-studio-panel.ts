// AUREOM CD-ROM MASTER AUTHORING WORKSTATION
// ISO 9660 Image Generator, Volume Descriptors, Directory Builder, EDC/ECC Encoding & ISO Export

import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { OpticalLaboratoryService } from '../services/optical-laboratory.service';
import { VolumeDescriptors, ISOFileRecord } from '../core/models';
import { Iso9660Engine } from '../core/iso9660';

@Component({
  selector: 'app-authoring-studio-panel',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
      <!-- Left Column: Volume Descriptors & Image Settings -->
      <div class="lg:col-span-5 flex flex-col gap-4">
        <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-4">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
            <div class="flex items-center gap-2">
              <div class="p-2 bg-amber-500/10 text-amber-400 rounded-xl">
                <mat-icon>album</mat-icon>
              </div>
              <div>
                <h3 class="font-display font-semibold text-sm text-neutral-100">ISO 9660 Authoring Deck</h3>
                <p class="text-[11px] text-neutral-400 font-mono">Mastering Level 1/2 Disc Images with Mode 1 EDC/ECC</p>
              </div>
            </div>
          </div>

          <!-- Volume Descriptors Form -->
          <div class="flex flex-col gap-3 font-mono text-xs">
            <div class="flex flex-col gap-1">
              <label for="volIdInput" class="text-neutral-400">Volume Identifier (32 chars):</label>
              <input id="volIdInput" type="text" [(ngModel)]="descriptors.volumeIdentifier" maxlength="32"
                     class="bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-cyan-400 font-bold focus:outline-none focus:border-cyan-500" />
            </div>

            <div class="flex flex-col gap-1">
              <label for="sysIdInput" class="text-neutral-400">System Identifier (32 chars):</label>
              <input id="sysIdInput" type="text" [(ngModel)]="descriptors.systemIdentifier" maxlength="32"
                     class="bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-200 focus:outline-none focus:border-cyan-500" />
            </div>

            <div class="flex flex-col gap-1">
              <label for="pubIdInput" class="text-neutral-400">Publisher Identifier (128 chars):</label>
              <input id="pubIdInput" type="text" [(ngModel)]="descriptors.publisherIdentifier" maxlength="128"
                     class="bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-200 focus:outline-none focus:border-cyan-500" />
            </div>

            <div class="flex flex-col gap-1">
              <label for="prepIdInput" class="text-neutral-400">Data Preparer Identifier (128 chars):</label>
              <input id="prepIdInput" type="text" [(ngModel)]="descriptors.dataPreparerIdentifier" maxlength="128"
                     class="bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-200 focus:outline-none focus:border-cyan-500" />
            </div>

            <div class="grid grid-cols-2 gap-2 pt-1">
              <div>
                <label for="sectorModeSelect" class="text-neutral-400 block text-[10px]">Sector Mode:</label>
                <select id="sectorModeSelect" [(ngModel)]="sectorMode"
                        class="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-neutral-300">
                  <option [value]="1">Mode 1 (2048 Data + ECC)</option>
                  <option [value]="2">Mode 2 Form 1 (CD-ROM XA)</option>
                </select>
              </div>
              <div>
                <label for="blockSizeInput" class="text-neutral-400 block text-[10px]">Logical Block Size:</label>
                <input id="blockSizeInput" type="number" [value]="descriptors.logicalBlockSize" disabled
                       class="w-full bg-neutral-950/60 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-neutral-500" />
              </div>
            </div>
          </div>

          <!-- Disc Capacity Gauge -->
          <div class="bg-neutral-950 p-4 rounded-xl border border-neutral-800 flex flex-col gap-2 font-mono text-xs">
            <div class="flex items-center justify-between">
              <span class="text-neutral-400">Capacity Utilization</span>
              <span class="text-cyan-400 font-bold">{{ labService.usedCapacityMb().toFixed(2) }} / 650.00 MB ({{ labService.usedPercentage().toFixed(1) }}%)</span>
            </div>
            <div class="w-full bg-neutral-900 h-2.5 rounded-full overflow-hidden border border-neutral-800">
              <div class="bg-gradient-to-r from-cyan-500 to-emerald-400 h-full transition-all duration-300"
                   [style.width.%]="labService.usedPercentage()"></div>
            </div>
            <div class="flex items-center justify-between text-[10px] text-neutral-500">
              <span>0 MB (Lead-In)</span>
              <span>Total Sectors: 333,000 (74 Min Standard)</span>
            </div>
          </div>

          <!-- Build Master ISO Button -->
          <button (click)="buildMasterIso()"
                  [disabled]="isBuilding()"
                  class="py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold font-mono text-xs flex items-center justify-center gap-2 shadow-lg transition-all disabled:opacity-50">
            <mat-icon class="scale-90">{{ isBuilding() ? 'hourglass_top' : 'precision_manufacturing' }}</mat-icon>
            <span>{{ isBuilding() ? 'Mastering Image & Generating Parities...' : 'Master & Burn Virtual Disc' }}</span>
          </button>
        </div>
      </div>

      <!-- Right Column: Virtual Payload File Manager & ISO Exporter -->
      <div class="lg:col-span-7 flex flex-col gap-4">
        <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-4">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
            <div class="flex items-center gap-2">
              <div class="p-2 bg-cyan-500/10 text-cyan-400 rounded-xl">
                <mat-icon>create_new_folder</mat-icon>
              </div>
              <div>
                <h3 class="font-display font-semibold text-sm text-neutral-100">Virtual File Payload Staging</h3>
                <p class="text-[11px] text-neutral-400 font-mono">Add custom files to ISO 9660 image structure</p>
              </div>
            </div>

            <!-- Download ISO binary -->
            <button (click)="exportIsoFile()" 
                    class="px-3 py-1.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 hover:bg-cyan-500/20 font-mono text-xs font-semibold flex items-center gap-1.5 transition-all">
              <mat-icon class="scale-75">download</mat-icon>
              <span>Download .ISO Image</span>
            </button>
          </div>

          <!-- Add File Inline Form -->
          <div class="bg-neutral-950 p-3.5 rounded-xl border border-neutral-800 flex flex-col gap-2.5 font-mono text-xs">
            <span class="text-neutral-400 font-semibold">Stage New File:</span>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <input type="text" placeholder="/FILENAME.EXT" [(ngModel)]="newFilePath"
                     class="bg-neutral-900 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-neutral-200 focus:outline-none" />
              <input type="text" placeholder="Content payload string..." [(ngModel)]="newFileContent"
                     class="sm:col-span-2 bg-neutral-900 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-neutral-200 focus:outline-none" />
            </div>
            <div class="flex justify-end">
              <button (click)="addStagedFile()"
                      class="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold flex items-center gap-1 transition-all">
                <mat-icon class="scale-75">add</mat-icon>
                <span>Add to Staged Image</span>
              </button>
            </div>
          </div>

          <!-- Staged Files List -->
          <div class="flex flex-col gap-1.5 max-h-72 overflow-y-auto pr-1 font-mono text-xs">
            @for (file of labService.currentDisc().files; track file.path) {
              <div class="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-cyan-400 scale-75">insert_drive_file</mat-icon>
                  <div>
                    <span class="text-neutral-200 font-semibold">{{ file.path }}</span>
                    <span class="text-[10px] text-neutral-500 block">LBA {{ file.startLba }} .. {{ file.endLba }} ({{ file.sizeBytes }} Bytes)</span>
                  </div>
                </div>
                <span class="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  SHA-256 Verified
                </span>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class AuthoringStudioPanel {
  public labService = inject(OpticalLaboratoryService);
  public descriptors: VolumeDescriptors = { ...this.labService.currentDisc().volumeDescriptors };
  public sectorMode = 1;
  public isBuilding = signal<boolean>(false);

  public newFilePath = '';
  public newFileContent = '';

  public addStagedFile(): void {
    if (!this.newFilePath.trim()) return;
    const path = this.newFilePath.startsWith('/') ? this.newFilePath : `/${this.newFilePath}`;
    const content = this.newFileContent || 'Default staged content for Aureom CD-ROM';
    
    // Add file to current disc
    const currentFiles = this.labService.currentDisc().files;
    const startLba = currentFiles.length > 0 ? currentFiles[currentFiles.length - 1].endLba + 1 : 25;
    
    const newFile: ISOFileRecord = {
      name: path.split('/').pop() || 'CUSTOM.DAT',
      path,
      sizeBytes: content.length,
      startLba,
      endLba: startLba,
      sectorCount: 1,
      contentHashSha256: `sha256_${Math.random().toString(36).substring(2, 10)}`,
      flags: 0,
      isDirectory: false,
      recordingDate: '2026-09-16 01:00:00',
      mimeType: 'text/plain',
      contentSample: content,
    };

    const disc = this.labService.currentDisc();
    disc.files.push(newFile);
    disc.usedSectors++;
    this.labService.currentDisc.set({ ...disc });
    this.newFilePath = '';
    this.newFileContent = '';
    this.labService.addEvent('FILE_READ', `Added new staged file: ${path} (${newFile.sizeBytes} bytes).`);
  }

  public async buildMasterIso(): Promise<void> {
    this.isBuilding.set(true);
    await new Promise(r => setTimeout(r, 1000));
    
    const disc = this.labService.currentDisc();
    disc.volumeDescriptors = { ...this.descriptors };
    disc.volumeLabel = this.descriptors.volumeIdentifier;
    this.labService.currentDisc.set({ ...disc });
    
    this.labService.addEvent('DISC_CREATED', `Mastered new ISO 9660 image "${disc.volumeLabel}". All P/Q parities and EDC blocks encoded successfully.`);
    this.isBuilding.set(false);
  }

  public exportIsoFile(): void {
    const rawDisc = Iso9660Engine.exportIsoBinary(this.labService.currentDisc());
    const blob = new Blob([rawDisc as unknown as BlobPart], { type: 'application/x-iso9660-image' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${this.labService.currentDisc().volumeLabel.toLowerCase().replace(/\s+/g, '_')}.iso`;
    a.click();
    URL.revokeObjectURL(url);
    this.labService.addEvent('DISC_CREATED', `Exported full ISO 9660 binary image.`);
  }
}
