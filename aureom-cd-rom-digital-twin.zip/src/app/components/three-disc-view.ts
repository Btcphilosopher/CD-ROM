// AUREOM 3D DIGITAL TWIN VIEWPORT (Three.js WebGL)
// Interactive 3D Disc Model, Exploded Layers, Spindle Motor, Radial SLED, and Laser Optical Pickup

import { Component, ElementRef, ViewChild, AfterViewInit, OnDestroy, ChangeDetectionStrategy, inject, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { OpticalLaboratoryService } from '../services/optical-laboratory.service';
import { DiscGeometryEngine } from '../core/disc-geometry';

@Component({
  selector: 'app-three-disc-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-[520px] bg-neutral-950 rounded-2xl overflow-hidden border border-neutral-800/80 shadow-2xl flex flex-col">
      <!-- Top Control Bar -->
      <div class="absolute top-3 left-3 right-3 z-10 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        <div class="pointer-events-auto flex items-center gap-1.5 bg-neutral-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-neutral-700/60 shadow-lg text-xs font-mono">
          <span class="w-2 h-2 rounded-full" [class.bg-emerald-400]="telemetry().isSpindleSpinning" [class.bg-neutral-500]="!telemetry().isSpindleSpinning"></span>
          <span class="text-neutral-300 font-medium">3D OPTICAL TWIN</span>
          <span class="text-neutral-500">|</span>
          <span class="text-cyan-400">{{ telemetry().currentRpm }} RPM</span>
          <span class="text-neutral-500">|</span>
          <span class="text-amber-400">{{ labService.cameraPreset().toUpperCase() }} VIEW</span>
        </div>

        <!-- Camera Preset Buttons -->
        <div class="pointer-events-auto flex items-center gap-1 bg-neutral-900/90 backdrop-blur-md p-1 rounded-xl border border-neutral-700/60 shadow-lg text-xs">
          <button (click)="setCameraPreset('orbit')" 
                  class="px-2.5 py-1 rounded-lg transition-all flex items-center gap-1"
                  [class.bg-cyan-500]="labService.cameraPreset() === 'orbit'"
                  [class.text-neutral-950]="labService.cameraPreset() === 'orbit'"
                  [class.text-neutral-300]="labService.cameraPreset() !== 'orbit'"
                  [class.hover:bg-neutral-800]="labService.cameraPreset() !== 'orbit'">
            <mat-icon class="text-sm scale-75">3d_rotation</mat-icon>
            <span>Orbit</span>
          </button>
          <button (click)="setCameraPreset('top')" 
                  class="px-2.5 py-1 rounded-lg transition-all"
                  [class.bg-cyan-500]="labService.cameraPreset() === 'top'"
                  [class.text-neutral-950]="labService.cameraPreset() === 'top'"
                  [class.text-neutral-300]="labService.cameraPreset() !== 'top'"
                  [class.hover:bg-neutral-800]="labService.cameraPreset() !== 'top'">
            Top
          </button>
          <button (click)="setCameraPreset('side')" 
                  class="px-2.5 py-1 rounded-lg transition-all"
                  [class.bg-cyan-500]="labService.cameraPreset() === 'side'"
                  [class.text-neutral-950]="labService.cameraPreset() === 'side'"
                  [class.text-neutral-300]="labService.cameraPreset() !== 'side'"
                  [class.hover:bg-neutral-800]="labService.cameraPreset() !== 'side'">
            Side
          </button>
          <button (click)="setCameraPreset('cross-section')" 
                  class="px-2.5 py-1 rounded-lg transition-all"
                  [class.bg-cyan-500]="labService.cameraPreset() === 'cross-section'"
                  [class.text-neutral-950]="labService.cameraPreset() === 'cross-section'"
                  [class.text-neutral-300]="labService.cameraPreset() !== 'cross-section'"
                  [class.hover:bg-neutral-800]="labService.cameraPreset() !== 'cross-section'">
            Cross-Sec
          </button>
          <button (click)="setCameraPreset('exploded')" 
                  class="px-2.5 py-1 rounded-lg transition-all flex items-center gap-1"
                  [class.bg-amber-500]="labService.cameraPreset() === 'exploded'"
                  [class.text-neutral-950]="labService.cameraPreset() === 'exploded'"
                  [class.text-neutral-300]="labService.cameraPreset() !== 'exploded'"
                  [class.hover:bg-neutral-800]="labService.cameraPreset() !== 'exploded'">
            <mat-icon class="text-sm scale-75">layers</mat-icon>
            <span>Exploded (4-Layer)</span>
          </button>
        </div>
      </div>

      <!-- Canvas Container -->
      <div #canvasContainer class="w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Bottom Overlays & Telemetry -->
      <div class="absolute bottom-3 left-3 right-3 z-10 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        <!-- Physical Sector Coordinates -->
        <div class="pointer-events-auto bg-neutral-900/90 backdrop-blur-md px-3 py-2 rounded-xl border border-neutral-700/60 shadow-lg text-xs font-mono text-neutral-300 flex items-center gap-3">
          <div>
            <span class="text-neutral-500">HEAD LBA:</span>
            <span class="text-cyan-400 font-bold ml-1">{{ telemetry().currentHeadLba }}</span>
          </div>
          <div>
            <span class="text-neutral-500">RADIUS:</span>
            <span class="text-emerald-400 font-bold ml-1">{{ telemetry().currentHeadRadiusMm.toFixed(2) }} mm</span>
          </div>
          <div>
            <span class="text-neutral-500">LASER:</span>
            <span class="text-rose-400 font-bold ml-1">{{ telemetry().laserPowerMilliWatts }} mW (780nm)</span>
          </div>
        </div>

        <!-- Exploded Layer Slider (when exploded mode active) -->
        @if (labService.cameraPreset() === 'exploded') {
          <div class="pointer-events-auto flex items-center gap-2 bg-neutral-900/95 backdrop-blur-md px-4 py-2 rounded-xl border border-amber-500/40 shadow-lg text-xs">
            <span class="text-amber-400 font-medium">Layer Separation:</span>
            <input type="range" min="0" max="1" step="0.01" 
                   [value]="labService.explodedOffset()" 
                   (input)="onExplodedSlider($event)"
                   class="w-32 cursor-pointer" />
            <span class="font-mono text-neutral-300">{{ (labService.explodedOffset() * 100).toFixed(0) }}%</span>
          </div>
        }
      </div>
    </div>
  `,
})
export class ThreeDiscView implements AfterViewInit, OnDestroy {
  public labService = inject(OpticalLaboratoryService);
  public telemetry = this.labService.driveTelemetry;
  public activeSector = this.labService.activeSector;

  @ViewChild('canvasContainer') private containerRef!: ElementRef<HTMLDivElement>;

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId = 0;

  // 3D Objects
  private discGroup = new THREE.Group();
  private spindleMesh!: THREE.Mesh;
  private pickupHeadGroup = new THREE.Group();
  private laserBeamMesh!: THREE.Mesh;
  private activeSectorMarker!: THREE.Mesh;

  // Exploded Layers
  private labelLayerMesh!: THREE.Mesh;
  private lacquerLayerMesh!: THREE.Mesh;
  private reflectiveLayerMesh!: THREE.Mesh;
  private substrateLayerMesh!: THREE.Mesh;

  // Mouse interaction
  private isDragging = false;
  private previousMousePosition = { x: 0, y: 0 };
  private cameraAngleTheta = 0.6;
  private cameraAnglePhi = 1.1;
  private cameraDistance = 140;

  constructor() {
    effect(() => {
      const preset = this.labService.cameraPreset();
      this.updateCameraToPreset(preset);
    });

    effect(() => {
      const offset = this.labService.explodedOffset();
      this.applyExplodedOffset(offset);
    });

    effect(() => {
      const sector = this.labService.activeSector();
      this.updateActiveSectorHighlight(sector.lba);
    });
  }

  public ngAfterViewInit(): void {
    if (typeof window !== 'undefined') {
      this.initThree();
      this.animate();
    }
  }

  public ngOnDestroy(): void {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  private initThree(): void {
    const container = this.containerRef.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 520;

    // 1. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0c14);

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.updateCameraPosition();

    // 3. Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    container.appendChild(this.renderer.domElement);

    // 4. Lighting (Simulating clean optical lab lights & laser reflections)
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    this.scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x38bdf8, 1.2);
    dirLight1.position.set(50, 80, 50);
    this.scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xf43f5e, 0.8);
    dirLight2.position.set(-60, 40, -40);
    this.scene.add(dirLight2);

    const pointLight = new THREE.PointLight(0xffffff, 1.0, 200);
    pointLight.position.set(0, 50, 0);
    this.scene.add(pointLight);

    // 5. Build Disc Layers and Hardware Mechanics
    this.buildDiscGeometry();
    this.buildSpindleMotor();
    this.buildOpticalPickupHead();

    this.scene.add(this.discGroup);

    // 6. Event Listeners for Orbit & Zoom
    this.setupMouseEvents(container);

    // Window resize observer
    const resizeObserver = new ResizeObserver(() => {
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (w > 0 && h > 0) {
        this.camera.aspect = w / h;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(w, h);
      }
    });
    resizeObserver.observe(container);
  }

  private buildDiscGeometry(): void {
    const outerRadius = 60.0; // 120 mm diameter
    const innerRadius = 7.5;  // 15 mm hole
    const thickness = 1.2;

    // Layer 1: Polycarbonate Substrate (Base Transparent Plastic with Pit/Land tracks)
    const substrateGeo = new THREE.CylinderGeometry(outerRadius, outerRadius, thickness * 0.8, 64, 1, false, 0, Math.PI * 2);
    const substrateMat = new THREE.MeshPhysicalMaterial({
      color: 0x94a3b8,
      transparent: true,
      opacity: 0.65,
      roughness: 0.1,
      metalness: 0.1,
      transmission: 0.7,
      ior: 1.55, // Polycarbonate refractive index
    });
    this.substrateLayerMesh = new THREE.Mesh(substrateGeo, substrateMat);
    this.discGroup.add(this.substrateLayerMesh);

    // Layer 2: Aluminum Reflective Layer (Iridescent Rainbow Diffraction)
    const reflectiveGeo = new THREE.RingGeometry(25.0, 58.0, 64);
    const reflectiveMat = new THREE.MeshStandardMaterial({
      color: 0xdbeafe,
      metalness: 0.95,
      roughness: 0.15,
      side: THREE.DoubleSide,
    });
    this.reflectiveLayerMesh = new THREE.Mesh(reflectiveGeo, reflectiveMat);
    this.reflectiveLayerMesh.rotation.x = -Math.PI / 2;
    this.reflectiveLayerMesh.position.y = 0.5;
    this.discGroup.add(this.reflectiveLayerMesh);

    // Layer 3: Protective Lacquer Layer
    const lacquerGeo = new THREE.RingGeometry(innerRadius, outerRadius, 64);
    const lacquerMat = new THREE.MeshStandardMaterial({
      color: 0x64748b,
      transparent: true,
      opacity: 0.5,
      metalness: 0.2,
      roughness: 0.3,
      side: THREE.DoubleSide,
    });
    this.lacquerLayerMesh = new THREE.Mesh(lacquerGeo, lacquerMat);
    this.lacquerLayerMesh.rotation.x = -Math.PI / 2;
    this.lacquerLayerMesh.position.y = 0.55;
    this.discGroup.add(this.lacquerLayerMesh);

    // Layer 4: Screen Printed Label Layer (Top)
    const labelGeo = new THREE.RingGeometry(13.0, 58.5, 64);
    const labelMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      metalness: 0.1,
      roughness: 0.8,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.75,
    });
    this.labelLayerMesh = new THREE.Mesh(labelGeo, labelMat);
    this.labelLayerMesh.rotation.x = -Math.PI / 2;
    this.labelLayerMesh.position.y = 0.6;
    this.discGroup.add(this.labelLayerMesh);

    // Active Sector Beacon/Marker
    const markerGeo = new THREE.SphereGeometry(1.2, 16, 16);
    const markerMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    this.activeSectorMarker = new THREE.Mesh(markerGeo, markerMat);
    this.activeSectorMarker.position.set(25, 0.8, 0);
    this.discGroup.add(this.activeSectorMarker);
  }

  private buildSpindleMotor(): void {
    // Center Spindle Hub & Clamping Ring
    const hubGeo = new THREE.CylinderGeometry(7.4, 7.4, 8, 32);
    const hubMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, roughness: 0.2 });
    this.spindleMesh = new THREE.Mesh(hubGeo, hubMat);
    this.spindleMesh.position.y = 0;
    this.scene.add(this.spindleMesh);

    // Outer clamping table
    const clampGeo = new THREE.CylinderGeometry(13, 13, 2, 32);
    const clampMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.9, roughness: 0.4 });
    const clampMesh = new THREE.Mesh(clampGeo, clampMat);
    clampMesh.position.y = -1.5;
    this.scene.add(clampMesh);
  }

  private buildOpticalPickupHead(): void {
    // SLED Base Block
    const headGeo = new THREE.BoxGeometry(16, 6, 20);
    const headMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.7, roughness: 0.3 });
    const headMesh = new THREE.Mesh(headGeo, headMat);
    this.pickupHeadGroup.add(headMesh);

    // Objective Lens Collimator
    const lensGeo = new THREE.CylinderGeometry(2, 2, 3, 16);
    const lensMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.9, roughness: 0.1 });
    const lensMesh = new THREE.Mesh(lensGeo, lensMat);
    lensMesh.position.y = 3;
    this.pickupHeadGroup.add(lensMesh);

    // Red Laser Beam (780nm infrared / visible red guide beam)
    const beamGeo = new THREE.CylinderGeometry(0.2, 0.2, 12, 8);
    const beamMat = new THREE.MeshBasicMaterial({ color: 0xff0044, transparent: true, opacity: 0.85 });
    this.laserBeamMesh = new THREE.Mesh(beamGeo, beamMat);
    this.laserBeamMesh.position.y = 9;
    this.pickupHeadGroup.add(this.laserBeamMesh);

    // Position optical pickup beneath disc at initial radius
    this.pickupHeadGroup.position.set(25, -10, 0);
    this.scene.add(this.pickupHeadGroup);
  }

  private setupMouseEvents(container: HTMLElement): void {
    container.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isDragging) return;
      const deltaX = e.clientX - this.previousMousePosition.x;
      const deltaY = e.clientY - this.previousMousePosition.y;

      this.cameraAngleTheta -= deltaX * 0.008;
      this.cameraAnglePhi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, this.cameraAnglePhi - deltaY * 0.008));

      this.updateCameraPosition();
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    container.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.cameraDistance = Math.max(40, Math.min(300, this.cameraDistance + e.deltaY * 0.2));
      this.updateCameraPosition();
    }, { passive: false });
  }

  private updateCameraPosition(): void {
    if (!this.camera) return;
    this.camera.position.x = this.cameraDistance * Math.sin(this.cameraAnglePhi) * Math.sin(this.cameraAngleTheta);
    this.camera.position.y = this.cameraDistance * Math.cos(this.cameraAnglePhi);
    this.camera.position.z = this.cameraDistance * Math.sin(this.cameraAnglePhi) * Math.cos(this.cameraAngleTheta);
    this.camera.lookAt(0, 0, 0);
  }

  public setCameraPreset(preset: 'orbit' | 'top' | 'side' | 'cross-section' | 'microscopic' | 'exploded'): void {
    this.labService.cameraPreset.set(preset);
    this.updateCameraToPreset(preset);
  }

  private updateCameraToPreset(preset: string): void {
    if (preset === 'top') {
      this.cameraAnglePhi = 0.05;
      this.cameraAngleTheta = 0;
      this.cameraDistance = 150;
      this.labService.explodedOffset.set(0);
    } else if (preset === 'side') {
      this.cameraAnglePhi = Math.PI / 2 - 0.05;
      this.cameraAngleTheta = 0;
      this.cameraDistance = 140;
      this.labService.explodedOffset.set(0);
    } else if (preset === 'cross-section') {
      this.cameraAnglePhi = 0.8;
      this.cameraAngleTheta = 0.5;
      this.cameraDistance = 90;
      this.labService.explodedOffset.set(0.3);
    } else if (preset === 'microscopic') {
      this.cameraAnglePhi = 0.9;
      this.cameraAngleTheta = 0.3;
      this.cameraDistance = 45;
      this.labService.explodedOffset.set(0);
    } else if (preset === 'exploded') {
      this.cameraAnglePhi = 1.0;
      this.cameraAngleTheta = 0.7;
      this.cameraDistance = 160;
      this.labService.explodedOffset.set(0.65);
    } else {
      // Orbit default
      this.cameraAnglePhi = 1.1;
      this.cameraAngleTheta = 0.6;
      this.cameraDistance = 140;
      this.labService.explodedOffset.set(0);
    }
    this.updateCameraPosition();
  }

  public onExplodedSlider(e: Event): void {
    const val = parseFloat((e.target as HTMLInputElement).value);
    this.labService.explodedOffset.set(val);
  }

  private applyExplodedOffset(offset: number): void {
    if (!this.substrateLayerMesh) return;
    const maxSeparation = 25; // mm
    this.substrateLayerMesh.position.y = -offset * maxSeparation * 0.5;
    this.reflectiveLayerMesh.position.y = 0.5;
    this.lacquerLayerMesh.position.y = 0.5 + offset * maxSeparation * 0.4;
    this.labelLayerMesh.position.y = 0.6 + offset * maxSeparation * 0.8;
  }

  private updateActiveSectorHighlight(lba: number): void {
    if (!this.activeSectorMarker || !this.pickupHeadGroup) return;
    const polar = DiscGeometryEngine.lbaToPolar(lba);
    const cart = DiscGeometryEngine.polarToCartesian(polar);

    // Update marker on disc
    this.activeSectorMarker.position.set(cart.xMm, 0.8, cart.yMm);

    // Update optical pickup head radial position
    this.pickupHeadGroup.position.set(polar.radiusMm, -10, 0);
  }

  private animate = (): void => {
    this.animationFrameId = requestAnimationFrame(this.animate);

    const telem = this.telemetry();
    if (telem.isSpindleSpinning && telem.currentRpm > 0) {
      // Angular velocity in rad/frame approx
      const rotationSpeed = (telem.currentRpm / 60) * 0.05;
      this.discGroup.rotation.y += rotationSpeed;
      if (this.spindleMesh) {
        this.spindleMesh.rotation.y += rotationSpeed;
      }
    }

    // Laser beam pulsation while reading
    if (this.laserBeamMesh) {
      if (telem.state === 'READING' || telem.state === 'SEEKING') {
        this.laserBeamMesh.visible = true;
        const scale = 1.0 + Math.sin(Date.now() * 0.02) * 0.15;
        this.laserBeamMesh.scale.set(scale, 1, scale);
      } else {
        this.laserBeamMesh.visible = false;
      }
    }

    this.renderer.render(this.scene, this.camera);
  };
}
