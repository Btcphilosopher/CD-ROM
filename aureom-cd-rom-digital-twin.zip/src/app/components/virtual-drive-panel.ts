// AUREOM VIRTUAL CD-ROM DRIVE CONTROLLER & TELEMETRY DECK
// Drive Mechanics, Spindle Speed Control, Eye-Pattern Oscilloscope, S-Curve Focus & Buffer Monitor

import { Component, ElementRef, ViewChild, AfterViewInit, OnDestroy, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { OpticalLaboratoryService } from '../services/optical-laboratory.service';
import { SpeedMultiplier } from '../core/models';

@Component({
  selector: 'app-virtual-drive-panel',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
      <!-- Left Column: Front Panel & Physical Drive Controls -->
      <div class="lg:col-span-5 flex flex-col gap-4">
        <!-- Physical Bezel Card -->
        <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-4">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
            <div class="flex items-center gap-2">
              <div class="p-2 bg-cyan-500/10 text-cyan-400 rounded-xl">
                <mat-icon>album</mat-icon>
              </div>
              <div>
                <h3 class="font-display font-semibold text-sm text-neutral-100">AUREOM OPTICA-5200</h3>
                <p class="text-[11px] text-neutral-400 font-mono">ATAPI / SCSI-II Optical Subsystem</p>
              </div>
            </div>

            <!-- Drive Status LED and Tray State -->
            <div class="flex items-center gap-2 font-mono text-xs">
              <div class="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-neutral-950 border border-neutral-800">
                <span class="w-2 h-2 rounded-full animate-pulse"
                      [class.bg-emerald-400]="telemetry().state === 'READY' || telemetry().state === 'READING'"
                      [class.bg-amber-400]="telemetry().state === 'SPINNING_UP' || telemetry().state === 'SEEKING'"
                      [class.bg-rose-500]="telemetry().state === 'ERROR'"
                      [class.bg-neutral-500]="telemetry().state === 'OPEN' || telemetry().state === 'EMPTY'"></span>
                <span class="text-neutral-300 font-bold">{{ telemetry().state }}</span>
              </div>
            </div>
          </div>

          <!-- Front Bezel Controls -->
          <div class="bg-neutral-950 p-4 rounded-xl border border-neutral-800 flex flex-col gap-3">
            <div class="flex items-center justify-between">
              <!-- Eject Button -->
              <button (click)="labService.toggleDriveTray()" 
                      class="px-4 py-2.5 rounded-xl border flex items-center gap-2 text-xs font-mono font-semibold transition-all shadow-md"
                      [class.bg-amber-500/20]="telemetry().trayOpen"
                      [class.border-amber-500/40]="telemetry().trayOpen"
                      [class.text-amber-300]="telemetry().trayOpen"
                      [class.bg-neutral-800]="!telemetry().trayOpen"
                      [class.border-neutral-700]="!telemetry().trayOpen"
                      [class.text-neutral-200]="!telemetry().trayOpen">
                <mat-icon class="scale-90">{{ telemetry().trayOpen ? 'eject' : 'eject' }}</mat-icon>
                <span>{{ telemetry().trayOpen ? 'CLOSE TRAY' : 'EJECT TRAY' }}</span>
              </button>

              <!-- Sound Toggle -->
              <button (click)="labService.toggleAcoustics()"
                      class="px-3 py-2 rounded-xl text-xs font-mono flex items-center gap-1.5 transition-all border"
                      [class.bg-cyan-500/20]="telemetry().acousticsActive"
                      [class.border-cyan-500/40]="telemetry().acousticsActive"
                      [class.text-cyan-300]="telemetry().acousticsActive"
                      [class.bg-neutral-900]="!telemetry().acousticsActive"
                      [class.border-neutral-800]="!telemetry().acousticsActive"
                      [class.text-neutral-400]="!telemetry().acousticsActive">
                <mat-icon class="scale-75">{{ telemetry().acousticsActive ? 'volume_up' : 'volume_off' }}</mat-icon>
                <span>Drive Audio</span>
              </button>
            </div>

            <!-- Manual Seek & Read Test -->
            <div class="flex items-center gap-2 pt-2 border-t border-neutral-900">
              <input type="number" 
                     #seekInput 
                     [value]="telemetry().currentHeadLba" 
                     min="0" 
                     [max]="labService.currentDisc().usedSectors - 1"
                     class="w-24 bg-neutral-900 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-xs font-mono text-cyan-400 font-bold focus:outline-none" />
              <button (click)="readTargetLba(seekInput.valueAsNumber)"
                      class="flex-1 py-1.5 px-3 rounded-lg bg-cyan-500 text-neutral-950 font-mono font-bold text-xs hover:bg-cyan-400 transition-all flex items-center justify-center gap-1">
                <mat-icon class="scale-75">sensors</mat-icon>
                <span>Seek & Read LBA</span>
              </button>
            </div>
          </div>

          <!-- Speed Profile Selector (1x to 52x) -->
          <div class="flex flex-col gap-2">
            <span class="text-xs font-mono text-neutral-400 flex items-center justify-between">
              <span>Drive Speed Multiplier:</span>
              <span class="text-cyan-400 font-bold">{{ telemetry().currentSpeed }}x ({{ telemetry().currentSpeed * 150 }} KB/s)</span>
            </span>
            <div class="grid grid-cols-5 gap-1.5 font-mono text-xs">
              @for (spd of speedProfiles; track spd) {
                <button (click)="labService.setDriveSpeed(spd)" 
                        class="py-1.5 rounded-lg border transition-all text-center"
                        [class.bg-cyan-500]="telemetry().currentSpeed === spd"
                        [class.text-neutral-950]="telemetry().currentSpeed === spd"
                        [class.font-bold]="telemetry().currentSpeed === spd"
                        [class.border-cyan-400]="telemetry().currentSpeed === spd"
                        [class.bg-neutral-950]="telemetry().currentSpeed !== spd"
                        [class.border-neutral-800]="telemetry().currentSpeed !== spd"
                        [class.text-neutral-400]="telemetry().currentSpeed !== spd">
                  {{ spd }}x
                </button>
              }
            </div>
          </div>

          <!-- Spindle Tachometer Gauge -->
          <div class="bg-neutral-950 p-4 rounded-xl border border-neutral-800 flex flex-col gap-2 font-mono text-xs">
            <div class="flex items-center justify-between">
              <span class="text-neutral-400">Spindle Motor Speed</span>
              <span class="text-emerald-400 font-bold text-sm">{{ telemetry().currentRpm }} RPM</span>
            </div>
            <div class="w-full bg-neutral-900 h-2.5 rounded-full overflow-hidden border border-neutral-800">
              <div class="bg-gradient-to-r from-cyan-500 to-emerald-400 h-full transition-all duration-300"
                   [style.width.%]="(telemetry().currentRpm / 10400) * 100"></div>
            </div>
            <div class="flex items-center justify-between text-[10px] text-neutral-500">
              <span>0 RPM</span>
              <span>Target: {{ telemetry().targetRpm }} RPM</span>
              <span>Max 52x: 10,400 RPM</span>
            </div>
          </div>

          <!-- Sector Buffer Monitor -->
          <div class="bg-neutral-950 p-4 rounded-xl border border-neutral-800 flex flex-col gap-2 font-mono text-xs">
            <div class="flex items-center justify-between">
              <span class="text-neutral-400">ATAPI FIFO Ring Buffer</span>
              <span class="text-cyan-400 font-bold">{{ telemetry().bufferUsedBytes / 1024 }} / {{ telemetry().bufferCapacityBytes / 1024 }} KB ({{ telemetry().bufferUtilizationPercent }}%)</span>
            </div>
            <div class="w-full bg-neutral-900 h-2 rounded-full overflow-hidden border border-neutral-800">
              <div class="bg-cyan-500 h-full transition-all duration-300"
                   [style.width.%]="telemetry().bufferUtilizationPercent"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Right Column: Live RF Eye Pattern Oscilloscope & Signal Telemetry -->
      <div class="lg:col-span-7 flex flex-col gap-4">
        <div class="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-4">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
            <div class="flex items-center gap-2">
              <div class="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl">
                <mat-icon>show_chart</mat-icon>
              </div>
              <div>
                <h3 class="font-display font-semibold text-sm text-neutral-100">Photodiode RF Eye Pattern Oscilloscope</h3>
                <p class="text-[11px] text-neutral-400 font-mono">Four-Quadrant Central Aperture (A+B+C+D) RF Signal</p>
              </div>
            </div>
            <span class="text-xs font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              780nm AlGaAs Laser
            </span>
          </div>

          <!-- Oscilloscope Screen Canvas -->
          <div class="relative w-full h-60 bg-neutral-950 rounded-xl overflow-hidden border border-emerald-950/60 p-2 scanlines tech-grid-dense flex items-center justify-center">
            <canvas #scopeCanvas class="w-full h-full"></canvas>
            <div class="absolute top-3 left-3 text-[10px] font-mono text-emerald-500/80 bg-neutral-950/80 px-2 py-1 rounded border border-emerald-900/40">
              CH1: RF (0.2V/div) | TB: 20ns/div | JITTER: 180ps
            </div>
          </div>

          <!-- S-Curve Focus & Push-Pull Tracking Error Meters -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono text-xs">
            <!-- Focus Error (Astigmatic Method) -->
            <div class="bg-neutral-950 p-3.5 rounded-xl border border-neutral-800 flex flex-col gap-1.5">
              <div class="flex items-center justify-between text-neutral-400">
                <span>Focus Error (FE):</span>
                <span class="text-cyan-400 font-bold">{{ (telemetry().focusErrorSignal * 1000).toFixed(1) }} mV</span>
              </div>
              <div class="relative w-full bg-neutral-900 h-2 rounded-full overflow-hidden">
                <div class="absolute top-0 bottom-0 w-1.5 bg-cyan-400 rounded-full transition-all duration-150"
                     [style.left.%]="50 + telemetry().focusErrorSignal * 500"></div>
              </div>
              <span class="text-[10px] text-neutral-500 text-center">-Astigmatic S-Curve (Focus Lock OK)-</span>
            </div>

            <!-- Tracking Error (Push-Pull Method) -->
            <div class="bg-neutral-950 p-3.5 rounded-xl border border-neutral-800 flex flex-col gap-1.5">
              <div class="flex items-center justify-between text-neutral-400">
                <span>Tracking Error (TE):</span>
                <span class="text-emerald-400 font-bold">{{ (telemetry().trackingErrorSignal * 1000).toFixed(1) }} mV</span>
              </div>
              <div class="relative w-full bg-neutral-900 h-2 rounded-full overflow-hidden">
                <div class="absolute top-0 bottom-0 w-1.5 bg-emerald-400 rounded-full transition-all duration-150"
                     [style.left.%]="50 + telemetry().trackingErrorSignal * 500"></div>
              </div>
              <span class="text-[10px] text-neutral-500 text-center">-Push-Pull Radial Differential Lock-</span>
            </div>
          </div>

          <!-- Read Retry & Host Interface Telemetry Log -->
          @if (labService.lastReadResult(); as res) {
            <div class="p-3 bg-neutral-950 border border-neutral-800 rounded-xl font-mono text-xs flex flex-col gap-1">
              <div class="flex items-center justify-between text-neutral-300">
                <span class="text-neutral-500">LAST I/O OP:</span>
                <span class="text-cyan-400 font-bold">LBA {{ res.lba }} ({{ res.sector ? res.sector.absoluteMsf : '--:--:--' }})</span>
                <span class="text-emerald-400">Seek: {{ res.seekTimeMs.toFixed(1) }}ms</span>
                <span class="text-amber-400">Read: {{ res.readTimeMs.toFixed(1) }}ms</span>
                <span class="text-purple-400">Retries: {{ res.retriesUsed }}</span>
              </div>
              <p class="text-[11px]" [class.text-emerald-400]="res.success" [class.text-rose-400]="!res.success">
                {{ res.statusMessage }}
              </p>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class VirtualDrivePanel implements AfterViewInit, OnDestroy {
  public labService = inject(OpticalLaboratoryService);
  public telemetry = this.labService.driveTelemetry;

  @ViewChild('scopeCanvas') private scopeCanvasRef!: ElementRef<HTMLCanvasElement>;

  public speedProfiles: SpeedMultiplier[] = [1, 2, 4, 8, 12, 16, 24, 32, 40, 52];
  private animFrameId = 0;

  public ngAfterViewInit(): void {
    if (typeof window !== 'undefined') {
      this.drawScope();
    }
  }

  public ngOnDestroy(): void {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
    }
  }

  public readTargetLba(lba: number): void {
    if (!isNaN(lba)) {
      this.labService.readSector(lba);
    }
  }

  private drawScope = (): void => {
    this.animFrameId = requestAnimationFrame(this.drawScope);
    const canvas = this.scopeCanvasRef?.nativeElement;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = (canvas.width = canvas.clientWidth);
    const height = (canvas.height = canvas.clientHeight);

    ctx.fillStyle = '#05070c';
    ctx.fillRect(0, 0, width, height);

    // Draw Grid Lines
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.12)';
    ctx.lineWidth = 1;
    const gridCols = 10;
    const gridRows = 6;
    for (let c = 0; c <= gridCols; c++) {
      const x = (width / gridCols) * c;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let r = 0; r <= gridRows; r++) {
      const y = (height / gridRows) * r;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Draw Eye Pattern (Superimposed 3T to 11T transitions)
    const isReading = this.telemetry().state === 'READING' || this.telemetry().state === 'READY';
    const amplitude = isReading ? height * 0.35 : 0;
    const centerY = height / 2;
    const time = Date.now() * 0.005;

    ctx.strokeStyle = 'rgba(52, 211, 153, 0.75)';
    ctx.lineWidth = 1.5;

    const runLengths = [3, 4, 5, 6, 7, 8, 9, 10, 11];
    for (const T of runLengths) {
      ctx.beginPath();
      for (let x = 0; x < width; x += 3) {
        const tVal = (x / (T * 6) + time) * Math.PI * 2;
        const noise = (Math.random() - 0.5) * 4;
        const y = centerY + Math.sin(tVal) * amplitude + noise;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Inverted eye curve
      ctx.beginPath();
      for (let x = 0; x < width; x += 3) {
        const tVal = (x / (T * 6) + time) * Math.PI * 2;
        const noise = (Math.random() - 0.5) * 4;
        const y = centerY - Math.sin(tVal) * amplitude + noise;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
  };
}
