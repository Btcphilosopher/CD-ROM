from pathlib import Path

import pytest

from cdoptimiser.core.exceptions import ScanError
from cdoptimiser.scanning.filesystem_scanner import scan_dataset, total_size_bytes


def make_dataset(tmp_path: Path) -> Path:
    root = tmp_path / "dataset"
    (root / "docs").mkdir(parents=True)
    (root / "docs" / "a.txt").write_text("hello")
    (root / "docs" / "b.txt").write_text("world!")
    (root / ".hidden").write_text("secret")
    return root


def test_scan_finds_all_regular_files(tmp_path: Path):
    root = make_dataset(tmp_path)
    files = scan_dataset(root)
    names = {str(f.relative_path) for f in files}
    assert names == {"docs/a.txt", "docs/b.txt", ".hidden"}


def test_scan_computes_hashes_and_sizes(tmp_path: Path):
    root = make_dataset(tmp_path)
    files = scan_dataset(root)
    a = next(f for f in files if f.relative_path.name == "a.txt")
    assert a.size_bytes == 5
    assert a.sha256 is not None and len(a.sha256) == 64


def test_scan_missing_path_raises(tmp_path: Path):
    with pytest.raises(ScanError):
        scan_dataset(tmp_path / "does-not-exist")


def test_scan_file_path_raises(tmp_path: Path):
    f = tmp_path / "not_a_dir.txt"
    f.write_text("x")
    with pytest.raises(ScanError):
        scan_dataset(f)


def test_scan_does_not_follow_symlinks_by_default(tmp_path: Path):
    root = tmp_path / "dataset"
    root.mkdir()
    target = tmp_path / "outside.txt"
    target.write_text("outside content")
    link = root / "link.txt"
    try:
        link.symlink_to(target)
    except (OSError, NotImplementedError):
        pytest.skip("symlinks not supported in this environment")

    files = scan_dataset(root)
    linked = next(f for f in files if f.relative_path.name == "link.txt")
    assert linked.is_symlink is True
    assert linked.sha256 is None


def test_total_size_bytes(tmp_path: Path):
    root = make_dataset(tmp_path)
    files = scan_dataset(root)
    assert total_size_bytes(files) == sum(f.size_bytes for f in files)
