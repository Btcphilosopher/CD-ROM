from pathlib import Path

import pytest

from cdoptimiser.compression.compression_benchmark import SelectionWeights, benchmark_file, select_best
from cdoptimiser.compression.stdlib_engines import Bz2Engine, GzipEngine, LzmaEngine, StoreEngine
from cdoptimiser.core.hashing import sha256_file

ENGINES = [StoreEngine(), GzipEngine(), Bz2Engine(), LzmaEngine()]


@pytest.mark.parametrize("engine", ENGINES, ids=lambda e: e.name.value)
def test_round_trip_preserves_content(tmp_path: Path, engine):
    source = tmp_path / "source.txt"
    source.write_text("The quick brown fox jumps over the lazy dog. " * 500)
    compressed = tmp_path / f"out.{engine.name.value}"
    result = engine.compress(source, compressed)
    assert result.compressed_size_bytes == compressed.stat().st_size
    assert result.original_size_bytes == source.stat().st_size

    recovered = tmp_path / "recovered.txt"
    engine.decompress(compressed, recovered)
    assert sha256_file(recovered) == sha256_file(source)


@pytest.mark.parametrize("engine", ENGINES, ids=lambda e: e.name.value)
def test_empty_file_round_trip(tmp_path: Path, engine):
    source = tmp_path / "empty.txt"
    source.write_bytes(b"")
    compressed = tmp_path / f"empty.{engine.name.value}"
    engine.compress(source, compressed)
    recovered = tmp_path / "empty_recovered.txt"
    engine.decompress(compressed, recovered)
    assert recovered.read_bytes() == b""


def test_highly_redundant_text_compresses_well(tmp_path: Path):
    source = tmp_path / "redundant.txt"
    source.write_text("A" * 100_000)
    compressed = tmp_path / "redundant.lzma"
    result = LzmaEngine().compress(source, compressed)
    assert result.ratio > 50  # trivially redundant data compresses drastically


def test_benchmark_file_sorts_by_compressed_size(tmp_path: Path):
    source = tmp_path / "data.txt"
    source.write_text("repeat this line. " * 2000)
    results = benchmark_file(source, tmp_path / "work")
    sizes = [r.compressed_size_bytes for r in results]
    assert sizes == sorted(sizes)


def test_select_best_does_not_always_pick_smallest_if_time_dominates(tmp_path: Path):
    source = tmp_path / "data.txt"
    source.write_text("repeat this line. " * 5000)
    results = benchmark_file(source, tmp_path / "work")
    # With zero time penalty, best == smallest compressed size.
    best_by_size = min(results, key=lambda r: r.compressed_size_bytes)
    picked = select_best(results, SelectionWeights(stored_size=1.0, time_penalty=0.0))
    assert picked.compressed_size_bytes == best_by_size.compressed_size_bytes


def test_select_best_requires_results():
    with pytest.raises(ValueError):
        select_best([])
