from pathlib import Path

from cdoptimiser.core.enums import FileCategory
from cdoptimiser.core.models import ScannedFile
from cdoptimiser.scanning.file_classifier import classify_file, recommendation_for


def make_file(ext: str) -> ScannedFile:
    return ScannedFile(
        absolute_path=Path(f"/tmp/x{ext}"),
        relative_path=Path(f"x{ext}"),
        size_bytes=100,
        modified_at=0.0,
        extension=ext,
        mime_type=None,
        is_symlink=False,
    )


def test_text_is_highly_compressible():
    assert classify_file(make_file(".txt")) == FileCategory.HIGHLY_COMPRESSIBLE
    assert classify_file(make_file(".csv")) == FileCategory.HIGHLY_COMPRESSIBLE
    assert classify_file(make_file(".json")) == FileCategory.HIGHLY_COMPRESSIBLE


def test_jpeg_is_already_compressed():
    assert classify_file(make_file(".jpg")) == FileCategory.ALREADY_COMPRESSED


def test_mp3_is_already_compressed():
    assert classify_file(make_file(".mp3")) == FileCategory.ALREADY_COMPRESSED


def test_unknown_extension():
    assert classify_file(make_file(".xyz123")) == FileCategory.UNKNOWN


def test_recommendation_never_suggests_recompressing_jpeg():
    f = make_file(".jpg")
    f.category = classify_file(f)
    rec = recommendation_for(f)
    assert rec["compression"] == "low expected benefit"
    assert "already compressed" in rec["reason"]
    assert rec["action"] == "store without recompression"


def test_recommendation_for_text_suggests_compression():
    f = make_file(".txt")
    f.category = classify_file(f)
    rec = recommendation_for(f)
    assert rec["compression"] == "high expected benefit"
