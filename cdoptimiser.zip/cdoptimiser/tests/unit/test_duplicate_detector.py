from pathlib import Path

from cdoptimiser.scanning.duplicate_detector import (
    annotate_duplicate_groups,
    duplicate_savings_bytes,
    find_duplicate_groups,
)
from cdoptimiser.scanning.filesystem_scanner import scan_dataset


def make_dataset_with_duplicates(tmp_path: Path) -> Path:
    root = tmp_path / "dataset"
    root.mkdir()
    (root / "a.txt").write_text("duplicate content")
    (root / "b.txt").write_text("duplicate content")
    (root / "c.txt").write_text("unique content")
    return root


def test_find_duplicate_groups(tmp_path: Path):
    root = make_dataset_with_duplicates(tmp_path)
    files = scan_dataset(root)
    groups = find_duplicate_groups(files)
    assert len(groups) == 1
    (group,) = groups.values()
    assert {f.relative_path.name for f in group} == {"a.txt", "b.txt"}


def test_annotate_duplicate_groups_mutates(tmp_path: Path):
    root = make_dataset_with_duplicates(tmp_path)
    files = scan_dataset(root)
    annotate_duplicate_groups(files)
    a = next(f for f in files if f.relative_path.name == "a.txt")
    b = next(f for f in files if f.relative_path.name == "b.txt")
    c = next(f for f in files if f.relative_path.name == "c.txt")
    assert a.duplicate_group is not None
    assert a.duplicate_group == b.duplicate_group
    assert c.duplicate_group is None


def test_duplicate_savings_bytes(tmp_path: Path):
    root = make_dataset_with_duplicates(tmp_path)
    files = scan_dataset(root)
    groups = find_duplicate_groups(files)
    savings = duplicate_savings_bytes(groups)
    # one redundant copy of "duplicate content" (18 bytes)
    assert savings == len(b"duplicate content")


def test_no_duplicates_returns_empty(tmp_path: Path):
    root = tmp_path / "dataset"
    root.mkdir()
    (root / "a.txt").write_text("one")
    (root / "b.txt").write_text("two")
    files = scan_dataset(root)
    assert find_duplicate_groups(files) == {}
