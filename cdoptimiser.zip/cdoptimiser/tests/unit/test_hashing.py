from pathlib import Path

from cdoptimiser.core.hashing import sha256_bytes, sha256_dataset, sha256_file


def test_sha256_file_matches_known_digest(tmp_path: Path):
    p = tmp_path / "a.txt"
    p.write_bytes(b"hello world")
    assert sha256_file(p) == sha256_bytes(b"hello world")


def test_sha256_file_chunked_matches_unchunked(tmp_path: Path):
    p = tmp_path / "big.bin"
    data = (b"x" * 5000) + (b"y" * 5000)
    p.write_bytes(data)
    small_chunk = sha256_file(p, chunk_size=64)
    default_chunk = sha256_file(p)
    assert small_chunk == default_chunk == sha256_bytes(data)


def test_sha256_dataset_is_order_independent():
    h1 = sha256_dataset(["aaa", "bbb", "ccc"])
    h2 = sha256_dataset(["ccc", "aaa", "bbb"])
    assert h1 == h2


def test_sha256_dataset_changes_with_content():
    h1 = sha256_dataset(["aaa", "bbb"])
    h2 = sha256_dataset(["aaa", "bbc"])
    assert h1 != h2
