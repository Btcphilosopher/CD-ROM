from cdoptimiser.core.units import (
    bytes_to_mebibytes,
    bytes_to_megabytes,
    compression_ratio,
    format_bytes_binary,
    format_bytes_decimal,
    percentage_saved,
    sectors_for_bytes,
)


def test_bytes_to_mebibytes():
    assert bytes_to_mebibytes(1024 * 1024) == 1.0


def test_bytes_to_megabytes():
    assert bytes_to_megabytes(1_000_000) == 1.0


def test_binary_vs_decimal_diverge():
    # 700 MB (decimal) is less than 700 MiB (binary) — the classic CD-ROM
    # labelling confusion. The two helpers must not silently agree.
    assert bytes_to_mebibytes(700_000_000) < 700.0
    assert bytes_to_megabytes(700_000_000) == 700.0


def test_format_bytes_binary():
    assert format_bytes_binary(0) == "0 B"
    assert format_bytes_binary(1024) == "1.00 KiB"
    assert format_bytes_binary(1024 * 1024) == "1.00 MiB"


def test_format_bytes_decimal():
    assert format_bytes_decimal(1_000_000) == "1.00 MB"


def test_sectors_for_bytes_rounds_up():
    assert sectors_for_bytes(2048, 2048) == 1
    assert sectors_for_bytes(2049, 2048) == 2
    assert sectors_for_bytes(0, 2048) == 0


def test_sectors_for_bytes_rejects_bad_block_size():
    import pytest

    with pytest.raises(ValueError):
        sectors_for_bytes(100, 0)


def test_compression_ratio():
    assert compression_ratio(1000, 500) == 2.0
    assert compression_ratio(0, 0) == 1.0


def test_percentage_saved():
    assert percentage_saved(1000, 500) == 50.0
    assert percentage_saved(1000, 1000) == 0.0
    assert percentage_saved(0, 0) == 0.0
