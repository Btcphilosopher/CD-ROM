from cdoptimiser.analysis.capacity_analyser import build_capacity_breakdown, evaluate_against_all_standard_profiles
from cdoptimiser.core.models import STANDARD_DISC_PROFILES


def test_capacity_breakdown_fits_when_small():
    profile = STANDARD_DISC_PROFILES["cd_700_mb"]
    breakdown = build_capacity_breakdown(
        disc_profile=profile,
        stored_payload_bytes=1_000_000,
        original_logical_bytes=2_000_000,
        file_count=10,
        directory_count=1,
        file_sizes_bytes=[100_000] * 10,
    )
    assert breakdown.fits is True
    assert breakdown.remaining_bytes > 0
    assert breakdown.compression_multiplier == 2.0


def test_capacity_breakdown_overflow_detected():
    profile = STANDARD_DISC_PROFILES["cd_650_mb"]
    breakdown = build_capacity_breakdown(
        disc_profile=profile,
        stored_payload_bytes=800 * 1024 * 1024,
        original_logical_bytes=800 * 1024 * 1024,
        file_count=5,
        directory_count=1,
        file_sizes_bytes=[100_000] * 5,
    )
    assert breakdown.fits is False
    assert breakdown.remaining_bytes < 0


def test_capacity_never_claims_physical_capacity_increases():
    # The physical capacity figure must equal the disc profile's nominal
    # capacity regardless of how well the data compresses.
    profile = STANDARD_DISC_PROFILES["cd_700_mb"]
    breakdown = build_capacity_breakdown(
        disc_profile=profile,
        stored_payload_bytes=1,
        original_logical_bytes=10_000_000_000,  # huge logical content, tiny stored size
        file_count=1,
        directory_count=1,
        file_sizes_bytes=[1],
    )
    assert breakdown.physical_capacity_bytes == profile.nominal_capacity_bytes


def test_evaluate_against_all_standard_profiles_returns_every_profile():
    results = evaluate_against_all_standard_profiles(
        stored_payload_bytes=1000,
        original_logical_bytes=2000,
        file_count=1,
        directory_count=1,
        file_sizes_bytes=[1000],
    )
    assert set(results.keys()) == set(STANDARD_DISC_PROFILES.keys())


def test_alignment_waste_rounds_up_to_full_sectors():
    profile = STANDARD_DISC_PROFILES["cd_700_mb"]
    # A single 1-byte file wastes (block_size - 1) bytes to sector alignment.
    breakdown = build_capacity_breakdown(
        disc_profile=profile,
        stored_payload_bytes=1,
        original_logical_bytes=1,
        file_count=1,
        directory_count=1,
        file_sizes_bytes=[1],
    )
    assert breakdown.filesystem_overhead_bytes >= profile.logical_block_size - 1
