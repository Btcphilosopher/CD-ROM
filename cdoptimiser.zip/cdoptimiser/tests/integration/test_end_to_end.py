"""End-to-end test of the CDOPTIMISER vertical slice (spec section 22).

Scans a real mixed-content dataset, builds a packed+compressed archive,
writes a manifest, computes a capacity report against 650/700 MB profiles,
then round-trip verifies that every recovered file's SHA-256 matches the
original — proving the archive is genuinely recoverable, not just smaller.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from cdoptimiser.analysis.capacity_analyser import build_capacity_breakdown
from cdoptimiser.archive.manifest_io import read_manifest, write_manifest
from cdoptimiser.core.hashing import sha256_file
from cdoptimiser.core.models import STANDARD_DISC_PROFILES
from cdoptimiser.optimisation.pipeline import build_optimised_archive
from cdoptimiser.scanning.duplicate_detector import annotate_duplicate_groups
from cdoptimiser.verification.round_trip_validator import verify_archive

SAMPLE_DATASET = Path(__file__).resolve().parents[2] / "examples" / "sample_dataset"


@pytest.fixture(scope="module")
def built_archive(tmp_path_factory):
    output_dir = tmp_path_factory.mktemp("optimised")
    archive_path, manifest, files = build_optimised_archive(SAMPLE_DATASET, output_dir, policy_name="balanced")
    manifest_path = output_dir / f"{manifest.archive_id}.manifest.json"
    write_manifest(manifest, manifest_path)
    return archive_path, manifest_path, manifest, files


def test_archive_and_manifest_are_created(built_archive):
    archive_path, manifest_path, manifest, files = built_archive
    assert archive_path.exists()
    assert manifest_path.exists()
    assert len(manifest.files) == len(files)


def test_manifest_round_trips_through_json(built_archive):
    _, manifest_path, manifest, _ = built_archive
    reloaded = read_manifest(manifest_path)
    assert reloaded.archive_id == manifest.archive_id
    assert reloaded.total_original_bytes == manifest.total_original_bytes
    assert {f.relative_path for f in reloaded.files} == {f.relative_path for f in manifest.files}


def test_already_compressed_media_is_stored_not_recompressed(built_archive):
    _, _, manifest, _ = built_archive
    jpeg_entry = next(f for f in manifest.files if f.relative_path.endswith(".jpg"))
    mp3_entry = next(f for f in manifest.files if f.relative_path.endswith(".mp3"))
    assert jpeg_entry.stored_algorithm == "store"
    assert mp3_entry.stored_algorithm == "store"


def test_text_content_is_compressed(built_archive):
    _, _, manifest, _ = built_archive
    txt_entry = next(f for f in manifest.files if f.relative_path.endswith("report-001.txt"))
    assert txt_entry.stored_algorithm != "store"
    assert txt_entry.stored_size_bytes < txt_entry.original_size_bytes


def test_compression_achieves_real_savings(built_archive):
    _, _, manifest, _ = built_archive
    assert manifest.total_stored_bytes < manifest.total_original_bytes


def test_duplicate_reports_are_detected_in_source(built_archive):
    _, _, _, files = built_archive
    groups = annotate_duplicate_groups(files)
    assert len(groups) >= 1  # report-001.txt and report-002.txt are identical


def test_capacity_report_against_700mb_profile(built_archive):
    archive_path, _, manifest, files = built_archive
    profile = STANDARD_DISC_PROFILES["cd_700_mb"]
    file_sizes = [f.size_bytes for f in files if not f.is_symlink]
    directories = {str(f.relative_path.parent) for f in files}
    breakdown = build_capacity_breakdown(
        disc_profile=profile,
        stored_payload_bytes=archive_path.stat().st_size,
        original_logical_bytes=manifest.total_original_bytes,
        file_count=len(file_sizes),
        directory_count=len(directories),
        file_sizes_bytes=file_sizes,
    )
    # This small demo dataset must comfortably fit on a single 700 MB disc.
    assert breakdown.fits is True
    assert breakdown.physical_capacity_bytes == profile.nominal_capacity_bytes


def test_full_round_trip_recovery_matches_original_hashes(built_archive, tmp_path):
    archive_path, manifest_path, manifest, files = built_archive
    report = verify_archive(archive_path, manifest_path, extract_to=tmp_path / "recovered")
    assert report.all_matched, [
        (r.relative_path, r.note) for r in report.failed_files
    ]

    # Cross-check independently against the live source files, not just the
    # manifest's own recorded hashes, to rule out a manifest that is
    # internally consistent but wrong.
    non_symlink_files = {str(f.relative_path): f for f in files if not f.is_symlink}
    for entry in manifest.files:
        if entry.stored_algorithm == "symlink":
            continue
        source_file = non_symlink_files[entry.relative_path]
        assert entry.original_sha256 == sha256_file(source_file.absolute_path)


def test_verification_detects_tampering(built_archive, tmp_path):
    import copy
    import shutil

    archive_path, manifest_path, manifest, _ = built_archive
    tampered = tmp_path / "tampered.cdopt"
    shutil.copyfile(archive_path, tampered)

    # Corrupt a *copy* of the manifest's expected hash for one file so
    # verification must catch the mismatch, without disturbing the shared
    # module-scoped fixture used by other tests.
    tampered_manifest_obj = copy.deepcopy(manifest)
    tampered_manifest_obj.files[0].original_sha256 = "0" * 64
    tampered_manifest = tmp_path / "tampered.manifest.json"
    write_manifest(tampered_manifest_obj, tampered_manifest)

    report = verify_archive(tampered, tampered_manifest, extract_to=tmp_path / "recovered_tampered")
    assert report.all_matched is False
    assert len(report.failed_files) >= 1
