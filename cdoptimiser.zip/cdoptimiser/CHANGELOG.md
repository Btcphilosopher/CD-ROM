# Changelog

## 0.1.0 — First vertical slice

- Repository foundation: packaging, core dataclasses, enums, exceptions, units.
- Recursive dataset scanner with chunked SHA-256 hashing; symlinks recorded, not followed.
- File classifier (highly compressible / moderately compressible / already compressed)
  with per-file recommendations.
- Exact-duplicate detection by content hash, with SAFE_COPY_MODE / REFERENCE_MODE
  distinction and reclaimable-space reporting.
- Shannon-entropy-based compressibility estimation.
- Pluggable compression engine protocol; store/gzip/bz2/lzma always available,
  optional zstandard with clean dependency degradation.
- Weighted compression-algorithm selection (never ratio-only).
- ISO9660-style filesystem overhead estimation (volume descriptors, path tables,
  directory records, sector-alignment waste) against CD-650/CD-700/74-min/80-min
  standard disc profiles.
- End-to-end optimisation pipeline: scan → classify → compress → pack into a
  single `.cdopt` archive → self-describing JSON manifest.
- Round-trip verification: extract, decompress per manifest, SHA-256 compare
  against recorded original hashes; path-traversal-safe extraction.
- CLI: scan, analyse, benchmark, optimise, verify, plan-discs.
- 55 passing tests (unit + integration), including a tampering-detection test
  and an end-to-end test against a real mixed-content sample dataset.
