# CDOPTIMISER

An engineering-grade Python platform for **CD-ROM / CD-R capacity planning,
content optimisation and archival packaging**.

CDOPTIMISER never claims to increase the physical capacity of an optical
disc. What it does is account, transparently and byte-by-byte, for how much
*logical* content a given physical capacity can carry once compression,
deduplication and intelligent packing are applied — and it proves every
optimisation is recoverable by round-trip verifying SHA-256 hashes end to
end.

This repository currently implements the **first vertical slice** described
in the build spec (section 22): a complete, working, tested path from a raw
directory of files to a packed, compressed, manifested archive with a
capacity report and verified recovery. The full repository skeleton for the
later phases (ISO 9660 layout, multi-disc volume planning, image mastering,
parity/recovery, GUI dashboard) is not yet built out — see "Status" below.

## What it does today

```
cdoptimiser scan <dataset>              # recursive scan, hashing, classification
cdoptimiser analyse <dataset>           # classification + duplicate detection + recommendations
cdoptimiser benchmark <file>            # compression benchmark across algorithms
cdoptimiser optimise <dataset> --output <dir>   # compress + pack + manifest + capacity report
cdoptimiser verify <archive.cdopt>      # round-trip extract, decompress, hash-compare
cdoptimiser plan-discs <dataset>        # rough disc-count estimate for a raw (unpacked) dataset
```

### Example

```bash
cdoptimiser optimise examples/sample_dataset --output ./out --profile balanced
cdoptimiser verify ./out/ARCHIVE-XXXXXXXXXXXX.cdopt
```

This will:

1. Recursively scan the dataset, computing a streamed SHA-256 for every file.
2. Classify every file (highly compressible / moderately compressible /
   already compressed) and never recommends recompressing formats like
   JPEG, MP3 or ZIP that are already internally compressed.
3. Detect exact-duplicate files by content hash and report reclaimable
   space (without silently deduplicating storage — see "Deduplication
   modes" below).
4. Select a compression algorithm per file from a named policy
   (`balanced` / `maximum_density` / `maximum_compatibility`) and measure
   real compressed size, ratio and duration — never an estimate presented
   as fact.
5. Pack every compressed member into a single `.cdopt` archive (a
   zip container of pre-compressed blobs), reducing per-file filesystem
   overhead relative to storing many small files directly on a disc image.
6. Write a self-describing JSON manifest (`archive_id`, per-file original
   hash, algorithm used, stored size, tool version, dataset hash).
7. Produce a capacity report against the CD-650 and CD-700 standard disc
   profiles, with an explicit accounting of physical capacity, estimated
   filesystem overhead, stored payload, original logical size, and
   compression multiplier — labelled as estimates where they are estimates.
8. On `verify`: extract the archive to a temporary directory, decompress
   every member using the algorithm recorded in the manifest, and compare
   the recovered SHA-256 against the manifest's recorded original hash.
   Verification fails loudly (non-zero exit code, per-file mismatch list)
   if anything doesn't match — it never silently reports success.

## Repository layout

```
src/cdoptimiser/
  core/            units, enums, dataclasses, exceptions, chunked hashing
  scanning/        recursive scanner, file classifier, duplicate detector
  analysis/        entropy estimation, ISO9660-style overhead model, capacity breakdown
  compression/     pluggable engine protocol; store/gzip/bz2/lzma (stdlib) + optional zstandard
  optimisation/    strategy selection, the end-to-end build pipeline
  archive/         manifest read/write
  verification/    round-trip extraction + hash verification, path-traversal guarding
  reporting/       human-readable capacity/benchmark report formatting
  cli/             argparse-based command-line interface
tests/
  unit/            one test module per core component
  integration/     full end-to-end vertical-slice test against examples/sample_dataset
examples/
  sample_dataset/  a small mixed-content demo dataset (text, CSV, JSON, JPEG-like, MP3-like,
                    including one intentional duplicate pair) used by the integration test
```

## Terminology (spec section 1.1)

CDOPTIMISER is careful to distinguish:

- **Physical capacity** — the disc profile's nominal byte capacity. Never changes.
- **Filesystem overhead** — estimated ISO9660-style volume descriptor,
  path table, directory record and sector-alignment cost. Labelled `[estimated]`
  until an actual image is built (later phase).
- **Stored payload** — the real, measured size of the packed archive.
- **Original logical content** — the real, measured size of the source data.
- **Compression multiplier** — original ÷ stored. Reported, never conflated
  with "extra physical capacity."

## Deduplication modes

`analyse` reports how much space duplicate files occupy and how much
`REFERENCE_MODE` deduplication *could* reclaim, but the vertical slice's
`optimise` command currently only implements `SAFE_COPY_MODE`: every file
is stored independently and remains recoverable without relying on any
application-level reference resolution. This matches spec section 8's
requirement that reference-based deduplication be clearly flagged as not
something ordinary CD-ROM filesystems provide transparently.

## Compression algorithm selection

Algorithm choice is never based on compression ratio alone
(`compression/compression_benchmark.py::select_best`). It scores candidates
on a weighted combination of stored size, time penalty and a compatibility
penalty (algorithms with less universal legacy-tool support score worse),
and the weights are configurable.

## Security

- Source files are never modified or deleted; every transformation writes
  to a fresh destination.
- Archive extraction resolves every member path against the destination
  root and refuses to write outside it (`verification/round_trip_validator.py::_safe_join`,
  raising `PathSecurityError`).
- No shell string concatenation is used anywhere in this slice (no
  external mastering tools are invoked yet — see Status).

## Status vs. the full spec

Implemented (working, tested):
Phase 1 (foundation), Phase 2 (scanner), most of Phase 3 (capacity model —
overhead is an estimate, not derived from an actual generated ISO layout
yet), Phase 4 (compression layer, stdlib algorithms + optional zstandard),
Phase 5 (duplicate detection), a working slice of Phase 6 (compression
selection + file packing; metadata-profile policies exist as compression
policies, not yet as a separate metadata-minimisation stage), and the
core of Phase 10 (manifest-based recovery + round-trip verification) and
Phase 12 (CLI).

Not yet implemented: ISO 9660/Joliet/Rock Ridge/UDF layout generation
against real external mastering tools (Phase 8–9), multi-disc volume
planning/allocation strategies beyond a rough single-profile estimate
(Phase 7), parity/error-correction (Phase 10's optional parity), the
scenario simulator (Phase 11), and the GUI dashboard (Phase 13). The
repository structure for these (`layout/`, `images/`, `simulation/`,
`gui/`) is intentionally left for the next build phase rather than
stubbed out with placeholder code, per the instruction to implement
working code rather than pseudocode.

## Running tests

```bash
pip install -e ".[dev]"
pytest
```

55 tests currently pass: unit coverage for units/hashing/scanning/
classification/duplicate-detection/compression round-trips/capacity
maths, plus an integration suite that builds a real archive from
`examples/sample_dataset`, verifies already-compressed media is stored
(not recompressed) and text is compressed, confirms measured savings,
and round-trip verifies recovered file hashes against both the manifest
and the live source files — including a tampering test that confirms
verification actually fails when a hash is corrupted.
