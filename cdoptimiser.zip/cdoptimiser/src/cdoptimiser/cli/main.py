from __future__ import annotations

import argparse
import json
import sys
import tempfile
from pathlib import Path

from cdoptimiser.analysis.capacity_analyser import build_capacity_breakdown, evaluate_against_all_standard_profiles
from cdoptimiser.archive.manifest_io import write_manifest
from cdoptimiser.compression.compression_benchmark import benchmark_file
from cdoptimiser.core.enums import CompressionAlgorithmName
from cdoptimiser.core.exceptions import CDOptimiserError
from cdoptimiser.core.models import STANDARD_DISC_PROFILES
from cdoptimiser.optimisation.pipeline import build_optimised_archive
from cdoptimiser.reporting.text_report import format_benchmark_table, format_capacity_report
from cdoptimiser.scanning.duplicate_detector import annotate_duplicate_groups, duplicate_savings_bytes
from cdoptimiser.scanning.file_classifier import classify_dataset, recommendation_for
from cdoptimiser.scanning.filesystem_scanner import scan_dataset, total_size_bytes
from cdoptimiser.verification.round_trip_validator import verify_archive


def cmd_scan(args: argparse.Namespace) -> int:
    files = scan_dataset(Path(args.dataset))
    classify_dataset(files)
    if args.json:
        payload = [f.to_dict() for f in files]
        Path(args.json).write_text(json.dumps(payload, indent=2), encoding="utf-8")
        print(f"Wrote scan report for {len(files)} files to {args.json}")
    else:
        total = total_size_bytes(files)
        print(f"Scanned {len(files)} files, {total:,} bytes total.")
        for f in files[:20]:
            print(f"  {f.relative_path}  {f.size_bytes:,}B  [{f.category.value}]")
        if len(files) > 20:
            print(f"  ... and {len(files) - 20} more")
    return 0


def cmd_analyse(args: argparse.Namespace) -> int:
    files = scan_dataset(Path(args.dataset))
    classify_dataset(files)
    groups = annotate_duplicate_groups(files)
    dedup_savings = duplicate_savings_bytes(groups)
    total = total_size_bytes(files)

    print(f"Dataset:              {args.dataset}")
    print(f"Files:                {len(files)}")
    print(f"Total size:           {total:,} bytes")
    print(f"Duplicate groups:     {len(groups)}")
    print(f"Reclaimable by dedup: {dedup_savings:,} bytes (REFERENCE_MODE only)")
    print()
    for f in files[:10]:
        rec = recommendation_for(f)
        print(f"  {f.relative_path}")
        print(f"    compression: {rec['compression']}; reason: {rec['reason']}")
    return 0


def cmd_benchmark(args: argparse.Namespace) -> int:
    algos = None
    if args.algorithms:
        algos = [CompressionAlgorithmName(a.strip()) for a in args.algorithms.split(",")]
    with tempfile.TemporaryDirectory() as tmp:
        results = benchmark_file(Path(args.file), Path(tmp), algorithms=algos)
        print(format_benchmark_table(results))
    return 0


def cmd_optimise(args: argparse.Namespace) -> int:
    output_dir = Path(args.output)
    archive_path, manifest, files = build_optimised_archive(
        Path(args.dataset), output_dir, policy_name=args.profile
    )
    manifest_path = output_dir / f"{manifest.archive_id}.manifest.json"
    write_manifest(manifest, manifest_path)

    print(f"Archive:  {archive_path}")
    print(f"Manifest: {manifest_path}")
    print(f"Original: {manifest.total_original_bytes:,} bytes")
    print(f"Stored:   {manifest.total_stored_bytes:,} bytes")
    if manifest.total_stored_bytes:
        print(f"Multiplier: {manifest.total_original_bytes / manifest.total_stored_bytes:.2f}:1")

    actual_archive_bytes = archive_path.stat().st_size
    file_sizes = [f.size_bytes for f in files if not f.is_symlink]
    directories = {str(f.relative_path.parent) for f in files}
    print()
    for key in ("cd_650_mb", "cd_700_mb"):
        profile = STANDARD_DISC_PROFILES[key]
        breakdown = build_capacity_breakdown(
            disc_profile=profile,
            stored_payload_bytes=actual_archive_bytes,
            original_logical_bytes=manifest.total_original_bytes,
            file_count=len(file_sizes),
            directory_count=len(directories),
            file_sizes_bytes=file_sizes,
        )
        print(format_capacity_report(breakdown))
        print()
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    archive_path = Path(args.archive)
    manifest_path = Path(args.manifest) if args.manifest else archive_path.with_suffix("").with_suffix(".manifest.json")
    with tempfile.TemporaryDirectory() as tmp:
        report = verify_archive(archive_path, manifest_path, extract_to=Path(tmp))
    status = "PASS" if report.all_matched else "FAIL"
    print(f"Verification: {status}  ({len(report.file_results)} files checked)")
    for r in report.failed_files:
        print(f"  MISMATCH: {r.relative_path} ({r.note or 'hash mismatch'})")
    return 0 if report.all_matched else 1


def cmd_plan_discs(args: argparse.Namespace) -> int:
    files = scan_dataset(Path(args.dataset))
    classify_dataset(files)
    total = total_size_bytes(files)
    file_sizes = [f.size_bytes for f in files if not f.is_symlink]
    directories = {str(f.relative_path.parent) for f in files}
    breakdowns = evaluate_against_all_standard_profiles(
        stored_payload_bytes=total,
        original_logical_bytes=total,
        file_count=len(file_sizes),
        directory_count=len(directories),
        file_sizes_bytes=file_sizes,
    )
    for key, breakdown in breakdowns.items():
        discs_needed = max(1, -(-breakdown.stored_payload_bytes // max(1, breakdown.estimated_usable_payload_bytes)))
        print(f"{breakdown.disc_profile_name:<20} discs needed (uncompressed, no packing): {discs_needed}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="cdoptimiser", description="CD-ROM capacity optimisation engine")
    sub = parser.add_subparsers(dest="command", required=True)

    p_scan = sub.add_parser("scan", help="Scan a dataset")
    p_scan.add_argument("dataset")
    p_scan.add_argument("--json", help="Write full JSON scan report to this path")
    p_scan.set_defaults(func=cmd_scan)

    p_analyse = sub.add_parser("analyse", help="Analyse a dataset: classification + duplicates")
    p_analyse.add_argument("dataset")
    p_analyse.set_defaults(func=cmd_analyse)

    p_bench = sub.add_parser("benchmark", help="Benchmark compression algorithms on a single file")
    p_bench.add_argument("file")
    p_bench.add_argument("--algorithms", help="Comma-separated list, e.g. gzip,lzma,bz2")
    p_bench.set_defaults(func=cmd_benchmark)

    p_opt = sub.add_parser("optimise", help="Scan, compress, pack and produce a capacity report")
    p_opt.add_argument("dataset")
    p_opt.add_argument("--output", required=True)
    p_opt.add_argument("--profile", default="balanced", choices=["balanced", "maximum_density", "maximum_compatibility"])
    p_opt.set_defaults(func=cmd_optimise)

    p_verify = sub.add_parser("verify", help="Round-trip verify a packed archive against its manifest")
    p_verify.add_argument("archive")
    p_verify.add_argument("--manifest", help="Path to manifest JSON (defaults to <archive_id>.manifest.json)")
    p_verify.set_defaults(func=cmd_verify)

    p_plan = sub.add_parser("plan-discs", help="Rough disc-count estimate for a raw (unpacked) dataset")
    p_plan.add_argument("dataset")
    p_plan.set_defaults(func=cmd_plan_discs)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except CDOptimiserError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
