"""Exact-duplicate detection based on SHA-256 content hashes.

Two files with identical hashes are treated as identical content
regardless of filename or path (spec section 8, stage 2).
"""

from __future__ import annotations

from collections import defaultdict

from cdoptimiser.core.models import ScannedFile


def find_duplicate_groups(files: list[ScannedFile]) -> dict[str, list[ScannedFile]]:
    """Group files by sha256. Only returns groups with 2+ members.

    Files without a computed hash (e.g. unhashed symlinks) are ignored.
    """
    by_hash: dict[str, list[ScannedFile]] = defaultdict(list)
    for f in files:
        if f.sha256:
            by_hash[f.sha256].append(f)
    return {h: group for h, group in by_hash.items() if len(group) > 1}


def annotate_duplicate_groups(files: list[ScannedFile]) -> dict[str, list[ScannedFile]]:
    """Mutates ScannedFile.duplicate_group for members of any duplicate group."""
    groups = find_duplicate_groups(files)
    for digest, group in groups.items():
        group_id = digest[:12]
        for f in group:
            f.duplicate_group = group_id
    return groups


def duplicate_savings_bytes(groups: dict[str, list[ScannedFile]]) -> int:
    """Bytes that SAFE_COPY_MODE could not reclaim but REFERENCE_MODE could:
    the size of every duplicate beyond the first copy in each group.
    """
    total = 0
    for group in groups.values():
        representative_size = group[0].size_bytes
        total += representative_size * (len(group) - 1)
    return total
