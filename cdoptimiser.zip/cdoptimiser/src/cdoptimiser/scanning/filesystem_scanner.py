"""Recursive dataset scanner.

Does not follow symbolic links by default (per spec section 4). Streams
file hashing in bounded chunks so large datasets do not blow memory.
"""

from __future__ import annotations

import mimetypes
from pathlib import Path

from cdoptimiser.core.exceptions import ScanError
from cdoptimiser.core.hashing import sha256_file
from cdoptimiser.core.models import ScannedFile


def scan_dataset(
    root: Path,
    *,
    follow_symlinks: bool = False,
    compute_hashes: bool = True,
) -> list[ScannedFile]:
    """Recursively scan `root`, returning one ScannedFile per regular file.

    Hidden files and directories are included. Symlinks are recorded but
    not followed unless follow_symlinks=True.
    """
    root = Path(root)
    if not root.exists():
        raise ScanError(f"Dataset path does not exist: {root}")
    if not root.is_dir():
        raise ScanError(f"Dataset path is not a directory: {root}")

    results: list[ScannedFile] = []
    for path in sorted(root.rglob("*")):
        if path.is_dir():
            continue
        if path.is_symlink() and not follow_symlinks:
            # Record the symlink itself as a zero-hash entry; do not traverse it.
            relative = path.relative_to(root)
            results.append(
                ScannedFile(
                    absolute_path=path,
                    relative_path=relative,
                    size_bytes=0,
                    modified_at=path.lstat().st_mtime,
                    extension=path.suffix.lower(),
                    mime_type=None,
                    is_symlink=True,
                    sha256=None,
                )
            )
            continue
        try:
            stat = path.stat()
        except OSError as exc:
            raise ScanError(f"Could not stat file: {path}") from exc

        mime_type, _ = mimetypes.guess_type(str(path))
        relative = path.relative_to(root)
        digest = sha256_file(path) if compute_hashes else None

        results.append(
            ScannedFile(
                absolute_path=path,
                relative_path=relative,
                size_bytes=stat.st_size,
                modified_at=stat.st_mtime,
                extension=path.suffix.lower(),
                mime_type=mime_type,
                is_symlink=False,
                sha256=digest,
            )
        )
    return results


def total_size_bytes(files: list[ScannedFile]) -> int:
    return sum(f.size_bytes for f in files)
