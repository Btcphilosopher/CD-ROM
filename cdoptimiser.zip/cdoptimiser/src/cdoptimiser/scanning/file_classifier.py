"""Classify files by expected compressibility.

The classifier is deliberately conservative: it never recommends
recompressing formats that are already compressed (JPEG, MP3, ZIP, etc.),
per spec section 5.
"""

from __future__ import annotations

from cdoptimiser.core.enums import FileCategory
from cdoptimiser.core.models import ScannedFile

HIGHLY_COMPRESSIBLE_EXTENSIONS = {
    ".txt", ".csv", ".json", ".xml", ".html", ".htm", ".md", ".markdown",
    ".py", ".js", ".ts", ".c", ".h", ".cpp", ".hpp", ".java", ".rs", ".go",
    ".sql", ".log", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".bmp",
    ".tsv", ".rst", ".sh", ".bat", ".ps1",
}

MODERATELY_COMPRESSIBLE_EXTENSIONS = {
    ".doc", ".rtf", ".wav", ".tiff", ".tif", ".psd", ".svg",
}

ALREADY_COMPRESSED_EXTENSIONS = {
    ".jpg", ".jpeg", ".png", ".webp", ".gif", ".mp3", ".aac", ".ogg",
    ".mp4", ".mkv", ".mov", ".avi", ".zip", ".rar", ".7z", ".gz", ".bz2",
    ".xz", ".zst", ".pdf", ".docx", ".xlsx", ".pptx", ".flac", ".m4a",
    ".heic", ".woff", ".woff2", ".jar",
}

_REASONS = {
    FileCategory.HIGHLY_COMPRESSIBLE: "Text-like or uncompressed structured data compresses well",
    FileCategory.MODERATELY_COMPRESSIBLE: "Format has partial internal redundancy",
    FileCategory.ALREADY_COMPRESSED: "Format already uses internal compression",
    FileCategory.UNKNOWN: "Extension not recognised; treat as unknown until sampled",
}


def classify_file(scanned: ScannedFile) -> FileCategory:
    ext = scanned.extension.lower()
    if ext in HIGHLY_COMPRESSIBLE_EXTENSIONS:
        return FileCategory.HIGHLY_COMPRESSIBLE
    if ext in MODERATELY_COMPRESSIBLE_EXTENSIONS:
        return FileCategory.MODERATELY_COMPRESSIBLE
    if ext in ALREADY_COMPRESSED_EXTENSIONS:
        return FileCategory.ALREADY_COMPRESSED
    return FileCategory.UNKNOWN


def classification_reason(category: FileCategory) -> str:
    return _REASONS[category]


def classify_dataset(files: list[ScannedFile]) -> None:
    """Classify every file in place (mutates ScannedFile.category)."""
    for f in files:
        f.category = classify_file(f)


def recommendation_for(scanned: ScannedFile) -> dict:
    """Human-readable recommendation block, mirroring the spec's example output."""
    category = scanned.category
    if category == FileCategory.ALREADY_COMPRESSED:
        return {
            "compression": "low expected benefit",
            "reason": f"{scanned.extension or 'this format'} is already compressed",
            "action": "store without recompression",
        }
    if category == FileCategory.HIGHLY_COMPRESSIBLE:
        return {
            "compression": "high expected benefit",
            "reason": classification_reason(category),
            "action": "compress with a general-purpose algorithm",
        }
    if category == FileCategory.MODERATELY_COMPRESSIBLE:
        return {
            "compression": "moderate expected benefit",
            "reason": classification_reason(category),
            "action": "compress; benchmark against store-only",
        }
    return {
        "compression": "unknown",
        "reason": classification_reason(category),
        "action": "sample entropy before deciding",
    }
