"""Streaming, chunked hashing so large files never need to be loaded whole."""

from __future__ import annotations

import hashlib
from pathlib import Path

DEFAULT_CHUNK_SIZE = 1024 * 1024  # 1 MiB


def sha256_file(path: Path, chunk_size: int = DEFAULT_CHUNK_SIZE) -> str:
    """Return the hex SHA-256 digest of a file, reading in bounded chunks."""
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_dataset(hashes: list[str]) -> str:
    """Combine a sorted list of per-file hashes into a single dataset hash.

    Deterministic: sorting the input hashes first means the result is
    independent of scan/iteration order.
    """
    digest = hashlib.sha256()
    for h in sorted(hashes):
        digest.update(h.encode("ascii"))
    return digest.hexdigest()
