from __future__ import annotations

from enum import Enum


class FileCategory(str, Enum):
    HIGHLY_COMPRESSIBLE = "highly_compressible"
    MODERATELY_COMPRESSIBLE = "moderately_compressible"
    ALREADY_COMPRESSED = "already_compressed"
    UNKNOWN = "unknown"


class CompressionAlgorithmName(str, Enum):
    STORE = "store"
    GZIP = "gzip"
    ZLIB = "zlib"
    BZ2 = "bz2"
    LZMA = "lzma"
    ZSTANDARD = "zstandard"
    BROTLI = "brotli"


class DiscProfileName(str, Enum):
    CD_650_MB = "cd_650_mb"
    CD_700_MB = "cd_700_mb"
    CD_74_MINUTE = "cd_74_minute"
    CD_80_MINUTE = "cd_80_minute"
    CUSTOM = "custom"


class DeduplicationMode(str, Enum):
    SAFE_COPY_MODE = "safe_copy_mode"
    REFERENCE_MODE = "reference_mode"


class MetadataProfile(str, Enum):
    MAXIMUM_COMPATIBILITY = "maximum_compatibility"
    BALANCED = "balanced"
    MAXIMUM_DENSITY = "maximum_density"
    ARCHIVAL_PRESERVATION = "archival_preservation"


class OptimisationObjective(str, Enum):
    MINIMUM_DISC_COUNT = "minimum_disc_count"
    MAXIMUM_COMPATIBILITY = "maximum_compatibility"
    MAXIMUM_STORAGE_DENSITY = "maximum_storage_density"
    FASTEST_RECOVERY = "fastest_recovery"
    ARCHIVAL_PRESERVATION = "archival_preservation"
    BALANCED = "balanced"
