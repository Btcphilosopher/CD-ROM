from __future__ import annotations


class CDOptimiserError(Exception):
    """Base class for all CDOPTIMISER errors."""


class ScanError(CDOptimiserError):
    """Raised when a dataset cannot be scanned."""


class CompressionError(CDOptimiserError):
    """Raised when a compression or decompression operation fails."""


class UnsupportedAlgorithmError(CompressionError):
    """Raised when a requested compression algorithm is unavailable."""


class CapacityExceededError(CDOptimiserError):
    """Raised when a dataset or image exceeds the target disc profile."""


class ManifestError(CDOptimiserError):
    """Raised when a manifest is missing, malformed, or fails validation."""


class VerificationError(CDOptimiserError):
    """Raised when integrity verification fails (hash mismatch, missing file)."""


class PathSecurityError(CDOptimiserError):
    """Raised when an archive member would escape its extraction destination."""
