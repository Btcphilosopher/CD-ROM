"""Explicit, unambiguous byte-unit conversions and formatting.

CDOPTIMISER never mixes decimal (MB) and binary (MiB) units silently.
Every function here is named after the exact unit it produces so that
call sites cannot accidentally conflate the two.
"""

from __future__ import annotations

KIBI = 1024
MEBI = 1024**2
GIBI = 1024**3

KILO = 1000
MEGA = 1000**2
GIGA = 1000**3


def bytes_to_mebibytes(num_bytes: int) -> float:
    """Convert bytes to MiB (binary, 1 MiB = 1,048,576 bytes)."""
    return num_bytes / MEBI


def bytes_to_megabytes(num_bytes: int) -> float:
    """Convert bytes to MB (decimal, 1 MB = 1,000,000 bytes)."""
    return num_bytes / MEGA


def bytes_to_gibibytes(num_bytes: int) -> float:
    return num_bytes / GIBI


def format_bytes_binary(num_bytes: int, precision: int = 2) -> str:
    """Human-readable binary size string, e.g. '697.42 MiB'."""
    value = float(num_bytes)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if abs(value) < KIBI or unit == "TiB":
            if unit == "B":
                return f"{int(value)} {unit}"
            return f"{value:.{precision}f} {unit}"
        value /= KIBI
    return f"{value:.{precision}f} TiB"  # pragma: no cover - unreachable guard


def format_bytes_decimal(num_bytes: int, precision: int = 2) -> str:
    """Human-readable decimal size string, e.g. '697.42 MB'."""
    value = float(num_bytes)
    for unit in ("B", "kB", "MB", "GB", "TB"):
        if abs(value) < KILO or unit == "TB":
            if unit == "B":
                return f"{int(value)} {unit}"
            return f"{value:.{precision}f} {unit}"
        value /= KILO
    return f"{value:.{precision}f} TB"  # pragma: no cover - unreachable guard


def sectors_for_bytes(num_bytes: int, logical_block_size: int) -> int:
    """Number of whole logical-block sectors required to hold num_bytes.

    Rounds up, since a partially filled sector still consumes a whole
    sector of physical space (alignment waste).
    """
    if logical_block_size <= 0:
        raise ValueError("logical_block_size must be positive")
    return -(-num_bytes // logical_block_size)  # ceiling division


def bytes_for_sectors(num_sectors: int, logical_block_size: int) -> int:
    return num_sectors * logical_block_size


def compression_ratio(original_bytes: int, stored_bytes: int) -> float:
    """Original:stored ratio. Returns 1.0 for zero-size input (no data, no gain)."""
    if stored_bytes <= 0:
        return 1.0 if original_bytes == 0 else float("inf")
    return original_bytes / stored_bytes


def percentage_saved(original_bytes: int, stored_bytes: int) -> float:
    if original_bytes <= 0:
        return 0.0
    return max(0.0, (1 - (stored_bytes / original_bytes)) * 100.0)
