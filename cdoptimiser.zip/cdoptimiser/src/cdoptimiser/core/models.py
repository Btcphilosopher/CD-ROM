from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from cdoptimiser.core.enums import CompressionAlgorithmName, FileCategory


@dataclass(frozen=True)
class DiscProfile:
    """A physical optical-disc capacity profile.

    All figures are measured/derived quantities, never invisible assumptions.
    """

    name: str
    nominal_capacity_bytes: int
    logical_block_size: int = 2048
    compatibility_notes: str = ""

    @property
    def usable_sector_count(self) -> int:
        return self.nominal_capacity_bytes // self.logical_block_size


# Standard disc profiles. Values are the conventional nominal figures used
# throughout the optical-media industry; they are starting points for the
# capacity model, not hidden constants baked into calculations elsewhere.
STANDARD_DISC_PROFILES: dict[str, DiscProfile] = {
    "cd_650_mb": DiscProfile(
        name="CD-R 650 MB",
        nominal_capacity_bytes=650 * 1024 * 1024,
        compatibility_notes="74-minute, 333,000-sector CD-R. Widest legacy-drive compatibility.",
    ),
    "cd_700_mb": DiscProfile(
        name="CD-R 700 MB",
        nominal_capacity_bytes=700 * 1024 * 1024,
        compatibility_notes="80-minute, 360,000-sector CD-R. Common modern standard.",
    ),
    "cd_74_minute": DiscProfile(
        name="CD-R 74-minute",
        nominal_capacity_bytes=333000 * 2048,
        compatibility_notes="333,000 sectors at 2,048 bytes/sector (audio-derived capacity).",
    ),
    "cd_80_minute": DiscProfile(
        name="CD-R 80-minute",
        nominal_capacity_bytes=360000 * 2048,
        compatibility_notes="360,000 sectors at 2,048 bytes/sector (audio-derived capacity).",
    ),
}


@dataclass
class ScannedFile:
    """A single file discovered by the dataset scanner."""

    absolute_path: Path
    relative_path: Path
    size_bytes: int
    modified_at: float
    extension: str
    mime_type: str | None
    is_symlink: bool
    sha256: str | None = None
    entropy_estimate: float | None = None
    category: FileCategory = FileCategory.UNKNOWN
    duplicate_group: str | None = None

    def to_dict(self) -> dict:
        return {
            "relative_path": str(self.relative_path),
            "size_bytes": self.size_bytes,
            "modified_at": self.modified_at,
            "extension": self.extension,
            "mime_type": self.mime_type,
            "is_symlink": self.is_symlink,
            "sha256": self.sha256,
            "entropy_estimate": self.entropy_estimate,
            "category": self.category.value,
            "duplicate_group": self.duplicate_group,
        }


@dataclass
class CompressionEstimate:
    algorithm: CompressionAlgorithmName
    estimated_ratio: float
    confidence: str  # "low" | "medium" | "high"
    reason: str


@dataclass
class CompressionResult:
    algorithm: CompressionAlgorithmName
    original_size_bytes: int
    compressed_size_bytes: int
    duration_seconds: float
    level: int | None
    source_hash: str

    @property
    def ratio(self) -> float:
        if self.compressed_size_bytes <= 0:
            return 1.0
        return self.original_size_bytes / self.compressed_size_bytes

    @property
    def percentage_saved(self) -> float:
        if self.original_size_bytes <= 0:
            return 0.0
        return max(0.0, (1 - self.compressed_size_bytes / self.original_size_bytes) * 100.0)


@dataclass
class CapacityBreakdown:
    """Explicit byte-level accounting for a built archive against a disc profile."""

    disc_profile_name: str
    physical_capacity_bytes: int
    filesystem_overhead_bytes: int
    stored_payload_bytes: int
    original_logical_bytes: int

    @property
    def estimated_usable_payload_bytes(self) -> int:
        return self.physical_capacity_bytes - self.filesystem_overhead_bytes

    @property
    def remaining_bytes(self) -> int:
        return self.estimated_usable_payload_bytes - self.stored_payload_bytes

    @property
    def fits(self) -> bool:
        return self.remaining_bytes >= 0

    @property
    def utilisation_fraction(self) -> float:
        if self.estimated_usable_payload_bytes <= 0:
            return 0.0
        return self.stored_payload_bytes / self.estimated_usable_payload_bytes

    @property
    def compression_multiplier(self) -> float:
        if self.stored_payload_bytes <= 0:
            return 1.0
        return self.original_logical_bytes / self.stored_payload_bytes


@dataclass
class ManifestFileEntry:
    relative_path: str
    original_size_bytes: int
    original_sha256: str
    stored_algorithm: str
    stored_size_bytes: int
    packed: bool = False


@dataclass
class ArchiveManifest:
    archive_id: str
    created_at: str
    tool_version: str
    source_dataset_hash: str
    total_original_bytes: int
    total_stored_bytes: int
    compression_algorithms: list[str]
    files: list[ManifestFileEntry] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "archive_id": self.archive_id,
            "created_at": self.created_at,
            "tool_version": self.tool_version,
            "source_dataset_hash": self.source_dataset_hash,
            "total_original_bytes": self.total_original_bytes,
            "total_stored_bytes": self.total_stored_bytes,
            "compression_algorithms": self.compression_algorithms,
            "files": [
                {
                    "relative_path": f.relative_path,
                    "original_size_bytes": f.original_size_bytes,
                    "original_sha256": f.original_sha256,
                    "stored_algorithm": f.stored_algorithm,
                    "stored_size_bytes": f.stored_size_bytes,
                    "packed": f.packed,
                }
                for f in self.files
            ],
        }
