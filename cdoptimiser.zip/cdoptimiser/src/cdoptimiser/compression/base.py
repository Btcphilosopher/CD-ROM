"""Pluggable compression engine interface.

Every engine streams in bounded chunks and reports a real measured
CompressionResult — never an estimate presented as fact.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Protocol

from cdoptimiser.core.enums import CompressionAlgorithmName
from cdoptimiser.core.hashing import sha256_file
from cdoptimiser.core.models import CompressionResult

CHUNK_SIZE = 1024 * 1024


class CompressionEngine(Protocol):
    name: CompressionAlgorithmName

    def compress(self, source: Path, destination: Path, level: int | None = None) -> CompressionResult: ...

    def decompress(self, source: Path, destination: Path) -> None: ...

    def is_available(self) -> bool: ...


def timed_stream_compress(
    *,
    algorithm: CompressionAlgorithmName,
    source: Path,
    destination: Path,
    level: int | None,
    open_writer,
) -> CompressionResult:
    """Shared timing/hashing/streaming scaffold used by every stdlib engine.

    `open_writer` is a callable(destination, level) -> file-like object
    supporting .write(bytes) and usable as a context manager.
    """
    source_hash = sha256_file(source)
    start = time.perf_counter()
    with open(source, "rb") as reader, open_writer(destination, level) as writer:
        while True:
            chunk = reader.read(CHUNK_SIZE)
            if not chunk:
                break
            writer.write(chunk)
    duration = time.perf_counter() - start
    compressed_size = destination.stat().st_size
    original_size = source.stat().st_size
    return CompressionResult(
        algorithm=algorithm,
        original_size_bytes=original_size,
        compressed_size_bytes=compressed_size,
        duration_seconds=duration,
        level=level,
        source_hash=source_hash,
    )
