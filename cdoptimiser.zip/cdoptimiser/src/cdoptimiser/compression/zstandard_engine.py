from __future__ import annotations

import time
from pathlib import Path

from cdoptimiser.core.enums import CompressionAlgorithmName
from cdoptimiser.core.exceptions import UnsupportedAlgorithmError
from cdoptimiser.core.hashing import sha256_file
from cdoptimiser.core.models import CompressionResult
from cdoptimiser.compression.base import CHUNK_SIZE

try:
    import zstandard  # type: ignore

    _ZSTD_AVAILABLE = True
except ImportError:  # pragma: no cover - exercised only when dependency missing
    _ZSTD_AVAILABLE = False


class ZstandardEngine:
    name = CompressionAlgorithmName.ZSTANDARD

    def is_available(self) -> bool:
        return _ZSTD_AVAILABLE

    def compress(self, source: Path, destination: Path, level: int | None = None) -> CompressionResult:
        if not _ZSTD_AVAILABLE:
            raise UnsupportedAlgorithmError(
                "zstandard is not installed. Install with: pip install 'cdoptimiser[zstd]'"
            )
        level = 3 if level is None else level
        source_hash = sha256_file(source)
        compressor = zstandard.ZstdCompressor(level=level)
        start = time.perf_counter()
        with open(source, "rb") as reader, open(destination, "wb") as raw_writer:
            with compressor.stream_writer(raw_writer) as writer:
                while True:
                    chunk = reader.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    writer.write(chunk)
        duration = time.perf_counter() - start
        return CompressionResult(
            algorithm=self.name,
            original_size_bytes=source.stat().st_size,
            compressed_size_bytes=destination.stat().st_size,
            duration_seconds=duration,
            level=level,
            source_hash=source_hash,
        )

    def decompress(self, source: Path, destination: Path) -> None:
        if not _ZSTD_AVAILABLE:
            raise UnsupportedAlgorithmError("zstandard is not installed.")
        decompressor = zstandard.ZstdDecompressor()
        with open(source, "rb") as reader, open(destination, "wb") as writer:
            with decompressor.stream_reader(reader) as stream:
                while True:
                    chunk = stream.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    writer.write(chunk)
