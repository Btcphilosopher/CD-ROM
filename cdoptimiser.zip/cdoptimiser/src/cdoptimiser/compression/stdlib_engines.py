"""Standard-library compression engines.

These are always available (no optional dependency needed) and cover the
core benchmark set: store (baseline), gzip, bz2, lzma. Optional engines
(zstandard, brotli) live in their own modules and degrade cleanly when the
dependency isn't installed.
"""

from __future__ import annotations

import bz2
import gzip
import lzma
import shutil
import time
from pathlib import Path

from cdoptimiser.core.enums import CompressionAlgorithmName
from cdoptimiser.core.exceptions import CompressionError
from cdoptimiser.core.hashing import sha256_file
from cdoptimiser.core.models import CompressionResult
from cdoptimiser.compression.base import CHUNK_SIZE


class StoreEngine:
    """Baseline: no compression, plain copy. Always available."""

    name = CompressionAlgorithmName.STORE

    def is_available(self) -> bool:
        return True

    def compress(self, source: Path, destination: Path, level: int | None = None) -> CompressionResult:
        source_hash = sha256_file(source)
        start = time.perf_counter()
        shutil.copyfile(source, destination)
        duration = time.perf_counter() - start
        return CompressionResult(
            algorithm=self.name,
            original_size_bytes=source.stat().st_size,
            compressed_size_bytes=destination.stat().st_size,
            duration_seconds=duration,
            level=None,
            source_hash=source_hash,
        )

    def decompress(self, source: Path, destination: Path) -> None:
        shutil.copyfile(source, destination)


class GzipEngine:
    name = CompressionAlgorithmName.GZIP

    def is_available(self) -> bool:
        return True

    def compress(self, source: Path, destination: Path, level: int | None = None) -> CompressionResult:
        level = 6 if level is None else level
        source_hash = sha256_file(source)
        start = time.perf_counter()
        try:
            with open(source, "rb") as reader, gzip.open(destination, "wb", compresslevel=level) as writer:
                while True:
                    chunk = reader.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    writer.write(chunk)
        except OSError as exc:
            raise CompressionError(f"gzip compression failed for {source}") from exc
        duration = time.perf_counter() - start
        return CompressionResult(
            algorithm=self.name,
            original_size_bytes=source.stat().st_size,
            compressed_size_bytes=destination.stat().st_size,
            duration_seconds=duration,
            level=level,
            source_hash=source_hash,
        )

    def decompress(self, source: Path, destination: Path) -> None:
        with gzip.open(source, "rb") as reader, open(destination, "wb") as writer:
            shutil.copyfileobj(reader, writer)


class Bz2Engine:
    name = CompressionAlgorithmName.BZ2

    def is_available(self) -> bool:
        return True

    def compress(self, source: Path, destination: Path, level: int | None = None) -> CompressionResult:
        level = 9 if level is None else level
        source_hash = sha256_file(source)
        start = time.perf_counter()
        with open(source, "rb") as reader, bz2.open(destination, "wb", compresslevel=level) as writer:
            while True:
                chunk = reader.read(CHUNK_SIZE)
                if not chunk:
                    break
                writer.write(chunk)
        duration = time.perf_counter() - start
        return CompressionResult(
            algorithm=self.name,
            original_size_bytes=source.stat().st_size,
            compressed_size_bytes=destination.stat().st_size,
            duration_seconds=duration,
            level=level,
            source_hash=source_hash,
        )

    def decompress(self, source: Path, destination: Path) -> None:
        with bz2.open(source, "rb") as reader, open(destination, "wb") as writer:
            shutil.copyfileobj(reader, writer)


class LzmaEngine:
    name = CompressionAlgorithmName.LZMA

    def is_available(self) -> bool:
        return True

    def compress(self, source: Path, destination: Path, level: int | None = None) -> CompressionResult:
        level = 6 if level is None else level
        source_hash = sha256_file(source)
        start = time.perf_counter()
        with open(source, "rb") as reader, lzma.open(destination, "wb", preset=level) as writer:
            while True:
                chunk = reader.read(CHUNK_SIZE)
                if not chunk:
                    break
                writer.write(chunk)
        duration = time.perf_counter() - start
        return CompressionResult(
            algorithm=self.name,
            original_size_bytes=source.stat().st_size,
            compressed_size_bytes=destination.stat().st_size,
            duration_seconds=duration,
            level=level,
            source_hash=source_hash,
        )

    def decompress(self, source: Path, destination: Path) -> None:
        with lzma.open(source, "rb") as reader, open(destination, "wb") as writer:
            shutil.copyfileobj(reader, writer)


STDLIB_ENGINES: dict[CompressionAlgorithmName, object] = {
    CompressionAlgorithmName.STORE: StoreEngine(),
    CompressionAlgorithmName.GZIP: GzipEngine(),
    CompressionAlgorithmName.BZ2: Bz2Engine(),
    CompressionAlgorithmName.LZMA: LzmaEngine(),
}
