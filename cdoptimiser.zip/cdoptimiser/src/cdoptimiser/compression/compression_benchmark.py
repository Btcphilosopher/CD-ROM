"""Compression algorithm registry and benchmarking engine.

Selecting the "best" algorithm is never done on ratio alone: see
`select_best` which applies a weighted objective over size, time and
compatibility, exactly as spec section 6 requires.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from cdoptimiser.core.enums import CompressionAlgorithmName
from cdoptimiser.core.models import CompressionResult
from cdoptimiser.compression.stdlib_engines import STDLIB_ENGINES
from cdoptimiser.compression.zstandard_engine import ZstandardEngine

REGISTRY: dict[CompressionAlgorithmName, object] = {
    **STDLIB_ENGINES,
    CompressionAlgorithmName.ZSTANDARD: ZstandardEngine(),
}


def available_engines() -> dict[CompressionAlgorithmName, object]:
    return {name: engine for name, engine in REGISTRY.items() if engine.is_available()}


def benchmark_file(
    source: Path,
    work_dir: Path,
    algorithms: list[CompressionAlgorithmName] | None = None,
) -> list[CompressionResult]:
    """Compress `source` with every requested (available) algorithm and
    return the measured results, sorted by compressed size ascending.
    """
    work_dir.mkdir(parents=True, exist_ok=True)
    engines = available_engines()
    algorithms = algorithms or list(engines.keys())
    results: list[CompressionResult] = []
    for algo in algorithms:
        engine = engines.get(algo)
        if engine is None:
            continue
        destination = work_dir / f"{source.name}.{algo.value}"
        results.append(engine.compress(source, destination))
    return sorted(results, key=lambda r: r.compressed_size_bytes)


@dataclass
class SelectionWeights:
    stored_size: float = 1.0
    time_penalty: float = 0.02
    memory_penalty: float = 0.0
    compatibility_penalty: float = 0.0


# Compatibility penalty applied per algorithm (higher = less universally
# supported by simple/legacy tooling). Expressed in "equivalent bytes" so
# it can be added directly into the weighted score.
_COMPATIBILITY_PENALTY_BYTES = {
    CompressionAlgorithmName.STORE: 0,
    CompressionAlgorithmName.GZIP: 0,
    CompressionAlgorithmName.ZLIB: 0,
    CompressionAlgorithmName.BZ2: 1024 * 50,
    CompressionAlgorithmName.LZMA: 1024 * 100,
    CompressionAlgorithmName.ZSTANDARD: 1024 * 200,
    CompressionAlgorithmName.BROTLI: 1024 * 200,
}


def select_best(
    results: list[CompressionResult],
    weights: SelectionWeights | None = None,
) -> CompressionResult:
    """Pick the result minimising a weighted score of size + time + compatibility.

    Never selects purely on compression ratio; see spec section 6.
    """
    if not results:
        raise ValueError("select_best requires at least one CompressionResult")
    weights = weights or SelectionWeights()

    def score(result: CompressionResult) -> float:
        time_bytes_equivalent = result.duration_seconds * 1_000_000 * weights.time_penalty
        compatibility_bytes = _COMPATIBILITY_PENALTY_BYTES.get(result.algorithm, 0) * weights.compatibility_penalty
        return (
            result.compressed_size_bytes * weights.stored_size
            + time_bytes_equivalent
            + compatibility_bytes
        )

    return min(results, key=score)
