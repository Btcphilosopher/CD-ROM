"""Round-trip verification: extract a packed archive and confirm every
recovered file's SHA-256 matches the manifest's recorded original hash.

This is the software's proof that recovery works, not just an assumption.
"""

from __future__ import annotations

import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from cdoptimiser.archive.manifest_io import read_manifest
from cdoptimiser.compression.compression_benchmark import available_engines
from cdoptimiser.core.enums import CompressionAlgorithmName
from cdoptimiser.core.exceptions import PathSecurityError, VerificationError
from cdoptimiser.core.hashing import sha256_file
from cdoptimiser.core.models import ArchiveManifest
from cdoptimiser.optimisation.pipeline import ARCHIVE_MEMBER_NAME_SEP


@dataclass
class FileVerificationResult:
    relative_path: str
    expected_sha256: str
    actual_sha256: str | None
    matched: bool
    note: str = ""


@dataclass
class VerificationReport:
    archive_id: str
    all_matched: bool
    file_results: list[FileVerificationResult] = field(default_factory=list)

    @property
    def failed_files(self) -> list[FileVerificationResult]:
        return [r for r in self.file_results if not r.matched]


def _safe_join(destination_root: Path, relative_path: str) -> Path:
    """Resolve relative_path under destination_root, refusing traversal."""
    candidate = (destination_root / relative_path).resolve()
    root = destination_root.resolve()
    if root not in candidate.parents and candidate != root:
        raise PathSecurityError(f"Refusing to extract outside destination: {relative_path}")
    return candidate


def verify_archive(
    archive_path: Path,
    manifest_path: Path,
    *,
    extract_to: Path,
) -> VerificationReport:
    manifest: ArchiveManifest = read_manifest(manifest_path)
    extract_to = Path(extract_to)
    extract_to.mkdir(parents=True, exist_ok=True)

    engines = available_engines()
    results: list[FileVerificationResult] = []

    with zipfile.ZipFile(archive_path, mode="r") as zf:
        for entry in manifest.files:
            if entry.stored_algorithm == "symlink":
                results.append(
                    FileVerificationResult(
                        relative_path=entry.relative_path,
                        expected_sha256="",
                        actual_sha256=None,
                        matched=True,
                        note="symlink entry — not content-verified",
                    )
                )
                continue

            member_name = f"{entry.relative_path}{ARCHIVE_MEMBER_NAME_SEP}{entry.stored_algorithm}"
            if member_name not in zf.namelist():
                results.append(
                    FileVerificationResult(
                        relative_path=entry.relative_path,
                        expected_sha256=entry.original_sha256,
                        actual_sha256=None,
                        matched=False,
                        note="missing from archive",
                    )
                )
                continue

            blob_dest = _safe_join(extract_to, entry.relative_path + ".blob")
            blob_dest.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(member_name) as source_member, open(blob_dest, "wb") as out:
                out.write(source_member.read())

            recovered_dest = _safe_join(extract_to, entry.relative_path)
            recovered_dest.parent.mkdir(parents=True, exist_ok=True)

            algo = CompressionAlgorithmName(entry.stored_algorithm)
            engine = engines.get(algo)
            if engine is None:
                results.append(
                    FileVerificationResult(
                        relative_path=entry.relative_path,
                        expected_sha256=entry.original_sha256,
                        actual_sha256=None,
                        matched=False,
                        note=f"decompression engine unavailable: {algo.value}",
                    )
                )
                blob_dest.unlink(missing_ok=True)
                continue

            engine.decompress(blob_dest, recovered_dest)
            blob_dest.unlink(missing_ok=True)

            actual_hash = sha256_file(recovered_dest)
            matched = actual_hash == entry.original_sha256
            results.append(
                FileVerificationResult(
                    relative_path=entry.relative_path,
                    expected_sha256=entry.original_sha256,
                    actual_sha256=actual_hash,
                    matched=matched,
                )
            )

    all_matched = all(r.matched for r in results)
    return VerificationReport(archive_id=manifest.archive_id, all_matched=all_matched, file_results=results)


def require_verified(report: VerificationReport) -> None:
    if not report.all_matched:
        failed = ", ".join(r.relative_path for r in report.failed_files)
        raise VerificationError(f"Verification failed for: {failed}")
