"""Per-file compression strategy selection.

Selection is driven by the classification stage (spec section 5) so that
already-compressed formats are never blindly recompressed.
"""

from __future__ import annotations

from cdoptimiser.core.enums import CompressionAlgorithmName, FileCategory

DEFAULT_POLICY: dict[FileCategory, CompressionAlgorithmName] = {
    FileCategory.ALREADY_COMPRESSED: CompressionAlgorithmName.STORE,
    FileCategory.HIGHLY_COMPRESSIBLE: CompressionAlgorithmName.LZMA,
    FileCategory.MODERATELY_COMPRESSIBLE: CompressionAlgorithmName.GZIP,
    FileCategory.UNKNOWN: CompressionAlgorithmName.GZIP,
}

MAXIMUM_DENSITY_POLICY: dict[FileCategory, CompressionAlgorithmName] = {
    FileCategory.ALREADY_COMPRESSED: CompressionAlgorithmName.STORE,
    FileCategory.HIGHLY_COMPRESSIBLE: CompressionAlgorithmName.LZMA,
    FileCategory.MODERATELY_COMPRESSIBLE: CompressionAlgorithmName.LZMA,
    FileCategory.UNKNOWN: CompressionAlgorithmName.LZMA,
}

MAXIMUM_COMPATIBILITY_POLICY: dict[FileCategory, CompressionAlgorithmName] = {
    FileCategory.ALREADY_COMPRESSED: CompressionAlgorithmName.STORE,
    FileCategory.HIGHLY_COMPRESSIBLE: CompressionAlgorithmName.GZIP,
    FileCategory.MODERATELY_COMPRESSIBLE: CompressionAlgorithmName.GZIP,
    FileCategory.UNKNOWN: CompressionAlgorithmName.GZIP,
}

POLICIES = {
    "balanced": DEFAULT_POLICY,
    "maximum_density": MAXIMUM_DENSITY_POLICY,
    "maximum_compatibility": MAXIMUM_COMPATIBILITY_POLICY,
}


def select_algorithm(category: FileCategory, policy_name: str = "balanced") -> CompressionAlgorithmName:
    policy = POLICIES.get(policy_name, DEFAULT_POLICY)
    return policy.get(category, CompressionAlgorithmName.STORE)
