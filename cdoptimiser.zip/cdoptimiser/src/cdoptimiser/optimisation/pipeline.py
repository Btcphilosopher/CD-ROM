"""End-to-end optimisation pipeline (spec section 22, "first vertical slice").

Produces:
  - a single packed archive (.cdopt, a zip container of pre-compressed
    member blobs) — this IS the "file packing" stage, reducing per-file
    filesystem overhead relative to storing many small files directly.
  - a JSON manifest fully describing every transformation, so the archive
    is recoverable without relying on undocumented behaviour.

Never touches or modifies the source dataset. All output is written to a
fresh destination directory.
"""

from __future__ import annotations

import datetime
import uuid
import zipfile
from pathlib import Path

from cdoptimiser import __version__
from cdoptimiser.compression.compression_benchmark import available_engines
from cdoptimiser.core.hashing import sha256_dataset
from cdoptimiser.core.models import ArchiveManifest, ManifestFileEntry, ScannedFile
from cdoptimiser.optimisation.strategy_selector import select_algorithm
from cdoptimiser.scanning.duplicate_detector import annotate_duplicate_groups
from cdoptimiser.scanning.file_classifier import classify_dataset
from cdoptimiser.scanning.filesystem_scanner import scan_dataset

ARCHIVE_MEMBER_NAME_SEP = "::"  # relative_path::algorithm, keeps manifest and zip in sync


def build_optimised_archive(
    source_root: Path,
    output_dir: Path,
    *,
    policy_name: str = "balanced",
    archive_id: str | None = None,
) -> tuple[Path, ArchiveManifest, list[ScannedFile]]:
    """Run the full pipeline and write `<archive_id>.cdopt` + manifest JSON.

    Returns (archive_path, manifest, scanned_files) so callers (CLI, tests,
    capacity analysis) can inspect intermediate results without re-scanning.
    """
    source_root = Path(source_root)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    files = scan_dataset(source_root)
    classify_dataset(files)
    annotate_duplicate_groups(files)

    engines = available_engines()
    archive_id = archive_id or f"ARCHIVE-{uuid.uuid4().hex[:12].upper()}"
    archive_path = output_dir / f"{archive_id}.cdopt"

    manifest_entries: list[ManifestFileEntry] = []
    algorithms_used: set[str] = set()
    total_original = 0
    total_stored = 0

    work_dir = output_dir / f".{archive_id}.work"
    work_dir.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(archive_path, mode="w", compression=zipfile.ZIP_STORED) as zf:
        for f in files:
            if f.is_symlink:
                # Symlinks are recorded in the manifest but not packed as content
                # (spec: preserve permission/link metadata, never silently
                # traverse links). Vertical slice records them as zero-byte
                # placeholders with an explicit "symlink" algorithm marker.
                manifest_entries.append(
                    ManifestFileEntry(
                        relative_path=str(f.relative_path),
                        original_size_bytes=0,
                        original_sha256="",
                        stored_algorithm="symlink",
                        stored_size_bytes=0,
                    )
                )
                continue

            algo = select_algorithm(f.category, policy_name)
            engine = engines.get(algo)
            if engine is None:
                # Requested algorithm unavailable in this environment: fall
                # back to store, and record that fallback honestly.
                from cdoptimiser.core.enums import CompressionAlgorithmName

                algo = CompressionAlgorithmName.STORE
                engine = engines[algo]

            blob_path = work_dir / (f.relative_path.name + ".blob")
            result = engine.compress(f.absolute_path, blob_path, level=None)

            member_name = f"{f.relative_path}{ARCHIVE_MEMBER_NAME_SEP}{algo.value}"
            zf.write(blob_path, arcname=member_name)
            blob_path.unlink()

            manifest_entries.append(
                ManifestFileEntry(
                    relative_path=str(f.relative_path),
                    original_size_bytes=f.size_bytes,
                    original_sha256=f.sha256 or "",
                    stored_algorithm=algo.value,
                    stored_size_bytes=result.compressed_size_bytes,
                    packed=True,
                )
            )
            algorithms_used.add(algo.value)
            total_original += f.size_bytes
            total_stored += result.compressed_size_bytes

    work_dir.rmdir()

    dataset_hash = sha256_dataset([e.original_sha256 for e in manifest_entries if e.original_sha256])

    manifest = ArchiveManifest(
        archive_id=archive_id,
        created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        tool_version=__version__,
        source_dataset_hash=dataset_hash,
        total_original_bytes=total_original,
        total_stored_bytes=total_stored,
        compression_algorithms=sorted(algorithms_used),
        files=manifest_entries,
    )

    # Archive's own stored size includes the zip container overhead (local
    # file headers, central directory) — measure it directly rather than
    # assuming the sum of member sizes.
    return archive_path, manifest, files
