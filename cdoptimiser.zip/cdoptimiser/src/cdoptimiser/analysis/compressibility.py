"""Sample-based Shannon entropy estimation.

Entropy is measured in bits/byte (0.0 - 8.0). Low entropy implies high
redundancy and therefore good compressibility; entropy near 8.0 implies
data that is already dense/compressed/encrypted-looking.
"""

from __future__ import annotations

import math
from collections import Counter
from pathlib import Path

DEFAULT_SAMPLE_BYTES = 256 * 1024  # 256 KiB sample is enough to estimate entropy


def shannon_entropy(data: bytes) -> float:
    if not data:
        return 0.0
    counts = Counter(data)
    length = len(data)
    entropy = 0.0
    for count in counts.values():
        p = count / length
        entropy -= p * math.log2(p)
    return entropy


def estimate_file_entropy(path: Path, sample_bytes: int = DEFAULT_SAMPLE_BYTES) -> float:
    """Read up to `sample_bytes` from the start of the file and estimate entropy.

    A fixed-size prefix sample keeps this bounded in memory and time even
    for very large files, at the cost of not seeing the whole file.
    """
    with open(path, "rb") as handle:
        sample = handle.read(sample_bytes)
    return shannon_entropy(sample)


def compressibility_confidence(entropy_bits_per_byte: float) -> tuple[str, str]:
    """Return (confidence_label, expected_benefit_label) from a measured entropy."""
    if entropy_bits_per_byte <= 4.0:
        return "high", "high expected benefit"
    if entropy_bits_per_byte <= 6.5:
        return "medium", "moderate expected benefit"
    return "high", "low expected benefit"
