from __future__ import annotations

from cdoptimiser.analysis.overhead_calculator import estimate_overhead
from cdoptimiser.core.models import CapacityBreakdown, DiscProfile, STANDARD_DISC_PROFILES


def build_capacity_breakdown(
    *,
    disc_profile: DiscProfile,
    stored_payload_bytes: int,
    original_logical_bytes: int,
    file_count: int,
    directory_count: int,
    file_sizes_bytes: list[int],
) -> CapacityBreakdown:
    overhead = estimate_overhead(
        file_count=file_count,
        directory_count=directory_count,
        file_sizes_bytes=file_sizes_bytes,
        logical_block_size=disc_profile.logical_block_size,
    )
    return CapacityBreakdown(
        disc_profile_name=disc_profile.name,
        physical_capacity_bytes=disc_profile.nominal_capacity_bytes,
        filesystem_overhead_bytes=overhead.total_bytes,
        stored_payload_bytes=stored_payload_bytes,
        original_logical_bytes=original_logical_bytes,
    )


def evaluate_against_all_standard_profiles(
    *,
    stored_payload_bytes: int,
    original_logical_bytes: int,
    file_count: int,
    directory_count: int,
    file_sizes_bytes: list[int],
) -> dict[str, CapacityBreakdown]:
    return {
        key: build_capacity_breakdown(
            disc_profile=profile,
            stored_payload_bytes=stored_payload_bytes,
            original_logical_bytes=original_logical_bytes,
            file_count=file_count,
            directory_count=directory_count,
            file_sizes_bytes=file_sizes_bytes,
        )
        for key, profile in STANDARD_DISC_PROFILES.items()
    }
