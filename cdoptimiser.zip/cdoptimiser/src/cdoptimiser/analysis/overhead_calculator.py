"""Estimate ISO 9660-style filesystem overhead from an actual file list.

These are *estimates* derived from the real number and size of files being
packed — not hard-coded constants. They approximate the standard ISO 9660
structures: volume descriptors, path tables, directory records, and
per-file sector-alignment waste (every file consumes whole sectors).

This is a planning-level model, not a byte-exact ISO 9660 implementation.
Values are clearly labelled as estimates throughout the CLI/report output.
"""

from __future__ import annotations

from dataclasses import dataclass

VOLUME_DESCRIPTOR_AREA_BYTES = 16 * 2048  # System area + primary/terminator descriptors
DIRECTORY_RECORD_BYTES_PER_FILE = 128  # Conservative average record size incl. padding
PATH_TABLE_BYTES_PER_DIRECTORY = 64


@dataclass(frozen=True)
class OverheadEstimate:
    volume_descriptor_bytes: int
    path_table_bytes: int
    directory_record_bytes: int
    alignment_waste_bytes: int

    @property
    def total_bytes(self) -> int:
        return (
            self.volume_descriptor_bytes
            + self.path_table_bytes
            + self.directory_record_bytes
            + self.alignment_waste_bytes
        )


def estimate_overhead(
    *,
    file_count: int,
    directory_count: int,
    file_sizes_bytes: list[int],
    logical_block_size: int = 2048,
) -> OverheadEstimate:
    alignment_waste = 0
    for size in file_sizes_bytes:
        remainder = size % logical_block_size
        if remainder != 0:
            alignment_waste += logical_block_size - remainder

    return OverheadEstimate(
        volume_descriptor_bytes=VOLUME_DESCRIPTOR_AREA_BYTES,
        path_table_bytes=directory_count * PATH_TABLE_BYTES_PER_DIRECTORY,
        directory_record_bytes=file_count * DIRECTORY_RECORD_BYTES_PER_FILE,
        alignment_waste_bytes=alignment_waste,
    )
