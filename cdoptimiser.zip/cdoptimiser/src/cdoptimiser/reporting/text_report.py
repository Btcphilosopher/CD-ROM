from __future__ import annotations

from cdoptimiser.core.models import CapacityBreakdown, CompressionResult
from cdoptimiser.core.units import format_bytes_binary, format_bytes_decimal

RULE = "─" * 46


def format_capacity_report(breakdown: CapacityBreakdown) -> str:
    lines = [
        "CD-ROM CAPACITY REPORT",
        RULE,
        f"Disc profile:                {breakdown.disc_profile_name}",
        f"Physical capacity:           {breakdown.physical_capacity_bytes:,} bytes "
        f"({format_bytes_decimal(breakdown.physical_capacity_bytes)})",
        "",
        f"Filesystem overhead:         {breakdown.filesystem_overhead_bytes:,} bytes "
        f"({format_bytes_binary(breakdown.filesystem_overhead_bytes)}) [estimated]",
        f"Stored payload:              {breakdown.stored_payload_bytes:,} bytes "
        f"({format_bytes_binary(breakdown.stored_payload_bytes)})",
        f"Original source data:        {breakdown.original_logical_bytes:,} bytes "
        f"({format_bytes_binary(breakdown.original_logical_bytes)})",
        f"Compression multiplier:      {breakdown.compression_multiplier:.2f}:1",
        RULE,
        f"Estimated usable payload:    {breakdown.estimated_usable_payload_bytes:,} bytes",
        f"Remaining capacity:          {breakdown.remaining_bytes:,} bytes",
        f"Utilisation:                 {breakdown.utilisation_fraction * 100:.1f}%",
        f"Fits on this disc profile:   {'YES' if breakdown.fits else 'NO — exceeds capacity'}",
    ]
    return "\n".join(lines)


def format_benchmark_table(results: list[CompressionResult]) -> str:
    header = f"{'Algorithm':<15}{'Output':<13}{'Ratio':<11}{'Time':<10}"
    sep = "─" * len(header)
    body_rows = []
    for r in results:
        body_rows.append(
            f"{r.algorithm.value:<15}"
            f"{format_bytes_binary(r.compressed_size_bytes):<13}"
            f"{r.ratio:.2f}:1{'':<5}"
            f"{r.duration_seconds:.1f}s"
        )
    title = "COMPRESSION BENCHMARK"
    return "\n".join([title, sep, header, sep, *body_rows])
