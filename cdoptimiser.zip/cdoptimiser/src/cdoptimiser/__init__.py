"""CDOPTIMISER — CD-ROM capacity optimisation and archival packaging engine.

This package provides engineering-grade tooling for analysing, compressing,
packing and reporting on digital datasets destined for optical-media
distribution (CD-ROM / CD-R). It never claims to increase the physical
capacity of a disc; it optimises how much *logical* content can be
represented within a fixed physical capacity, and accounts transparently
for every byte of overhead along the way.
"""

__version__ = "0.1.0"
