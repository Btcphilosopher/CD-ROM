from __future__ import annotations

import json
from pathlib import Path

from cdoptimiser.core.exceptions import ManifestError
from cdoptimiser.core.models import ArchiveManifest, ManifestFileEntry


def write_manifest(manifest: ArchiveManifest, destination: Path) -> None:
    destination.write_text(json.dumps(manifest.to_dict(), indent=2), encoding="utf-8")


def read_manifest(source: Path) -> ArchiveManifest:
    if not source.exists():
        raise ManifestError(f"Manifest not found: {source}")
    try:
        data = json.loads(source.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ManifestError(f"Manifest is not valid JSON: {source}") from exc

    required = {
        "archive_id", "created_at", "tool_version", "source_dataset_hash",
        "total_original_bytes", "total_stored_bytes", "compression_algorithms", "files",
    }
    missing = required - data.keys()
    if missing:
        raise ManifestError(f"Manifest missing required fields: {sorted(missing)}")

    files = [
        ManifestFileEntry(
            relative_path=entry["relative_path"],
            original_size_bytes=entry["original_size_bytes"],
            original_sha256=entry["original_sha256"],
            stored_algorithm=entry["stored_algorithm"],
            stored_size_bytes=entry["stored_size_bytes"],
            packed=entry.get("packed", False),
        )
        for entry in data["files"]
    ]

    return ArchiveManifest(
        archive_id=data["archive_id"],
        created_at=data["created_at"],
        tool_version=data["tool_version"],
        source_dataset_hash=data["source_dataset_hash"],
        total_original_bytes=data["total_original_bytes"],
        total_stored_bytes=data["total_stored_bytes"],
        compression_algorithms=data["compression_algorithms"],
        files=files,
    )
